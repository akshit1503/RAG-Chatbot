# TechStack.md

Running log of the tech stack, architecture decisions, and every feature added to this project, with what was actually built, why, and how it was tested. Written incrementally as work happens — nothing in here is aspirational; each entry is only added after the feature is implemented and verified.

---

## Core stack (as of this session)

| Layer | Choice | Notes |
|---|---|---|
| Backend framework | FastAPI (Python) | async, auto Swagger docs, modular routers per module |
| LLM runtime | Ollama, local | embeddings + generation, auto-starts with the app if not already running |
| Embedding model | `nomic-embed-text` | local, free |
| Generation model | `gpt-oss:20b-cloud` (default) | Ollama's free cloud tier — verified free, no subscription required (unlike glm-5.2/kimi-k3/qwen3.5-cloud, which return "requires a subscription") |
| Vision/OCR model | `gemma4:cloud` | free cloud tier; used as OCR fallback for scanned PDFs with no text layer |
| Vector store | ChromaDB | local persistent client, cosine similarity, RBAC enforced via metadata `where` filter at query time |
| Relational storage | SQLite, two separate files | `app_metadata.db` (users/files/RBAC) and `tabular.db` (ingested CSV/Excel) — split deliberately so the Text-to-SQL LLM never has schema access to auth tables |
| Auth | JWT, 3 roles (user/operator/admin) × 3 scopes (personal/departmental/global) | |
| Math rendering | KaTeX, vendored locally (no CDN) | ~600KB, only `.woff2` fonts kept |
| Frontend | Vanilla JS + CSS, no framework | single `app.js` / `style.css` / `index.html` |
| PDF text extraction | pypdf, with pymupdf-based OCR fallback | |
| Web search | DuckDuckGo HTML scrape (unofficial, no API key) | free but not a supported API — see Known Limitations |

---

## Frontend: Liquid glass UI effect

**What:** Applied a CSS "liquid glass" refraction effect (glassmorphism + SVG `feTurbulence`/`feDisplacementMap` distortion) to the app's chrome surfaces: login/register cards, header, both sidebars, file/upload panels, and the summary modal.

**Source:** Technique adapted from [freefrontend.com/css-liquid-glass](https://freefrontend.com/css-liquid-glass/) → CodePen "Pure CSS iOS 26 Liquid Glass Effect" by daftplug. Pulled the actual HTML/CSS source directly from the CodePen editor's CodeMirror instances (not just eyeballing the rendered demo). Not copied verbatim — generalized into two reusable SVG filters (`#glass-distort-panel` for large surfaces, `#glass-distort-control` for small controls, unused so far) and a `.glass` utility class, since the original was a single fixed-size circular button demo with a photo background, not a set of arbitrary rectangular panels on a flat dark theme.

**Implementation:**
- `static/index.html` — hidden `<svg>` block defining the two displacement filters; `.glass` class added to `.login-card` (both), `.app-header`, `.chat-sidebar`, both `.panel` sections, `.modal-card`.
- `static/style.css` — `.glass` utility block placed at the **end** of the file (utility-class position), using `background: ... !important` on the base rule. This was necessary: every target component (`.panel`, `.login-card`, `.app-header`, `.modal-card`, `.chat-sidebar`) already sets an opaque `background: var(--surface)`, and a same-specificity single-class selector defined earlier in the file loses the cascade to those later component rules. Compound/utility-last placement fixes this without touching component rules.
- Added a subtle multi-blob radial-gradient background to `body`. **This was necessary, not decorative** — `backdrop-filter: blur()` on a flat single-color background is a no-op visually (blurring a uniform color produces the same uniform color), so the glass effect was technically applied but completely invisible until the background had some texture/color variation for it to refract.

**A real bug found and fixed along the way:** `.chat-sidebar` had `overflow-y: auto` directly on itself. Since `.glass`'s backdrop layer is an absolutely-positioned pseudo-element whose containing block is that same scrolling element, the glass backdrop would have scrolled away with the session list instead of staying fixed as a backdrop. Fixed by moving `overflow-y: auto` down to `.chat-session-list` (with `flex: 1; min-height: 0`) so only the list content scrolls while the glass-bearing parent stays static. `.panel`/`.sidebar` didn't have this problem since the scrolling container (`.sidebar`) doesn't carry `.glass` itself — only the inner `.panel` cards do, and those move as whole units with the page scroll, which is visually correct.

**Tested:**
- Verified via `getComputedStyle` that every CSS property (`background-color`, `box-shadow`, `backdrop-filter`, `filter: url(...)`, SVG filter element presence) actually resolved as expected, not just "looks right."
- Visual screenshots confirmed the effect is visible (soft warped color bleed-through) on the login card, header, and both sidebars.
- Specifically stress-tested the scroll fix: injected 60 fake chat sessions into `localStorage`, forced an overflow, scrolled the list 300px, and confirmed via screenshot that the glass backdrop stayed anchored to the card while only the list content moved underneath it.
- No console errors.

**Revision (user feedback, later in the session):** the user reported the collapsed-sidebar chat icon was visually uncentered and asked for a plain "frosted glass" look instead of this liquid-distortion one.
- **Icon centering, root-caused:** `.chat-sidebar-icon` was correctly `position: absolute` in its own rule, but `.glass > * { position: relative; z-index: 1; }` (defined later in the file, deliberately, so the glass utility block wins cascade battles against component rules) matched it too — same specificity (one class + universal selector each), later source order, so it silently overrode `absolute` back to `relative`. This wasn't caught by the earlier visual check because a `relative`-positioned icon still renders *somewhere* on screen, just not where `top`/`left` intended, so it "looked plausible" in the small preview it was originally checked in. Fixed by qualifying the selector as `.chat-sidebar .chat-sidebar-icon` (two classes) so it outranks `.glass > *`. Verified via `getBoundingClientRect()` before/after: offset from true center went from **10px off** to **0px** (exact).
- **Effect itself, replaced:** removed the SVG `feTurbulence`/`feDisplacementMap` distortion filters entirely (`filter: url(#glass-distort-panel)` on `.glass::after`, and the two `<filter>` defs in `index.html` — both now dead code, deleted rather than left unused). Root cause of why it read as muddy rather than glassy: applying an SVG `filter` and `backdrop-filter` to the *same* pseudo-element is inconsistently composited across browsers/GPUs, which is very likely why the "liquid" warping mostly just softened/dirtied the blur instead of producing a clean refraction. Replaced with a standard frosted-glass treatment on the same `.glass::after`/`::before` pseudo-elements: `backdrop-filter: blur(22px) saturate(160%)` alone (was `blur(14px) saturate(130%)` + the SVG filter), a slightly stronger tint (`rgba(255,255,255,0.06)`, was `0.035`), and an explicit `1px` translucent border for a cleaner pane edge. No new files, no new classes — same `.glass` utility, same call sites, just the effect definition changed.

**Tested (after the revision):**
- `getComputedStyle` confirmed `backdrop-filter: blur(22px) saturate(1.6)` resolves on `.app-header::after` with no `filter: url(...)` attached anymore.
- `getBoundingClientRect()` confirmed the collapsed sidebar icon is now exactly centered (0px offset from the rail's true center, both axes) — not just "looks closer."
- Screenshots of the login card and the collapsed/expanded sidebar rail before and after confirm a cleaner, unwarped translucent panel.
- Re-ran `node --check static/app.js` (unaffected by this CSS-only change, but confirmed anyway since the index.html edit removed a block near where scripts load).

**Status:** ✅ Done and verified (including the later frosted-glass revision).

---

## Conversation memory (multi-turn context)

**What:** All three query endpoints (`/rag/query`, `/rag/topics`, `/rag/query/from-topics`) now accept an optional `history: list[{role, content}]` field. Recent turns are formatted into every generation prompt (document-answer, web-fallback, general-knowledge-fallback) so follow-up questions like "what's its top speed?" or "how does it compare?" resolve against what was just discussed, instead of the model treating every message as a stateless one-off.

**Source:** Own design — no external reference, straightforward prompt-engineering + plumbing.

**Implementation:**
- `app/modules/rag/schemas.py` — added `ChatTurn` model and `history: list[ChatTurn] = []` on `QueryRequest`, `TopicsRequest`, `AnswerFromTopicsRequest`.
- `app/modules/rag/generation.py` — `_format_history()` renders the turns into a `Recent conversation:` block; a `{history}` placeholder was added to all three prompt templates (document, web, general-knowledge). Empty history renders to `""` so an existing single-turn chat's prompt is byte-identical to before this feature.
- `app/modules/rag/service.py` — `history` threaded through the full call chain: `_answer_from_web` → `_web_or_general_fallback` → `_answer_or_fallback` → `answer_query`/`ask`/`answer_from_topics`.
- `app/modules/rag/routes.py` — server-side `_MAX_HISTORY_TURNS = 10` cap via `_history_dicts()`, applied regardless of what a client sends, so prompt size stays bounded.
- `static/app.js` — `getRecentHistory()` pulls the last 6 messages from the active chat session (client-side `localStorage`, source of truth for session history) and sends them on every query, including from the topic-picker's "Get answer" action.
- Deliberately **retrieval-blind**: only generation sees `history`; the vector search still embeds just the raw current question. A follow-up that doesn't restate its topic (e.g. "what's its top speed?" with no antecedent in the same request) may not retrieve the right document — query rewriting for retrieval is a known future step, documented inline in `schemas.py`, not implemented here.

**Bugs found and fixed:**
- A test script (not app code) bug: `response.get('direct_answer', {})` when the JSON key is present but `null` returns `None`, not the `{}` default — `dict.get` only substitutes the default for a *missing* key. Chaining `.get('answer', ...)` on that `None` crashed. Not a product bug; fixed the test script to check `is not None` explicitly.

**Tested:**
- Isolated the generation-level effect from retrieval ambiguity by pinning `/rag/query/from-topics` to a freshly uploaded, freshly indexed `Redis.pdf`'s chunks directly (`topic_ids: ["6:0","6:1","6:2","6:3"]`), so the context is identical between runs and only `history` varies.
- Without history: asked "How fast is it compared to what we just discussed?" — nothing to resolve "it" or "what we just discussed" against; answer would necessarily be generic/confused.
- With history: same question, with a prior turn establishing "PostgreSQL... single-digit milliseconds due to disk I/O." The model correctly answered *"Redis offers sub-millisecond read/write latency, while a disk-based relational database such as PostgreSQL typically incurs single-digit milliseconds..."* — explicitly naming PostgreSQL and its latency figure, information that exists **only** in the injected history, not in the Redis.pdf context chunks. Confirms the model is actually reading and using `{history}`, not ignoring it.
- Verified via direct Python execution (pre-server-restart) that `build_prompt`/`build_fallback_prompt`/`build_web_prompt` render correctly both with and without history, and that empty history produces the old prompt text unchanged.
- Verified `python -c "import app.main"` and `node --check app.js` both clean after all edits; server restarted and `/health` returns 200.

**Status:** ✅ Done and verified.

---

## Feedback signal (👍/👎 on answers)

**What:** Every rendered answer (direct answers, topic-picker answers, and answers re-rendered from chat history) gets a "Was this helpful?" row with 👍/👎 buttons. A click POSTs the question, full answer text, `source` tier, and rating to the backend, is persisted, and the UI swaps the buttons for a static confirmation so an answer can't be double-rated by accident. Admins can list all collected feedback.

**Source:** Own design.

**Implementation:**
- `app/modules/rag/models.py` — new `AnswerFeedback` table (`user_id`, `question`, `answer`, `source`, `rating` enum `up`/`down`, optional `comment`, `created_at`). Lives on the shared app-metadata DB, same pattern as `DocumentIndex`.
- `app/modules/rag/schemas.py` — `FeedbackRequest` / `FeedbackOut`, `rating` typed as `Literal["up","down"]` so an invalid value is rejected by FastAPI's validation (422) before it ever reaches the DB layer.
- `app/modules/rag/service.py` — `record_feedback()`, `list_feedback()`.
- `app/modules/rag/routes.py` — `POST /rag/feedback` (any authenticated user), `GET /rag/feedback` (admin-only, 403 otherwise) — same admin-gate pattern already used elsewhere in the app (`current_user.role != Role.admin`).
- `static/app.js` — `renderFeedbackRow()` builds the row and handles the submit/confirm/error states; `renderAnswerInto()` now takes an optional `question` param and appends the row when present. Wired into all three render call sites: the direct-answer path, the topic-picker "Get answer" path, and history-rehydration (tracks `lastUserQuestion` while replaying a saved session so re-viewed answers still carry a working feedback row).
- `static/style.css` — `.feedback-row` / `.feedback-btn` styles.

**Tested:**
- `curl`: submitted an "up" and a "down" (with comment) via `POST /rag/feedback`, confirmed both appear via `GET /rag/feedback` (admin) ordered newest-first; confirmed a bogus `rating` value ("sideways") is rejected with 422 before touching the DB.
- Browser: asked "Tell me about Redis" in the live UI, confirmed the 👍/👎 row rendered under the answer, clicked 👍, confirmed it flipped to "Thanks for the feedback! 👍" with the buttons removed, then confirmed via `GET /rag/feedback` that the click actually persisted a new row (id 3, rating `up`, matching question) — not just a UI-only state change.

**Status:** ✅ Done and verified.

---

## Audit logging

**What:** A flat, append-only `audit_log` table recording who did what: logins, file uploads/downloads/deletes, RAG queries (with which answer tier resolved them), SQL queries, and SQL queries the authorizer sandbox rejected. `GET /audit` (admin-only) lists entries with optional `action`/`username` filters.

**Source:** Own design.

**Implementation:**
- `app/core/audit.py` — `AuditLog` model (`user_id`, `username` — denormalized so a row stays readable if the account is later deleted — `action`, `resource_type`, `resource_id`, `detail`, `created_at`) and `log_event()`, a best-effort writer that catches and logs (never raises) any failure, since an audit-write hiccup must not break the request it's describing.
- `app/modules/file_access/database.py` — `init_db()` now also imports `app.core.audit` and `app.modules.rag.models` before `create_all`, so both register on `Base.metadata` the same way `file_access.models` already did (the earlier `DocumentIndex` table relied on `rag.routes` being imported by the time `init_db()` ran; making the import explicit here removes that implicit ordering dependency for both new tables).
- `app/api/routes/audit.py` — `GET /audit`, admin-gated, same `role != Role.admin → 403` pattern used for `GET /rag/feedback`.
- Call sites: `routes_auth.py` (`login`), `routes_files.py` (`file_upload`, `file_download`, `file_delete`), `rag/routes.py` (`rag_query`, tagged with which tier — `documents`/`web`/`general_knowledge`/`topic_picker` — actually answered it), `text_to_sql/routes.py` (`sql_query` on success, `sql_query_blocked` — with the rejection reason — when the SQL authorizer sandbox rejects LLM-generated SQL; a distinct action so a pattern of these stands out as a potential prompt-injection signal).

**Tested:**
- `curl`: logged in, ran a RAG query, downloaded a file, then fetched `GET /audit` as admin and confirmed all three actions appear, newest-first, with correct `resource_type`/`resource_id`/`detail` (e.g. `rag_query | admin | answer_source documents | Tell me about Redis`).
- Confirmed the `action=login` filter returns only login rows.
- **Update (closed the gap flagged at the time this entry was first written):** later in this session, two real datasets were ingested (`employees.csv` → `t_7`, `secrets.csv` → `t_8`) specifically to test this properly. Confirmed the authorizer sandbox blocks a real cross-table `UNION` attack (`SELECT id, name FROM t_7 UNION SELECT id, api_key FROM t_8`) with `access to t_8.id is prohibited` — a genuine per-table denial, not just a missing-table coincidence. Then called the `/sql/datasets/{file_id}/query` route function directly with `service.answer_query` mocked to raise `UnsafeQueryError` (simulating what happens when the LLM's generated SQL fails), and confirmed it both returns the correct `422` and writes a real `sql_query_blocked` audit row (`admin | dataset:7 | "...-- access to t_8.id is prohibited"`) — the row count was checked before and after, not just assumed from the code path. This call site is now verified the same as the other three.

**Status:** ✅ Done and verified — all four call sites confirmed live, including `sql_query_blocked`.

---

## Hover-to-reveal chat sidebar

**What:** The chat-sessions sidebar (`+ New chat` / session list) is collapsed by default to a 52px icon rail showing a 💬 chat bubble, and expands to its full 220px width on hover (or keyboard focus, via `:focus-within`, so it's not mouse-only) — per the user's explicit request. Reclaims horizontal space for the main chat/document panels without removing the multi-chat feature.

**Source:** Own design — pure CSS (width transition + opacity-crossfade between the icon and the content), no JS needed for the show/hide itself.

**Implementation:**
- `static/index.html` — wrapped the existing `#new-chat-btn` + `#chat-session-list` in a new `.chat-sidebar-content` div, and added a `.chat-sidebar-icon` (💬) as a sibling. IDs unchanged, so no `app.js` changes were needed.
- `static/style.css` — `.chat-sidebar` collapsed width `52px`→`220px` on `:hover`/`:focus-within` via a `width` transition, `overflow: hidden` so content stays clipped while collapsed rather than reflowing the layout; the icon and content cross-fade via opacity (icon visible only while collapsed, content only while expanded). `tabindex="0"` added to the `<aside>` so it's keyboard-focusable (Tab key) for the `:focus-within` expand path.

**Tested (real browser clicks, not just code review):**
- Screenshot confirmed the collapsed state shows only the icon rail.
- Hovered over the rail — screenshot confirmed a smooth expand showing "+ New chat" and the session list, icon fading out.
- Moved the mouse away — screenshot confirmed it collapses back.
- While hovering (expanded), clicked "+ New chat" via its `ref` — confirmed the chat log actually cleared, proving the expanded content is fully interactive, not just visually revealed.

**Revision (user request, later in the session):** two follow-up asks arrived together — the collapsed icon was visually uncentered (see the root-cause and fix already documented in the Liquid Glass UI Effect entry above, since it was the same underlying `.glass > *` cascade bug), and the user pointed at a specific demo — [freefrontend.com/css-liquid-glass](https://freefrontend.com/css-liquid-glass/)'s "Apple Liquid Glass Effect" (`lassiterda/pen/vEOpqMa`, itself adapted from [lucasromerodb/liquid-glass-effect-macos](https://github.com/lucasromerodb/liquid-glass-effect-macos) on GitHub) — and asked for that exact effect on this tab specifically, distinct from the plainer frosted-glass treatment just applied to the rest of the chrome in the prior revision.
- **Finding the right pen took real verification, not a guess:** the freefrontend page has *two* different snippets both titled "Apple Liquid Glass Effect" (one CSS/SVG-based, one a React Three Fiber + GLSL demo). Confirmed which was which by reading each card's actual description text via the live DOM (`data-stash-source` + the paragraph text), not by title match alone — the GLSL one was a false lead a title-only match would have picked wrongly.
- Pulled the real HTML and CSS directly from the CodePen editor's live `CodeMirror` instances (`.CodeMirror` → `.CodeMirror.getValue()`), the same verification method used for the original liquid-glass work — never eyeballed the rendered demo and guessed at the code.
- `static/index.html` — added the source's `#glass-distortion` SVG filter (`feTurbulence` → `feComponentTransfer` → `feGaussianBlur` → `feSpecularLighting`/`fePointLight` → `feComposite` → `feDisplacementMap`; values unchanged from source), scoped to this one use rather than reintroducing a general-purpose filter. Restructured `.chat-sidebar`'s markup to the source's 3-layer pattern: `.liquidGlass-effect` (blur + SVG distortion) → `.liquidGlass-tint` (surface color) → `.liquidGlass-shine` (inset highlight), with the real content (`.chat-sidebar-icon`, `.chat-sidebar-content`) stacked above via explicit `z-index: 3`.
- `static/style.css` — layer styles adapted from the source with one deliberate change: the source's tint is `rgba(255,255,255,0.50)`, a bright look meant for a light-themed iOS dock over a photo background; lowered to `0.10` so it reads as glass rather than fog against this app's dark theme. Blur, shine, and the SVG filter reference are otherwise unchanged from source.
- This tab no longer carries the `.glass` utility class at all (replaced by its own dedicated 3-layer treatment) — it's now visually distinct from the plainer frosted-glass panels elsewhere, which was the point of a per-element ask rather than a global change.

**Tested (the revision):**
- `getComputedStyle` confirmed all three layers resolve correctly on the live page: `.liquidGlass-effect` has both `backdrop-filter: blur(6px)` and `filter: url("#glass-distortion")` applied, `.liquidGlass-tint`'s background and `.liquidGlass-shine`'s inset box-shadow both resolve as authored, and the `#glass-distortion` element exists in the DOM.
- Screenshots of the expanded rail show visible warped/refracted color bleed-through along its edge over the app's background blobs — a genuinely different, more textured look than the flat frosted panels elsewhere, confirming the distortion is actually rendering, not just present in the CSS.
- Re-confirmed click-through still works after the restructure: clicked "+ New chat" (now stacked above three new layer `div`s instead of zero) and confirmed the chat log actually cleared.
- Re-confirmed the collapse/expand mechanics survived the markup change: expanded on hover, collapsed on mouse-away *unless* focus was still inside it (`:focus-within` correctly keeping it open when the just-clicked button retained keyboard focus — verified via `document.activeElement`, confirmed this is the pre-existing, intentional accessibility behavior and not a new bug), then collapsed once focus moved elsewhere.

**Status:** ✅ Done and verified.

---

**Status:** ✅ Done and verified.

---

## Settings tab with privacy features

**What:** A third top-level tab, "Settings", with three interpretations of "privacy features" chosen deliberately to be real, testable controls rather than a vague catch-all:
1. **Include web search in answers** toggle — per-user, opts out of the web-search fallback tier for that user's own requests, without needing an admin to disable it server-wide.
2. **My chat history** — export (download all local chat sessions as JSON) and clear (wipe them from this browser), with a confirm-gate on the destructive action.
3. **My recent activity** — a self-service view into the new audit log (logins, file access, queries) so a user can see exactly what's recorded about their own account.

**Source:** Own design — the user's ask ("a settings tab which have some privacy features") didn't specify which controls, so this session picked concrete, verifiable ones rather than a decorative placeholder.

**Implementation:**
- `static/index.html` — new `#tab-settings` panel alongside Chat/SQL, reusing the existing tab-switcher (`data-tab="settings"` — no JS changes needed there, it's already generic over `.tab-btn`/`.tab-panel`).
- `app/modules/rag/schemas.py` — `allow_web_search: bool = True` added to `QueryRequest`, `TopicsRequest`, `AnswerFromTopicsRequest`.
- `app/modules/rag/service.py` — threaded `allow_web_search` through the full fallback chain (`_answer_from_web` now short-circuits to `None` before ever calling `search_web()` when it's false, same as when the server-wide `settings.enable_web_search` is false) → `_web_or_general_fallback` → `_answer_or_fallback` → `answer_query`/`ask`/`answer_from_topics`.
- `app/modules/rag/routes.py` — all three POST endpoints pass `request.allow_web_search` through.
- `app/api/routes/audit.py` — `GET /audit` now lets a non-admin call it too, but silently forces the `username` filter to their own username regardless of what they pass — same endpoint powers both the admin audit view and this per-user privacy view, without giving non-admins visibility into anyone else's activity.
- `static/app.js` — `getAllowWebSearch()`/`setAllowWebSearch()` (localStorage, scoped per-user like chat sessions: `allow_web_search_v1_${currentUser.id}`), `refreshActivity()` (fetches `GET /audit`), `initSettingsTab()` wiring the checkbox and the export/clear/refresh buttons. The two RAG-answering fetch calls (`/rag/topics`, `/rag/query/from-topics`) now send `allow_web_search: getAllowWebSearch()`.
- `static/style.css` — `.settings-page`/`.settings-block`/`.settings-toggle`/`.activity-list` etc.

**Tested:**
- Backend, deterministically (bypassing DuckDuckGo's live bot-detection flakiness): mocked `search_web`, called `service._answer_from_web(..., allow_web_search=True)` — confirmed `search_web` was called and a `"web"`-sourced result came back; called it again with `allow_web_search=False` — confirmed `search_web` was never called and the function returned `None` (forcing the caller on to general knowledge).
- Browser: opened the Settings tab, confirmed all three blocks render with real data (the activity feed showed actual prior actions from this session — logins, a file download, a RAG query — self-scoped correctly, no other users' rows).
- Clicked the web-search toggle off, confirmed `localStorage["allow_web_search_v1_1"] = "false"`, then confirmed live in-page that `getAllowWebSearch()` — the same function the chat form calls when building its request body — returned `false`.
- Export: built the same `Blob` the button builds, read it back, and confirmed it round-trips to the real in-memory session array (count and content matched) — a real file download couldn't be verified through the sandboxed preview, so this confirms the export data itself is correct instead.
- Clear: clicked once with the native `confirm()` dialog auto-dismissed by the browser sandbox (returns falsy) — confirmed sessions were correctly **not** cleared, proving the confirm-gate blocks accidental data loss. Then patched `window.confirm` to auto-accept (safe here — only throwaway test sessions from this session's own testing) and clicked again — confirmed `chatSessions` emptied, the status text updated, and `localStorage` was actually rewritten to `"[]"`, not just the in-memory array.

**Status:** ✅ Done and verified.

---

## Supabase database integration

**What:** Per the user's request ("link it to a supabase database to store database queries and other stuff"), audit-log rows (logins, file access, queries) and feedback rows mirror to a Supabase project as a secondary, queryable store, alongside the existing local SQLite writes (which stay the source of truth). **Fully activated and live-tested against a real project** — the user later authorized creating the project directly ("use supabase and integrate yourself"); this agent created it (org `akshit1503's Org`, project `RAG`, region Southeast Asia/Singapore), ran the schema, retrieved the new-format `sb_secret_...` API key, and wired it into `.env`.

**Source:** Own design, using the official `supabase-py` client.

**Implementation:**
- `app/core/config.py` — `supabase_url`, `supabase_key`, `supabase_sync_enabled` (default `true`); both URL/key blank (the real current state) means the integration is fully inactive.
- `app/core/supabase_client.py` — `is_configured()`, `get_client()` (lazy-imports `supabase`, raises `SupabaseNotConfiguredError` with an actionable message if unconfigured or the package isn't installed), and `mirror_row(table, data)` — the only thing callers use: a pure fire-and-forget write that silently no-ops when unconfigured and silently logs-and-swallows any failure when configured, since Supabase must never be able to block or fail the primary request.
- `app/core/audit.py` — `log_event()` now also calls `mirror_row("audit_log", ...)` after its local SQLite commit succeeds.
- `app/modules/rag/service.py` — `record_feedback()` now also calls `mirror_row("answer_feedback", ...)`.
- `supabase_schema.sql` (new file, repo root) — the exact DDL for both mirror tables (with RLS enabled, no policies, so only the service-role key can reach them), for the user to run once in their Supabase project's SQL editor before setting the env vars.
- `.env.example` — `SUPABASE_URL` / `SUPABASE_KEY` / `SUPABASE_SYNC_ENABLED` documented, both blank by default.
- `requirements.txt` — added `supabase==2.31.0`. Installing it pulled in newer `pydantic` (2.10.4→2.13.5) and `pyjwt` (2.10.1→2.13.0) than what was previously pinned; verified both bumps are safe (see Tested).

**Tested:**
- Installed `supabase` into the venv for real (not mocked) and confirmed the app still imports, still starts, login (JWT, the most upgrade-sensitive path given the `pyjwt` bump) still works, and a feedback submission (which now also attempts the mirror) still succeeds end-to-end — proving the dependency bump didn't break anything already working.
- With settings unconfigured: confirmed `is_configured()` is `False` and `mirror_row(...)` is a true no-op (no exception, no network call).
- Confirmed `get_client()` raises `SupabaseNotConfiguredError` with an actionable message when unconfigured.
- Simulated the "configured but wrong/unreachable" case with fake credentials pointed at a nonexistent Supabase project: confirmed `mirror_row()` makes a real network attempt (a genuine DNS failure, not mocked), catches it, logs a warning with the full traceback, and returns normally — never raises into the caller.
- **Real end-to-end test against the live project** (the gap flagged in an earlier pass, now closed): created the Supabase project via the dashboard (region Southeast Asia/Singapore), ran `supabase_schema.sql` in its SQL Editor (via the Monaco editor's own `setValue()` API rather than simulated typing — simulated typing hit the editor's auto-bracket-closing feature and produced a mismatched-paren syntax error on the first attempt; setting the model value directly avoided that entirely), confirmed both tables (`audit_log`, `answer_feedback`) exist in the Table Editor, retrieved the new-format secret API key (`sb_secret_...` — Supabase's current replacement for the legacy `service_role` JWT key) by inspecting the DOM directly rather than trusting a screenshot transcription, and set `SUPABASE_URL`/`SUPABASE_KEY` in `.env`.
  - Direct `mirror_row()` call against the real project, then queried the table back via `get_client()` — the row was genuinely there, not just "no exception raised."
  - Real app actions next: logged in via `POST /auth/login` and submitted real feedback via `POST /rag/feedback`, then queried Supabase directly and confirmed both actually mirrored — the login row's `source_id` matched the local SQLite audit row's real id, and the feedback row's `source_id` matched the local feedback row's real id, proving the two stores are genuinely linked, not just independently populated.
  - Cleaned up the manual test row from the live table afterward so it doesn't linger as fake data next to real activity.

**Status:** ✅ Done and verified — fully activated, real writes confirmed landing in the user's own Supabase project.

---

## Hybrid search (keyword + vector)

**What:** Retrieval now fuses vector-similarity search with a BM25 keyword ranking, so literal terms a purely semantic embedding can under-weight (a port number, a function name, an exact phrase) get proper credit. `_search()` casts a wider net than before (4x the requested `top_k`, capped at 40) via Chroma, then `hybrid_search.hybrid_rank()` re-ranks that candidate pool by fusing the two signals via Reciprocal Rank Fusion (RRF) before truncating to the originally-requested `top_k`. Applies to every retrieval path (`answer_query`, `ask`/topic-picker, and indirectly `answer_from_topics` since its chunks come from a prior `ask`/`discover_topics` call).

**Source:** Own design — BM25 (Robertson/Sparck Jones) and Reciprocal Rank Fusion (Cormack et al., 2009) are standard, well-established IR techniques; implemented directly (no new dependency) since the candidate pool being re-ranked is always small (≤40 chunks), not a full-corpus index.

**Implementation:**
- `app/modules/rag/hybrid_search.py` (new file) — `bm25_scores()` (minimal in-memory BM25 over the candidate texts), `reciprocal_rank_fusion()` (fuses a vector-rank list with keyword scores, standard `k=60` RRF constant), `hybrid_rank()` (the public entry point: candidates → fused top_k, with a passthrough no-op when there are ≤1 candidates or the query has zero keyword overlap with anything).
- `app/modules/rag/service.py` — `_search()` now requests `candidate_k = min(top_k * 4, 40)` chunks from Chroma instead of exactly `top_k`, then calls `hybrid_rank(question, candidates, top_k)` before returning.

**Tested:**
- Unit-level: confirmed BM25 correctly ranks a document with more query-term overlap above one with less; confirmed RRF measurably pulls a candidate that's *worst* on vector similarity but *best* on keyword score from last place (rank 19 of 20) up to rank 8 — a real, substantial promotion. Also hit (and correctly diagnosed, not worked around) a case where two top candidates swapped ranks {0,1} on both signals score to an exact tie under RRF's math, correctly broken by stable-sort in favor of the top vector match — confirmed this is expected RRF behavior, not a bug, rather than forcing a test to pass.
- Live, end-to-end, against real indexed documents (not mocked): ran the same query ("What is the default port 6379 used for?") through both `vectorstore.query_chunks()` alone (pure vector order) and through `hybrid_rank()` on the identical candidate set, and diffed the two orderings directly. `Redis.pdf` chunk 1 (containing "Expected answer: 6379") moved from vector-rank #4 to hybrid-rank #3, and chunk 0 moved from #5 to #2 — a measurable, real improvement from the keyword signal, not just a passing unit test.
- Confirmed the full `/rag/topics` request still returns a sensible response after the change (didn't just test the ranking function in isolation).

**Status:** ✅ Done and verified.

---

## Reranking (MMR — Maximal Marginal Relevance)

**What:** A second reranking pass, after hybrid search, that trims a relevance-ranked shortlist down to the final `top_k` while balancing relevance against redundancy — so a small context window doesn't end up filled with 3-4 near-duplicate chunks (adjacent paragraphs repeating the same point) at the expense of genuinely different information ranked just below them.

**Source:** Own design — MMR (Carbonell & Goldstein, 1998) is a standard IR/summarization technique; implemented directly in pure Python (cosine similarity over Chroma-returned embeddings), no new dependency.

**Implementation:**
- `app/modules/rag/vectorstore.py` — `query_chunks()` now requests `embeddings` from Chroma in addition to documents/metadatas/distances (needed for pairwise similarity between candidates; previously only fetched what hybrid search needed).
- `app/modules/rag/reranking.py` (new file) — `mmr_rerank(candidates, top_k, lambda_mult=0.7)`. Fails open (falls back to a plain top_k truncation) when there aren't enough candidates to matter or any candidate is missing an embedding, since this is a quality refinement, not something that should ever be able to break an answer.
- `app/modules/rag/service.py` — `_search()` gained a `use_mmr: bool = False` parameter, **deliberately not applied everywhere**: `answer_query()` (the direct single-turn path) opts in (`use_mmr=True`); `ask()` and `discover_topics()` do not.

**A real bug found and fixed during testing:** applying MMR unconditionally in `_search()` broke the already-shipped, already-tested "skip the topic picker for an unambiguous question" feature. `ask()`'s single-dominant-source check inspects the top-4 chunks' file IDs; MMR's diversity term can deliberately promote a lower-relevance chunk from a *different* document purely to reduce redundancy, which corrupted that top-4 window into looking like a multi-source match. Concretely: "Tell me about Redis" — previously answered directly from `Redis.pdf` (see the Conversation Memory entry's own test of this exact query) — started incorrectly showing the topic picker once MMR ran unconditionally, because MMR pulled in one chunk from an unrelated RBAC document to diversify a set that was already correctly single-source. Fixed by scoping MMR to only the path with no topic-picker decision downstream (`answer_query`), leaving `ask()`/`discover_topics()` on the pure hybrid-relevance order their dominance check depends on. Caught by re-running the exact regression scenario after implementing MMR, not assumed safe.

**Tested:**
- Unit-level: confirmed `lambda_mult=1.0` (pure relevance) keeps two near-identical top candidates over a genuinely different third one; confirmed `lambda_mult=0.5` correctly swaps the redundant second pick for the different one; confirmed fail-open behavior with missing embeddings (plain truncation, no crash); confirmed a passthrough when `top_k >= len(candidates)`.
- Live: ran `_search()` with `use_mmr=False` vs `use_mmr=True` on the identical broad query against real indexed documents and diffed the two chunk selections directly — MMR swapped out a second same-document, adjacent chunk for chunks from a different document, a real, visible diversification.
- Regression check (post-fix): re-ran "Tell me about Redis" through `/rag/topics` and confirmed it's back to a clean `direct_answer` with all 4 sources from `Redis.pdf`, and separately confirmed `/rag/query` (the MMR-enabled path) still returns a valid, correctly-shaped response with no `embedding` field leaking into the `sources` list sent to the frontend.

**Status:** ✅ Done and verified.

---

## Per-user rate limits / quotas

**What:** Expensive, LLM-backed endpoints (`/rag/query`, `/rag/topics`, `/rag/query/from-topics` — sharing one `rag_query` quota bucket since they're all "asking a question"; `/sql/datasets/{id}/query` on its own `sql_query` bucket) are now rate-limited per user: 20 requests/minute by default, sliding window, `429 Too Many Requests` with a `Retry-After` header once exceeded.

**Source:** Own design.

**Implementation:**
- `app/core/rate_limit.py` (new file) — `check_rate_limit(user_id, bucket, limit=None, window_seconds=60)`, an in-memory sliding-window counter keyed by `(user_id, bucket)`, thread-locked (uvicorn's default worker model runs request handlers on a thread pool for sync def routes, which all of these are). Explicitly documented as per-process/in-memory — correct for this app's single-instance deployment model, would need a shared store (Redis) behind a real load balancer with multiple worker processes.
- `app/core/config.py` — `rate_limit_enabled` (default `true`), `rate_limit_requests_per_minute` (default `20`, `<=0` = unlimited, same convention as `max_upload_size_mb`/`max_ocr_pages`).
- `app/main.py` — a `RateLimitExceededError` → `429` exception handler (same pattern as the existing `OllamaUnavailableError` → `503` handler), setting `Retry-After` from the actual remaining window time.
- Call sites: one `check_rate_limit(current_user.id, "rag_query")` / `"sql_query"` line at the top of each of the four route handlers, before any real work happens.

**Tested:**
- Unit-level: confirmed the Nth+1 call within a window is correctly blocked while the first N succeed; confirmed two different `user_id`s in the same bucket, and the same `user_id` in two different buckets, are correctly independent (one's usage never affects the other's); confirmed `limit<=0` means unlimited.
- Live, end-to-end: restarted the server with `RATE_LIMIT_REQUESTS_PER_MINUTE=1` specifically to make this fast to test for real rather than needing 21 real LLM calls. First `/rag/query` call: `200`. Second, immediately after: `429` with `retry-after: 43` and the expected JSON body. Then confirmed a *different* user hitting the same endpoint right after was **not** blocked (`200`), and that the same admin user's `/sql/datasets/{id}/query` call was **not** blocked by their already-exhausted `rag_query` bucket (`200`) — both isolation properties proven over the real HTTP API, not just the unit-level function. Restarted the server back to the default `20`/min afterward.

**Status:** ✅ Done and verified.

## Structured data extraction

**What:** A new endpoint, `POST /utility/documents/{file_id}/extract`, that pulls a set of named fields out of a document as JSON instead of a free-text answer — e.g. `{"fields": [{"name": "default_port", "description": "..."}]}` → `{"data": {"default_port": 6379}}`. Every requested field name is always a key in the response (`null` if genuinely not found in the document, never a missing key or a guessed value).

**Source:** Own design — reuses the same code-fence-stripping/JSON-reconciliation pattern already proven in `rag/generation.py`'s `generate_topic_labels()`, applied to a new extraction use case.

**Implementation:**
- `app/modules/utility/extraction.py` (new file) — `extract_fields(text, fields, descriptions)`. Single-pass for documents under the same 12,000-char budget summarization.py uses; for longer documents, chunks the text, extracts per-chunk, and merges by taking the first non-null value found per field across chunks in document order. `_parse_json_object()` strips markdown code fences the model sometimes wraps its JSON in, falls back to an all-`None` dict on unparseable output (never raises), and always reconciles the result to exactly the requested keys regardless of what the model actually returned.
- `app/modules/utility/schemas.py` — `ExtractField` (`name` + optional `description`), `ExtractRequest`, `ExtractResponse` (`data: dict[str, Any]` — deliberately not a narrower type, since the model legitimately returns nested lists for fields like "supported data structures", not just flat scalars).
- `app/modules/utility/service.py` — `extract_from_file()`: documents (PDF/DOCX/TXT/MD) only. Tabular files (CSV/XLSX) are explicitly rejected with a `422` pointing at `/sql/datasets/{id}/schema` instead — they already have a real, directly queryable schema, so LLM-based extraction would just be a worse way to read a column that's already accessible.
- `app/modules/utility/routes.py` — the route, rate-limited via the same `check_rate_limit()` used elsewhere (its own `"extract"` bucket).
- `static/index.html`/`app.js`/`style.css` — an "Extract fields" button added next to "Summarize" in each file's action row, reusing the existing summary modal (title/body swapped per use, rather than building a second modal). Prompts for comma-separated field names inline (a real input field in the modal, not a native `window.prompt()` — deliberately avoided since a native dialog would be an awkward, easy-to-forget dependency for both real users and automated testing), then renders `data` as a clean key/value table, with a missing field shown as `(not found)`.

**Tested:**
- Unit-level: confirmed code-fenced JSON with an unrequested extra key is correctly parsed down to exactly the requested keys; confirmed fully malformed (non-JSON) model output degrades to an all-`None` dict rather than crashing; confirmed the chunk-merge logic picks the first non-null value per field across a 3-chunk sequence.
- Live, against the real `Redis.pdf`: requested `default_port`, `data_structures`, `eviction_policies` (all genuinely present) plus `company_headquarters_address` (genuinely absent). Got back `default_port: 6379` (correct), `data_structures` as a real JSON array of the 5 actual Redis data types (correct, and confirms the `Any`-typed schema decision was necessary — the model returns real structure, not flat strings), `eviction_policies` as `["LRU", "LFU", "volatile-ttl"]` (correct), and `company_headquarters_address: null` — the model correctly declined to invent an address rather than hallucinating one, the same grounding property already verified for the main RAG answer path.
- Confirmed extraction on a CSV (`employees.csv`, file_id 7) is rejected with `422` and the schema-endpoint pointer, and that an empty `fields` list is rejected with `422` too.
- Browser: clicked "Extract fields" on `Redis.pdf` in the live UI, typed `default port, data structures, eviction policies` into the modal's input, clicked "Extract", and confirmed a screenshot shows the real results table with the correct values (matching the API-level test above) rendered inline in the modal — not just that the request succeeded.

**Status:** ✅ Done and verified.

---

## Cross-table SQL joins

**What:** A new endpoint, `POST /sql/join-query`, that lets a question span multiple ingested datasets — `{"file_ids": [7, 9], "question": "..."}` — with the LLM allowed to generate a real SQL `JOIN` across them, not just query one table at a time like the existing `/sql/datasets/{id}/query`.

**Source:** Own design. Handled as security-sensitive throughout, per the explicit scoping note in the original feature list — this touches the same authorizer sandbox that's the app's actual SQL-injection defense, so it was generalized rather than bypassed or loosened.

**Implementation:**
- `app/modules/text_to_sql/query_executor.py` — `_make_authorizer()` and `execute_readonly()` generalized from a single `allowed_table: str` to an `allowed_tables: set[str]` (single-table queries now just pass a one-element set — `answer_query()`'s existing call site was updated to `execute_readonly(sql, {dataset.table_name})`, so the original endpoint's behavior is unchanged, just expressed through the more general signature). The authorizer still hard-denies `SQLITE_READ` on any table not in the set — this is the one real security boundary, unchanged in kind, just parameterized over more than one table.
- `app/modules/text_to_sql/nl_to_sql.py` — `build_join_prompt()`: a new prompt template listing every involved table's schema + sample rows, instructing the model it may `JOIN` across exactly these tables and no others.
- `app/modules/text_to_sql/service.py` — `answer_join_query(datasets, question)`. Deliberately takes no `user`/RBAC context at all — by design, so that responsibility can never be silently skipped by some future call site; it's a mandatory, visible step at the route layer instead.
- `app/modules/text_to_sql/routes.py` — `POST /sql/join-query`: loops over every requested `file_id` and calls the same `_get_authorized_file()` RBAC check already used everywhere else in this module (404s on the first file the requester can't see, before any dataset name, schema, or SQL ever reaches the LLM or the authorizer) — a user can never get a table added to the allowed set just by listing its `file_id`. Requires at least 2 `file_ids` (a single-table "join" is just `/sql/datasets/{id}/query`). Logs `sql_join_query` (success) / `sql_query_blocked` (rejected SQL) to the audit trail, resource_id as the comma-joined file_ids.
- `app/modules/text_to_sql/schemas.py` — `JoinQueryRequest`, `JoinQueryResponse` (adds `file_ids` to the existing `QueryResponse` shape).
- `static/index.html`/`app.js`/`style.css` — the SQL tab's dataset `<select>` is now `multiple` (a small listbox instead of a dropdown), with a hint that Ctrl/Cmd-click selects more than one. The submit handler routes to `/sql/join-query` when more than one dataset is selected, or the original `/sql/datasets/{id}/query` when exactly one is — the single-dataset path is unchanged.

**Tested — live, with real data, not mocked:**
- Uploaded and ingested a second, genuinely related dataset (`departments.csv` → `t_9`, with a `department` column matching `employees.csv`/`t_7`'s), then asked a question that actually requires both: *"For each employee, show their name, salary, and their department's manager and budget."* Got back a real, correct SQL query — `SELECT t_7.name, t_7.salary, t_9.manager, t_9.budget FROM t_7 JOIN t_9 ON t_7.department = t_9.department` — and verified the returned rows by hand (e.g. Alice/Carol/Eve are all Engineering → correctly joined to Grace / $2,500,000).
- **Security boundary, directly attacked:** with the join's allowed set correctly `{t_7, t_9}`, ran two adversarial queries against `execute_readonly()` targeting `t_8` (the `secrets.csv` table from the Audit Logging entry's earlier test, a real table in the same database but *not* part of this join) — one via `JOIN`, one via `UNION`. Both correctly rejected with `access to t_8.<column> is prohibited`. A table existing in the database is not enough to read it; it has to be in the specific request's verified allowed set.
- **RBAC gate, directly attacked:** uploaded a `personal`-scope dataset as `admin` (invisible to other users by the existing scope rules), then had the non-admin `apidocs-test-user` account attempt to join it against a file they *do* own — got `404 File not found` (not a leaking `403`), and crucially this happens in the RBAC loop before `answer_join_query` (and therefore the LLM and the authorizer) is ever invoked — confirmed by the response containing no SQL/schema information at all.
- Confirmed the successful join was correctly audit-logged: `admin | dataset_join | 7,9 | "For each employee..."`.
- Browser: opened the SQL tab, Ctrl-clicked `#9 departments.csv` and `#7 employees.csv` (confirmed via JS that both were really selected, not just visually), asked "Which department has the highest budget and who manages it?", clicked Send, and confirmed via `read_network_requests` that the request actually went to `/sql/join-query` (not the single-dataset endpoint) — the model correctly answered from `t_9` alone (`SELECT department, manager FROM t_9 ORDER BY budget DESC LIMIT 1` → "Engineering... managed by Grace", correct), demonstrating the prompt's "don't force an unnecessary JOIN" instruction working as intended even though two tables were available.

**Status:** ✅ Done and verified.

---

## Agentic multi-step reasoning (RAG + SQL + web chained automatically)

**What:** A new endpoint, `POST /agent/query`, that decomposes a question into up to 3 tool calls — `rag` (document search), `sql` (a specific ingested dataset), `web` (web search) — executes them, and synthesizes one coherent final answer, instead of the user having to pick a tab/tool themselves. The response includes a `steps` array showing exactly which tools ran, on what sub-question, and a summary of each result — agentic transparency, not a black box.

**Source:** Own design. Deliberately built as an orchestration layer over the app's existing, already-tested tool implementations (`rag.service.answer_query`, `text_to_sql.service.answer_query`, `rag.service.web_or_general_answer`) rather than reimplementing retrieval/SQL/web logic a third time — the agent's only new logic is planning (deciding which tools to call) and synthesis (combining their results).

**Implementation:**
- `app/modules/agent/planning.py` (new) — `build_plan_prompt()` shows the planner LLM only the documents/datasets the requesting user can see, and asks for a JSON plan (`{"steps": [{"tool": ..., "question": ..., "file_id": ...}]}`, `sql` steps only). `parse_plan()` never trusts the output blindly: drops any step naming a tool it doesn't recognize, drops any `sql` step naming a `file_id` outside the caller-supplied valid set (defense in depth — nothing stops a model from hallucinating an id it wasn't shown), truncates to `MAX_STEPS = 3`, and degrades malformed/non-JSON output to an empty plan rather than raising. `build_synthesis_prompt()`/`synthesize()` combine the executed steps' full results into one final answer.
- `app/modules/agent/service.py` — `run_agent_query()`: builds the RBAC-filtered manifest (`_visible_manifest()`, reusing `rbac.can_view_file` the same way every other module does), gets a plan, and executes each step by calling straight into the existing tested service functions — never regenerates SQL or retrieval logic itself. **Re-verifies RBAC a second, independent time at execution** for every `sql` step (`crud.get_file_by_id` + `rbac.can_view_file` again), even though the planner was only ever shown visible datasets — the same defense-in-depth pattern used in the Cross-table SQL Joins entry above. Falls back to the plain single-tool RAG flow (`_fallback_to_plain_rag`) whenever planning produces nothing usable, or every planned step failed RBAC/execution — an agent that can't plan still must not leave the user without an answer.
- `app/modules/agent/schemas.py` / `routes.py` — `POST /agent/query`, its own rate-limit bucket (`"agent_query"`, capped tighter at 10/min by default since one call can itself trigger up to 3 sub-calls), audit-logged as `agent_query` with the step count as `resource_id`.
- `app/modules/rag/service.py` — added `web_or_general_answer()`, a thin public wrapper around the already-existing `_web_or_general_fallback()`, so the agent's `web` tool reuses that exact tested logic instead of a second implementation.
- `static/index.html`/`app.js`/`style.css` — a fourth top-level tab, "Agent", alongside Chat/SQL/Settings (the existing generic tab-switcher needed no changes). `renderAgentAnswer()` shows the final answer, then an open-by-default "N step(s) taken" panel with a colored tool-name badge, the sub-question, and a summary per step, followed by the usual document/web source lists.

**Tested — live, with real multi-tool questions, not mocked:**
- Single-source question ("What is the default Redis port?") → planner correctly chose a single `rag` step, answered `6379` (matches every earlier RAG test of this same fact).
- **Genuine multi-tool chaining:** *"What is the average employee salary, and separately, what port does Redis use by default?"* → planner correctly split this into a `sql` step (`file_id: 7`, "average salary") and a `rag` step ("Redis port"), executed both as real tool calls, and synthesized: *"Average employee salary: $85,600 · Default Redis port: 6379."* Verified both figures by hand — $85,600 is the correct mean of the 5 employees' salaries ((95000+72000+105000+68000+88000)/5), and 6379 is the correct Redis port from earlier tests. This is real chained execution, not a scripted response.
- **RBAC isolation, tested twice (first attempt caught a test-design mistake, not a bug):** first tried a non-admin user asking about `secrets.csv` — got real data back, which looked alarming until double-checked: that file is genuinely `scope: global`, so it's legitimately visible to everyone, and the agent behaved correctly. Re-ran properly against `admin_private.csv` (genuinely `scope: personal`, owned by `admin`) — the non-admin user's agent query correctly could **not** reference it (`steps: []`, "I don't have access to that dataset"), confirming the RBAC-filtered manifest actually excludes it.
- **Second, independent RBAC layer, directly attacked:** mocked `parse_plan()` to return a plan referencing `file_id=10` (bypassing the manifest/parsing-level filter entirely, simulating a hallucinated plan) and called `run_agent_query()` for real against the non-admin user. The execution-time `rbac.can_view_file()` re-check independently caught and skipped it (`steps: []`, correctly fell back) — proving this isn't a single point of failure; two independent checks both have to be bypassed to leak anything.
- Confirmed all four scenarios above were correctly written to the audit log with accurate step counts (`0`, `1`, `1`, `2`) as `resource_id`.
- Browser: opened the new Agent tab, asked the same two-tool salary/Redis-port question through the real UI, and confirmed a screenshot shows the correct combined answer plus a "2 step(s) taken" panel with `SQL (FILE #7)` / `RAG` badges, each step's exact sub-question and summary, and a "4 document source(s)" collapsible — matching the API-level test above, rendered correctly end-to-end.

**Status:** ✅ Done and verified.

---

## Live connectors (Google Drive / Slack / etc.) — genuinely blocked

**What:** Not built. Every other "blocked" item in this document (Supabase) still got real scaffolding code that activates the moment credentials are supplied, because a Supabase project's URL + API key are the only things standing between "inactive" and "working." Live connectors are a different kind of blocked: connecting to Google Drive, Slack, or similar requires **registering an OAuth application** in that provider's own developer console (Google Cloud Console, Slack API dashboard, etc.) — a step that produces a `client_id`/`client_secret` tied to a specific Google/Slack account and a specific redirect URI, and requires agreeing to that provider's developer terms. This agent has no account to register an app under, and creating one on the user's behalf without their direct involvement isn't something that can be done safely or, in most cases, at all (many of these consoles require interactive identity verification).

**What scaffolding would look like once the user has credentials** (documented here rather than half-built speculatively): an OAuth authorization-code flow (redirect to provider → callback endpoint exchanges the code for tokens → tokens stored per-user, encrypted, in a new table) feeding a per-provider sync job that pulls documents/messages into the existing RAG ingestion pipeline (`rag.service.index_document`) the same way an uploaded file does today — the ingestion side of this app is already provider-agnostic, so a connector's real work is entirely the OAuth handshake and the provider-specific "list files"/"list messages" API calls, not a new retrieval or RBAC model.

**To unblock:** the user would need to (1) register an OAuth app in the target provider's developer console, (2) set a redirect URI pointing at this app, (3) supply the resulting `client_id`/`client_secret` via `.env`, at which point this becomes a buildable, testable feature the same way Supabase was.

**Status:** ❌ Not started — genuinely blocked on user-provided OAuth app credentials, not attempted.

---

Table of contents (updated as features land below):
- [x] Liquid glass UI effect
- [x] Conversation memory (multi-turn context)
- [x] Feedback signal (👍/👎 on answers)
- [x] Audit logging
- [x] Hover-to-reveal chat sidebar
- [x] Settings tab with privacy features
- [x] Supabase database integration — fully activated and live-tested against a real project
- [x] Hybrid search (keyword + vector)
- [x] Reranking
- [x] Structured data extraction
- [x] API access / external integration docs
- [x] Per-user rate limits / quotas
- [x] Cross-table SQL joins
- [x] Agentic multi-step reasoning (RAG + SQL + web chained automatically)
- [ ] Live connectors (Google Drive/Slack/etc.) — **blocked**, needs OAuth app credentials only the user can create; see the entry above

---

## API access / external integration docs

**What:** `API_ACCESS.md` (new file, repo root) — a guide for any external script/service consuming this API directly, not through the web UI: auth flow, RBAC model, every endpoint group (files, RAG, feedback, Text-to-SQL, audit) with example `curl` calls, and error-code conventions. Also confirmed FastAPI's auto-generated `/docs` (Swagger UI) and `/redoc` already work out of the box for interactive exploration and typed-client generation from `/openapi.json` — no extra work needed there, just verified and documented as the entry point.

**Source:** Own design/writing, but every example command was actually run against the live app during this session rather than written from memory or guessed at.

**Implementation:**
- `API_ACCESS.md` covers: bearer-token auth (`/auth/register`, `/auth/login`, token expiry), the RBAC model (roles × scopes, enforced at the query level not just the UI), file upload/list/download/delete, all three RAG query endpoints (with `history`/`allow_web_search` shapes), feedback submission and admin-only listing, the full Text-to-SQL flow (upload → schema → query, with a note on the authorizer sandbox), the audit/activity endpoint (self-scoped for regular users, full access for admins), and standard error codes including the deliberate 404-not-403 on RBAC-denied files (avoids confirming a hidden file's existence to someone who can't see it).
- Along the way, **exercised two endpoint groups that had never been tested live this session**: uploaded and ingested two real CSVs (`employees.csv` → `t_7`, `secrets.csv` → `t_8`) to test `/sql/datasets/{id}/schema` and `/sql/datasets/{id}/query` for the first time, and used the second dataset to run a real adversarial cross-table `UNION` attack against the SQL authorizer sandbox — closing a gap flagged (but left unverified) in the Audit Logging entry above, where the `sql_query_blocked` audit action had only been code-reviewed, not exercised live.

**Tested:**
- Every `curl` example in `API_ACCESS.md` was run against the live server and its real response shape captured, not invented — including a fresh non-admin account registered specifically to verify two access-control claims live: `GET /rag/feedback` correctly `403`s for a non-admin, and `GET /audit` correctly `200`s for a non-admin (self-scoped to their own rows, per the Settings-tab entry above).
- Verified the 404-vs-403 RBAC claim directly against the route code (`record is None or not can_view_file(...)` → `404`, consistently across `GET /files/{id}`, download, and delete).
- The cross-table `UNION` attack (`SELECT id, name FROM t_7 UNION SELECT id, api_key FROM t_8`) was run directly against `query_executor.execute_readonly()` and confirmed blocked with `access to t_8.id is prohibited` — a genuine per-table authorizer denial between two tables that both really exist in the same `tabular.db`, not a missing-table coincidence.
- Confirmed `/docs`, `/redoc`, and `/openapi.json` all return `200` on the live server.

**Status:** ✅ Done and verified.

---

## Theme switcher (light / dark / auto)

**What:** A 3-way segmented control in the header, next to Sign Out, letting the user pick Light / Dark / Match system. Persists across sessions and applies before first paint (no flash of the wrong theme). This app previously had no light theme at all — it was unconditionally dark — so this required actually building a real light palette, not just a toggle.

**Source:** Interaction pattern (segmented radio control, sliding pill positioned via `:has()`) adapted from freefrontend.com/css-liquid-glass/'s "Liquid Glass Theme Switcher" (fooontic/pen/KwpRaGr), pulled from the live CodePen source. Its own distortion filter (a large precomputed displacement-map image baked for one exact pill size) wasn't reusable at a different size, so the switcher initially borrowed the procedural SVG filter built for the Chats sidebar instead — later removed from both, see the Liquid-glass bleed fix entry below.

**Implementation:**
- `static/style.css` — `:root[data-theme="light"]` block defining a full light palette (`--bg`, `--surface`, `--surface-2`, `--border`, `--text`, `--text-dim`, `--accent`, `--accent-dim`, `--danger`); the existing `:root` dark values stay the unconditional baseline. Every component already reads color exclusively through these custom properties, so this one block re-themes the whole app.
- `index.html` — inline, render-blocking `<script>` in `<head>` that resolves the stored choice (localStorage `theme_v1`) against `matchMedia` for "auto" and stamps `data-theme` on `<html>` before first paint.
- `static/app.js` — `initThemeSwitcher()` wires the three radio inputs, persists changes, and listens for system preference changes to live-update an "auto" selection.
- `color-scheme: dark` / `color-scheme: light` set per theme — otherwise native form controls (checkboxes, etc.) always render in OS-default light chrome regardless of the page theme (this is what caused the stark-white Settings checkbox reported by the user; see below).

**Tested:**
- Clicked all three options live; confirmed via `getComputedStyle`/`localStorage` that each correctly sets `data-theme` and persists.
- Confirmed the *entire app* re-themes correctly on a single variable swap — screenshotted the file list, buttons, and status pills in light mode, not just the header.
- Confirmed "auto" resolves against a forced `prefers-color-scheme: light` emulation and updates live on a simulated system preference change.

**Status:** ✅ Done and verified.

---

## Web search toggle (liquid switch)

**What:** A pill-shaped toggle switch (🌐 icon thumb) in both the Chat and Agent tabs' input rows, controlling the same "include web search in answers" setting as the Settings tab checkbox — all three now stay in sync with each other, not just with storage.

**Source:** Interaction/shape adapted from freefrontend.com/css-liquid-glass/'s "Liquid Toggle Switch" (jh3y/pen/bNVWoBW). The source drives its liquid blob-merge animation with GSAP Draggable + dynamic `feGaussianBlur`/`feColorMatrix` — a physics-drag interaction that doesn't fit a simple click-to-toggle control, and would mean a ~70KB animation dependency for one switch. Rebuilt as CSS-only: same pill/thumb shape and sliding motion, the same liquid-glass effect/tint/shine layering used elsewhere in this app, and a squash-and-stretch keyframe on the thumb at the moment of toggling in place of real physics. Deliberately built **without** the SVG distortion filter from the start (unlike the sidebar/switcher at the time) — already suspected that filter of causing the rendering issues that were later confirmed.

**Implementation:**
- `static/index.html` — the toggle markup duplicated into `#chat-form` and `#agent-form`, each input tagged `data-web-search-toggle`.
- `static/style.css` — `.web-search-toggle__track`/`__thumb`, sliding via `translate` on the checked sibling selector, `contain: paint` (see below).
- `static/app.js` — `getAllWebSearchToggleInputs()`/`initWebSearchToggles()`: every toggle instance (both chat-input toggles + the Settings checkbox) is initialized from and kept in sync with `getAllowWebSearch()`, so flipping any one immediately updates the others without a reload.

**Tested:**
- Clicked the chat-tab toggle live; confirmed via JS that all three inputs (chat, agent, settings) and `localStorage` updated together.
- Confirmed the visual ON/OFF states (thumb position, track tint) render correctly.

**Status:** ✅ Done and verified.

---

## Bug: liquid-glass effect bleeding onto unrelated page regions on hover

**What happened:** After the theme switcher and web-search toggle shipped (both initially sharing the sidebar's SVG distortion filter, or backdrop-filter alone), the user reported — across several messages, with screenshots and one annotated with circles — that hovering almost anything (the nav tabs, "Ask a dataset (SQL)" specifically called out, "Agent," "Settings") caused the glass effect to visibly bleed onto distant, unrelated regions: the file list at the bottom of the left sidebar, the collapsed Chats icon at the top. One screenshot showed a genuine stray colored artifact next to the Chats icon.

**Investigation:**
1. First hypothesis: layout overlap. Checked `getBoundingClientRect()` on the sidebar's glass layers during a real hover — all correctly bounded within their own element, not overlapping the neighboring file panel. Ruled out.
2. Second hypothesis, confirmed and fixed: animating `width` directly on the same element carrying `backdrop-filter` + the SVG filter forces the filter to recompute every frame of the transition. Restructured the Chats sidebar into an outer plain clipping box (`.chat-sidebar`, animates `width`, no filter) wrapping an inner box (`.chat-sidebar-inner`) that stays a constant 220px and never resizes — only gets clipped by its parent. This alone didn't fully resolve the user's later reports, but is a real, independently-justified fix (kept).
3. Third hypothesis, confirmed and fixed: one `<filter>` element shared by two independently-animated targets (sidebar width transition, switcher's sliding pill) caused Chromium's filter/backdrop-filter compositing to glitch on hover near *either* one. Split into two separately-`id`'d filter instances. Still didn't fully resolve it per the user's continued reports (now specifically implicating the top nav tabs, which have zero glass/filter CSS of their own).
4. Final diagnosis: a broader, known Chromium characteristic, not a logic bug — pages with several simultaneously-live `backdrop-filter` elements (this app has many: `.glass` on the header/panels/login card/modal, the sidebar, the theme switcher, both web-search toggles) can force the browser to recomposite far more of the page than expected whenever *anything* nearby repaints, including a plain color transition on an unrelated tab button. The elaborate SVG filter chain (`feTurbulence` → `feSpecularLighting` → `feDisplacementMap`) made this measurably worse and was the most likely source of the one genuine stray-artifact screenshot.

**Fix:** Removed the SVG distortion filter from both remaining users (Chats sidebar, theme switcher) — both now use the same plain `backdrop-filter`-only approach already proven stable in `.glass` and the web-search toggle. Added `contain: paint` to every glass/backdrop-filter container (`.glass`, `.chat-sidebar-inner`, `.theme-switcher`, `.web-search-toggle__track`) as defense-in-depth, isolating each one's paint from the rest of the page regardless of the filter question. Deleted the now-unused SVG `<filter>` definitions from `index.html` entirely rather than leaving dead code.

**Tested:**
- Re-ran the exact scenario from the user's report: hovered "Ask a dataset (SQL)" and screenshotted the (now-collapsed, unfocused) Chats icon and file list simultaneously — clean, no artifact.
- Swept hover across all four nav tabs (Chat, SQL, Agent, Settings) individually — clean in each case.
- Re-confirmed the sidebar's hover-expand, click-through, and collapse-on-blur mechanics all still work correctly after the structural change (unaffected by the filter removal, which was CSS-only).
- **Honest caveat:** this session's automated browser testing could not visually reproduce the original bug in static screenshots even before this fix (the artifact may be a transient compositing flicker more visible to a continuously-watching human eye than a discrete screenshot can capture) — so "clean in my screenshots" is necessarily weaker evidence here than the live-data verification used elsewhere in this document. The fix is based on a decisive, well-reasoned engineering diagnosis (three consecutive, independent, increasingly-specific user reports all pointing at the same category of cause) rather than a screenshot-confirmed before/after. Flagged clearly rather than overclaiming a fix that hasn't been confirmed by the person who could actually see the bug.

**Status:** ✅ Fix applied and re-tested as thoroughly as this session's tooling allows; **awaiting the user's own confirmation** that it's resolved on their end (a hard-refresh may be needed to bypass any already-loaded stale CSS/JS in a tab opened before this fix shipped).

---

## Bug: native OS tooltip and unstyled checkbox clashing with the theme

**What:** Two smaller, related theme-consistency bugs the user caught via screenshot: (1) the Settings tab's "Include web search" checkbox rendered as a stark, unstyled white square regardless of the app's dark theme; (2) hovering the collapsed Chats icon showed the browser's native `title`-attribute tooltip, OS-styled (light background, hard rectangular border) and visibly foreign against the app's chrome.

**Root cause and fix:**
1. Native form controls (checkboxes, etc.) only respect a page's dark styling if the page declares `color-scheme` — without it, they always render in OS-default light chrome. Added `color-scheme: dark` / `color-scheme: light` to the corresponding theme blocks (this only became visible/relevant once a real light/dark theme system existed to expose the mismatch).
2. Native title-attribute tooltips can't be restyled via CSS at all, cross-browser. Removed `title="Chats"` from the Chats sidebar, replaced with `aria-label="Chats"` (keeps the accessible name for screen readers). Considered building a custom-styled replacement tooltip, but the sidebar already fully expands (revealing real content) within ~220ms of the same hover/focus that would trigger a tooltip — concluded a tooltip would be redundant rather than helpful, so none was added back.

**Tested:** Screenshotted the Settings checkbox before/after in dark mode — before: stark white square; after: themed dark checkbox with a visible checkmark when checked. Confirmed via JS that `.chat-sidebar`'s `title` attribute is gone and `aria-label` is set.

**Status:** ✅ Done and verified.

---

## MARX (education mode)

**What:** A distinct tutor persona and answer flow, per the user's request: *"Add mode for education Named 'MARX' WHICH IS completely stick to the Pdfs student may give and also if something is not present inside the Pdf the rag can web-search and use that."* A new "MARX" tab, own chat log, own endpoint (`POST /rag/marx/query`). Two things distinguish it from the main Chat tab, both deliberate:
1. **Persona:** MARX explains like a tutor (defines terms, says *why* something's true when the material supports it), not a generic document-QA responder.
2. **No silent fallback to raw parametric knowledge.** The main chat flow's last resort is the model's own general knowledge, clearly labeled but still ungrounded. MARX never does this — if the student's documents don't cover it, it tries the web (clearly announcing the switch); if neither covers it, it says so plainly (`source: "insufficient"`) rather than answering from memory. A tutor silently mixing in unstated outside knowledge is bad pedagogy — the student can't tell what they're responsible for knowing vs. what MARX added.

**Source:** Own design.

**Implementation:**
- `app/modules/rag/generation.py` — `_MARX_DOCUMENT_PROMPT_TEMPLATE` / `_MARX_WEB_PROMPT_TEMPLATE` and their `build_marx_document_prompt()`/`build_marx_web_prompt()` builders. Reuses the existing `INSUFFICIENT_CONTEXT_SENTINEL`/`is_insufficient()` machinery unchanged.
- `app/modules/rag/service.py` — `answer_marx_query()` and `_marx_web_or_insufficient()`: a **separate** small fallback chain from the main `_answer_or_fallback()`/`_web_or_general_fallback()` pair, built from the same primitives (`_search`, `_answer_from_web`'s pattern) rather than a flag on the existing one — sharing the main chain's tail would silently reintroduce the exact ungrounded-fallback behavior MARX exists to avoid.
- `app/modules/rag/schemas.py` — `AnswerSource` extended with a fourth value, `"insufficient"` (MARX-only; the main flow never produces it).
- `app/modules/rag/routes.py` — `POST /rag/marx/query`, same rate-limit bucket and audit-logging pattern (`action="marx_query"`) as the other RAG endpoints.
- `static/index.html`/`app.js`/`style.css` — a fourth top-level tab, "MARX", reusing `renderAnswerInto()` (unchanged) for rendering — including a new `.answer-source-badge.insufficient` (🚫) badge added there for the new source value. Own web-search liquid toggle in its input row, synced with every other instance via the existing shared toggle wiring (no MARX-specific JS needed for that).

**Tested — live, three real scenarios, not mocked:**
- **Document-grounded:** *"What is the default Redis port and what data structures does it support?"* → answered correctly from `Redis.pdf` with the tutor explanatory style (e.g., table of data structures with a "why it's useful" column), `source: "documents"`.
- **Web-fallback attempted, initially landed on "insufficient" — investigated, not just accepted:** *"What year was the Eiffel Tower built?"* → not in any indexed document, so MARX tried the web. Directly confirmed via `app.core.web_search.search_web()` that DuckDuckGo returned zero results for this exact query, so MARX correctly fell through to `source: "insufficient"`. This led to a real fix — see the "Web search reliability" entry below — after which the same class of question correctly resolves to `source: "web"` instead.
- **The key distinguishing behavior, proven by direct side-by-side comparison:** ran the *identical* Eiffel Tower question through the regular `/rag/query` endpoint under the same conditions (before the web-search fix) — it correctly answered "1889" from `source: "general_knowledge"` (the main flow's designed last resort). MARX, given the exact same unavailable-web situation, correctly refused instead. This is the one behavior MARX was built to have and the main chat was deliberately built not to — confirmed with a real, live, matched comparison, not just each path tested in isolation.
- Browser: opened the MARX tab, asked the Redis question through the real UI — confirmed a screenshot shows the full formatted tutor answer with sources and the feedback row. Asked a real, live, user-typed question ("in which year efiele tower was made", typo included) — confirmed a screenshot shows the correct `🌐 From the web` badge, a properly source-announcing answer ("I'm realizing that your course material probably didn't cover... I'm pulling the answer straight from a reliable web source instead"), the correct 1887–1889 date, and the cited Wikipedia snippet.

**Status:** ✅ Done and verified.

---

## Web search reliability (query rewriting + Instant Answer API)

**What happened:** After MARX shipped, the user tested it live with a real, slightly-misspelled question ("in which year efiele tower was made") and got `source: "insufficient"` — MARX correctly refusing to guess, but only because the web-search tier genuinely wasn't working, which defeats the point of having it.

**Investigation:** Fetched the raw DuckDuckGo HTML-scrape response directly rather than assuming the cause. Confirmed it: an HTTP `202` response body containing an `anomaly.js` challenge script — a real, deliberate bot-detection mechanism, not a transient glitch. **This app does not attempt to defeat it** (no headless-browser JS execution, no fingerprint spoofing, no proxying) — consistent with this session's standing rule against bypassing bot detection. Instead, found and integrated a legitimate alternative: DuckDuckGo's Instant Answer API (`api.duckduckgo.com`), a real documented JSON API meant for exactly this kind of programmatic use, not a scrape of a page meant for browsers. Direct testing showed it works well for bare entity names ("Eiffel Tower" → a real Wikipedia-sourced abstract) but returns nothing for fuller phrasing ("eiffel tower built year" → empty) — a near-exact topic-lookup, not full-text search, which is why the raw misspelled question still failed even once the API was wired in.

**Fix:**
- `app/core/web_search.py` — added `_instant_answer()` (the new API) and renamed the old function to `_html_search()`; `search_web()` now takes an optional `topic` hint and tries, in order: Instant Answer with the topic, Instant Answer with the full query, then the HTML scrape — three complementary attempts instead of one fragile one.
- `app/modules/rag/generation.py` — `rewrite_search_query()`: one LLM call that turns a raw (possibly misspelled, verbosely-phrased) question into both a bare topic name (for the Instant Answer API's near-exact matching) and a cleaner search query (for the HTML scrape) — standard query-rewriting-for-retrieval practice, the same thing a person does instinctively when they type a search query instead of pasting their whole question, not an attempt to work around anything.
- `app/modules/rag/service.py` — both web-search call sites (`_answer_from_web`, used by the main chat/Agent; `_marx_web_or_insufficient`, MARX's own) now call `rewrite_search_query()` before `search_web()`. Fixing it at this shared layer means the main chat and Agent tab benefit too, not just MARX.

**Tested:**
- Reproduced the exact failure first: confirmed directly that the DuckDuckGo HTML endpoint returns the `anomaly.js` challenge for a real query, and that the Instant Answer API returns nothing for the natural phrasing but a real abstract for the bare entity name alone.
- Unit-level: `rewrite_search_query("in which year efiele tower was made")` → `("Eiffel Tower", "Eiffel Tower construction year")`, both typo-corrected and shaped for their respective consumers.
- End-to-end, the exact real user query, through the real `/rag/marx/query` endpoint: now resolves to `source: "web"` with a real Wikipedia-sourced answer, instead of `"insufficient"`.
- Browser: re-asked the identical question (typo included) through the live MARX tab — screenshot confirms the correct badge, source-announcing tutor answer, correct date, and cited snippet.

**Status:** ✅ Done and verified. Residual limitation, stated plainly: the Instant Answer API's coverage is inconsistent (works well for well-known encyclopedia-style topics, poor for narrow or highly specific factual questions) and the HTML-scrape path remains blocked by DuckDuckGo's bot detection as a matter of policy on this app's part, not a bug — so web search is meaningfully more reliable now, not universally reliable. A question genuinely outside both the user's documents and Instant-Answer-API coverage will still correctly land on `general_knowledge` (main chat) or `insufficient` (MARX), which is the honest, intended behavior in that case, not a failure to fix.

---

## Bug: math (LaTeX) rendering broken on non-document answer tiers

**What happened:** Asked a real math question ("Explain the quadratic formula and show the derivation") through the regular Chat tab. It landed on `source: "web"` and came back with LaTeX wrapped in `\[...\]`/`\(...\)` delimiters instead of `$$...$$`/`$...$` — `static/app.js`'s `renderMarkdown()` only recognized the dollar-sign style, so this would have rendered as broken raw text with visible backslashes instead of a formula.

**Root cause:** The `$$`/`$`-delimiter instruction existed on only **one** of five prompt templates (`_PROMPT_TEMPLATE`, the document-grounded one) — never copied to `_FALLBACK_PROMPT_TEMPLATE` (general knowledge), `_WEB_PROMPT_TEMPLATE`, or either MARX prompt. A math question answered via any of those other four tiers got no delimiter instruction at all, so the model fell back to its own default LaTeX style. Found by testing a real question end-to-end and inspecting the raw answer text, not by reading the prompt code and assuming it was shared.

**Fix, two layers (both real, not redundant):**
1. Pulled the instruction into one shared `_LATEX_INSTRUCTIONS` constant and interpolated it into all five templates, so this can't silently drift out of sync again the way it did the first time. Also strengthened the wording to explicitly say never `\[...\]`/`\(...\)`.
2. **Even with the fix, live re-testing showed the model still sometimes uses `\[...\]`/`\(...\)` regardless of the instruction** (an LLM formatting-instruction-adherence issue, not a prompt bug — confirmed by re-running the identical question after the prompt fix and seeing the same delimiter style in the raw response). So `static/app.js`'s `renderMarkdown()` was also given defense-in-depth: it now recognizes `\[...\]` and `\(...\)` as additional display/inline math delimiters, alongside `$$...$$`/`$...$`, regardless of which tier answered. Two independent layers because the first one alone was empirically shown not to be sufficient.

**Tested:**
- Reproduced the original break: confirmed the raw API response for a real math question contained `\[` / `\(` delimiters, not `$`.
- After both fixes: re-ran the identical question through the live Chat UI (topic-picker path, "Select all" → "Get answer") and confirmed via screenshot that the quadratic formula, the completing-the-square derivation steps, and the discriminant cases all render as real typeset math — fraction bars, square root symbols, superscripts, and the Δ symbol all correctly rendered by KaTeX, not raw backslash-LaTeX text — even though the raw model output still used `\[...\]`, proving the frontend fallback (not just the prompt instruction) is what's actually carrying this.

**Status:** ✅ Done and verified.

---

## Diagram generation (Mermaid) + scoping "images" out of "images and diagram generations"

**What:** In response to *"check marks for mathematical questions and some images and diagram generations too and then test the agent tab too and SQL dataset,"* checked math rendering (already covered above), then added diagram support. Scoped "images and diagram generations" down to **diagrams only**, deliberately: this app's model stack is Ollama running text/vision-input models, with no image-*output* (diffusion) model configured anywhere in the pipeline — there is no component that could generate a picture even if asked. A Mermaid-rendered flowchart is the closest genuinely-supportable interpretation of "help explain something visually," so that's what was built; true image generation was not attempted or faked. (Note: the *existing* vision pipeline, `generate_vision()` in `app/core/ollama_client.py`, already lets the app read images inside uploaded documents via OCR/vision extraction — that's a separate, already-built capability, not new, and not what "generation" was asking for.)

**Implementation:**
- Vendored `mermaid` locally (`static/vendor/mermaid/mermaid.esm.min.mjs`, 30KB, plus its 103 lazy-loaded per-diagram-type chunk files, ~3.6MB, under `static/vendor/mermaid/chunks/mermaid.esm.min/`) rather than pulling from a CDN, consistent with this app's fully-local/offline-capable stack (Ollama, local KaTeX, etc.).
- `static/index.html` — a `<script type="module">` loads the vendored ESM bundle, initializes it (`theme: "dark"`, `securityLevel: "strict"`), and exposes it as `window.mermaid`, dispatching a `mermaid-ready` event for the classic-script `app.js` to pick up whenever it finishes loading.
- `static/app.js`'s `renderMarkdown()` — extracts ` ```mermaid ` fenced blocks *before* HTML-escaping (same raw-content placeholder pattern already used for math blocks), and substitutes them back in as `<div class="mermaid">${escapeHtml(...)}</div>` — escaped like any other LLM-sourced text for the security invariant, then read back via `.textContent` (which the browser auto-decodes) at render time rather than trusting raw HTML.
- New `renderMermaidIn(container)` helper calls `window.mermaid.run(...)` on any `.mermaid` divs in a container, waiting on `mermaid-ready` first if the module hasn't finished loading yet. Wired into all four `innerHTML = renderMarkdown(...)` call sites: the file-summary modal, `renderAnswerInto()` (Chat/MARX/topic-picker), the SQL result handler, and `renderAgentAnswer()` — so a diagram renders correctly regardless of which tab produced it.
- `app/modules/rag/generation.py` — new `_MERMAID_INSTRUCTIONS` constant (kept separate from `_LATEX_INSTRUCTIONS`, not merged) telling the model it *may* include a ```mermaid flowchart when it would genuinely help explain a process/relationship, with a worked example and an explicit "don't add one for simple factual answers" guardrail. Wired into `_PROMPT_TEMPLATE` (document-grounded chat) and `_MARX_DOCUMENT_PROMPT_TEMPLATE` (MARX) — the two tiers where a student/user is asking about material likely to contain explainable processes. Deliberately *not* added to the general-knowledge/web/MARX-web tiers, where an unsolicited diagram is more likely to be noise than help.

**Tested — live, through the real UI, not just `node --check`:**
- Restarted the uvicorn server to pick up the new prompt instructions (verified via `Get-CimInstance Win32_Process` that the old process pair was stopped and a fresh one came up, confirmed reachable at `/docs`).
- Asked MARX, through the live browser, *"Explain the water cycle and show a flowchart diagram of the process"* — confirmed via screenshot that the response contains a real rendered SVG flowchart (boxes and connecting arrows for evaporation → condensation → precipitation → runoff/infiltration → return to ocean), not raw ```mermaid text, sitting above a normal prose explanation and the usual web-source citation footer.

**Status:** ✅ Done and verified.

---

## Bug: Mermaid diagrams broke (ugly red error SVG) on invalid model-generated syntax, plus topic-picker verification

**What happened:** User asked to also check the topic-picker view with a mermaid diagram. Re-tested with *"Explain how Redis persistence works (RDB vs AOF) and show a flowchart comparing the two processes"* — this one landed directly on the document-grounded answer (not the topic-picker; Redis.pdf matched confidently enough not to trigger it), but surfaced a real bug: the model's mermaid block used unquoted punctuation inside a node label -- `H[File sync policy (always/everysec/no)]` -- which is invalid Mermaid grammar (parentheses/slashes inside an unquoted `[...]` label break its parser). By default, `mermaid.run()` doesn't propagate that as a rejected promise; it silently swallows the parse error internally and draws mermaid's own built-in red "Syntax error in text" diagram in place, which is what the user saw rendered.

**Fix, two layers (same pattern as the earlier LaTeX-delimiter bug):**
1. **Prompt:** extended `_MERMAID_INSTRUCTIONS` in `app/modules/rag/generation.py` with an explicit rule and worked example: node labels containing punctuation like parentheses, slashes, or colons must be wrapped in double quotes (`C["File sync policy (always/everysec/no)"]`, never `C[File sync policy (always/everysec/no)]`).
2. **Frontend, load-bearing (confirmed by re-testing — the model repeated the exact same mistake even after the prompt fix, the same instruction-adherence limitation seen with the LaTeX bug):**
   - `static/index.html` — added `suppressErrorRendering: true` to `mermaid.initialize()`, which makes a parse failure reject the `run()` promise instead of silently drawing mermaid's own broken-looking error diagram.
   - `static/app.js`'s `renderMermaidIn()` — now catches that rejection and, for any `.mermaid` node that didn't end up with a rendered `<svg>`, replaces it with a plain-language warning ("⚠️ Couldn't render this diagram (invalid syntax) -- showing the raw source instead:") plus a `<pre>` of the original Mermaid source, styled via new `.mermaid-error`/`.mermaid-error-note` CSS -- a readable degradation instead of a broken red diagram.
   - **A real follow-up bug caught before shipping:** the first version of this fix read each node's fallback source (`node.textContent`) *after* `run()` had already rejected -- but mermaid's own cleanup path clears a failed node's content as part of unwinding when `suppressErrorRendering` is set, so by the time the `.catch()`/`.finally()` ran, the source was already gone (empirically confirmed: `preText` came back empty in a synthetic test). Fixed by capturing every node's source into a `Map` *before* calling `run()`, and reading from that map in the fallback instead of re-reading the (by-then-cleared) DOM.

**Tested:**
- Reproduced the original failure live (screenshot showing mermaid's own red "Syntax error in text" box) before either fix.
- After the fix: re-asked the identical question live — model made the same syntax mistake again (proving layer 1, the prompt fix, isn't sufficient alone, exactly as with the LaTeX bug), but this time the page showed the clean fallback warning + raw source instead of a broken diagram.
- Caught and fixed the content-loss follow-up bug via a synthetic in-browser test (constructing a `.mermaid` node with deliberately invalid syntax, calling `renderMermaidIn()` directly, and asserting on the resulting DOM) rather than relying on the LLM to reproduce the exact same mistake a third time.
- Regression-checked with a synthetic *valid* diagram through the same `renderMermaidIn()` path afterward — confirmed it still renders as a real `<svg>`, not routed through the error fallback.
- **Topic-picker view, specifically, with a real multi-diagram answer:** asked *"Compare and contrast the architectures described in the documents, and show a diagram of how they differ"* — broad enough to spread across `Redis.pdf`, `TensorFlow.pdf`, and the RAG-pipeline PDF, which correctly triggered the topic-picker checklist (not a direct answer) instead of the single-document path used in the tests above. Selected "Select all" → "Get answer" and confirmed live: the resulting answer (rendered through `renderTopicPicker()`'s "Get answer" flow, a different call site than the two tested earlier) contained **three** Mermaid diagrams -- the RDB one rendered as a real SVG flowchart, while the AOF and Hybrid ones both hit the same unquoted-punctuation mistake and correctly fell back to the readable warning + raw source, each independently (one node's failure didn't affect the sibling that rendered fine), with the rest of the answer (comparison table, prose, feedback row) unaffected either way.

**Status:** ✅ Done and verified. Residual limitation, stated plainly (same as the LaTeX case): the model will still sometimes produce invalid Mermaid syntax despite the prompt instruction — the frontend fallback exists specifically because that can't be fully prevented at the prompt level, not because the prompt fix is expected to be sufficient on its own.

---

## Agent tab + SQL dataset tab — live re-verification

**What:** Same user request as above also asked to re-test the Agent tab and the SQL dataset tab specifically (not new features — both were built and tested in an earlier session — this was a fresh live pass to confirm they still work after this session's other changes).

**Tested — live, through the real UI:**
- **Agent tab:** asked *"How many employees are in each department?"* — screenshot confirms it planned, ran one step (`SQL (FILE #7)`, the actual generated `SELECT department, COUNT(*) AS count FROM employees GROUP BY department` query shown inline), and rendered a correct 3-row grouped table (Engineering: 3, Marketing: 1, Sales: 1).
- **SQL dataset tab:** multi-selected `departments.csv` + `secrets.csv` + `employees.csv` (ctrl-click multi-select) and asked *"List each employee's name along with their department name"* — screenshot confirms a correct join result rendered as a clean "Employee ↔ Department List" table plus the raw SQL query (`SELECT name, department FROM t_7`) and its result table underneath, all 5 employees correctly matched to their departments.

**Status:** ✅ Done and verified — no regressions found in either tab.
