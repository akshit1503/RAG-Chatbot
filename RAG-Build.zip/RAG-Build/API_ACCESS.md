# API Access Guide

This app is a plain FastAPI backend — anything the web UI does, an external
script or service can do too, over the same REST API. Every example below
was actually run against a live instance of this app during development
(not hand-written from memory), so the shapes are real.

## Interactive docs

FastAPI auto-generates full interactive API documentation from the code —
no separate doc-writing to keep in sync:

- **Swagger UI:** `GET /docs` — try requests directly in the browser
- **ReDoc:** `GET /redoc` — read-only reference view
- **Raw OpenAPI schema:** `GET /openapi.json` — for generating a typed client

## Authentication

All endpoints except `/health*`, `/auth/register`, and `/auth/login` require
a JWT bearer token.

```bash
# Register (self-service accounts always start at the base "user" role;
# promotion to operator/admin requires an existing admin via POST /users)
curl -X POST http://localhost:8000/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username": "svc-account", "password": "a-strong-password", "department": "engineering"}'

# Log in (OAuth2 password flow -- form-encoded, not JSON)
curl -X POST http://localhost:8000/auth/login \
  -d "username=svc-account&password=a-strong-password"
# -> {"access_token": "eyJhbGci...", "token_type": "bearer"}

# Use the token on every subsequent request
TOKEN="eyJhbGci..."
curl http://localhost:8000/auth/me -H "Authorization: Bearer $TOKEN"
```

Tokens expire after `JWT_ACCESS_TOKEN_EXPIRE_MINUTES` (default 60) — see
`.env.example`. There's no refresh-token endpoint; re-authenticate with
`/auth/login` when a token expires (a `401` on any request means this).

## Roles and scopes (RBAC)

Three roles — `user`, `operator`, `admin` — and three file scopes —
`personal`, `departmental`, `global`. A file's scope, not just the
uploader's role, determines who can see it; see `app/modules/file_access/rbac.py`
for the exact matrix. This is enforced at the database/vector-store query
level (a `WHERE`/Chroma metadata filter), not just hidden in the UI — an
API caller gets the same enforcement the web UI does.

## Files

```bash
# Upload (auto-indexes for RAG if it's a document, auto-ingests for
# Text-to-SQL if it's tabular -- see the response's rag_indexed/sql_ingested)
curl -X POST http://localhost:8000/files/upload \
  -H "Authorization: Bearer $TOKEN" \
  -F "scope=global" \
  -F "file=@report.pdf"
# -> {"id": 6, "original_filename": "report.pdf", ..., "rag_indexed": true, "sql_ingested": false}

curl http://localhost:8000/files -H "Authorization: Bearer $TOKEN"
curl http://localhost:8000/files/6/download -H "Authorization: Bearer $TOKEN" -o report.pdf
curl -X DELETE http://localhost:8000/files/6 -H "Authorization: Bearer $TOKEN"
```

There is no file-size or page-count cap by default (`MAX_UPLOAD_SIZE_MB` /
`MAX_OCR_PAGES` are both `0` = unlimited out of the box; set them in `.env`
to add a limit).

## RAG (document Q&A)

Three query endpoints, all accepting an optional `history` (recent chat
turns, for follow-up questions) and `allow_web_search` (per-request privacy
opt-out of the web-search fallback tier):

```bash
# Ask directly -- always returns an answer (falls through documents -> web
# -> general knowledge; check the "source" field to see which tier answered)
curl -X POST http://localhost:8000/rag/query \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"query": "What is the default Redis port?"}'
# -> {"answer": "...", "sources": [...], "web_sources": [], "source": "documents"}

# Ask ambiguously -- returns either a direct answer (single dominant source)
# or a list of topics to disambiguate between
curl -X POST http://localhost:8000/rag/topics \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"query": "Tell me about Redis"}'
# -> {"query": "...", "topics": [], "direct_answer": {"answer": "...", ...}}
# or -> {"query": "...", "topics": [{"topic_id": "6:0", "label": "...", ...}], "direct_answer": null}

# Answer from specific topic_ids returned by /rag/topics
curl -X POST http://localhost:8000/rag/query/from-topics \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"query": "Tell me about Redis", "topic_ids": ["6:0", "6:1"]}'
```

`history` shape: `[{"role": "user", "content": "..."}, {"role": "assistant", "content": "..."}]`.
`source` in every response is one of `documents`, `web`, `general_knowledge`
— always check it before presenting an answer as document-grounded.

## MARX (education mode)

A separate tutor persona at `POST /rag/marx/query`, same request/response
shape as `/rag/query`. Two differences from the main chat endpoint: it
explains like a tutor rather than answering like a generic document-QA
bot, and it **never** falls back to the model's raw general knowledge —
only your documents, or a web search that's explicitly labeled as such. If
neither covers the question, `source` comes back as `"insufficient"`
instead of guessing:

```bash
curl -X POST http://localhost:8000/rag/marx/query \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"query": "What eviction policies does Redis support?"}'
# -> {"answer": "...", "sources": [...], "web_sources": [], "source": "documents"}

curl -X POST http://localhost:8000/rag/marx/query \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"query": "something in neither your documents nor findable on the web"}'
# -> {"answer": "I couldn't find this in your course material or the web...", "source": "insufficient"}
```

## Agent (automatic multi-tool reasoning)

For a question that might need documents, a dataset, and/or the web
together, `/agent/query` plans and runs the needed tool calls itself
instead of you picking an endpoint:

```bash
curl -X POST http://localhost:8000/agent/query \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"query": "What is the average employee salary, and separately, what port does Redis use by default?"}'
# -> {"answer": "- Average employee salary: $85,600\n- Default Redis port: 6379",
#     "steps": [
#       {"tool": "sql", "file_id": 7, "question": "...", "summary": "..."},
#       {"tool": "rag", "file_id": null, "question": "...", "summary": "..."}
#     ], "sources": [...], "web_sources": [...]}
```

`steps` shows exactly which tools ran and on what sub-question — always
check it if you need to know where an answer actually came from. Only
datasets/documents visible to your account can ever appear in `steps`; a
dataset you can't see is invisible to the planner, not just filtered from
the display. Capped at 3 tool calls per question; has its own rate limit
(10/min by default, tighter than the single-tool endpoints since one call
here can trigger several).

## Structured data extraction

Pulls named fields out of a document as JSON, rather than a free-text
answer. Documents only (PDF/DOCX/TXT/MD) — tabular files already have a
real, directly queryable schema via the Text-to-SQL endpoints above.

```bash
curl -X POST http://localhost:8000/utility/documents/6/extract \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"fields": [
        {"name": "default_port", "description": "the default network port Redis listens on"},
        {"name": "data_structures", "description": "list of supported data structure types"}
      ]}'
# -> {"file_id": 6, "filename": "Redis.pdf", "data": {"default_port": 6379, "data_structures": ["Strings", "Lists", "Sets", "Hashes", "Sorted Sets (ZSets)"]}}
```

A field not present in the document comes back as `null`, not a guessed
value or a missing key — every requested field name is always a key in
`data`. `description` per field is optional but recommended: it's the only
disambiguation the model gets for a generic name like `"total"` or
`"date"`.

## Feedback

```bash
curl -X POST http://localhost:8000/rag/feedback \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"question": "Tell me about Redis", "answer": "...", "source": "documents", "rating": "up"}'

# Admins see everyone's feedback; non-admins get a 403 here (there's no
# self-scoped feedback view -- unlike /audit below)
curl http://localhost:8000/rag/feedback -H "Authorization: Bearer $ADMIN_TOKEN"
```

## Text-to-SQL (tabular data Q&A)

```bash
curl -X POST http://localhost:8000/files/upload -H "Authorization: Bearer $TOKEN" \
  -F "scope=global" -F "file=@employees.csv"
# -> {"id": 7, ..., "sql_ingested": true}   (CSV/XLSX auto-ingest on upload)

curl http://localhost:8000/sql/datasets/7/schema -H "Authorization: Bearer $TOKEN"
# -> {"table_name": "t_7", "columns": [...], "row_count": 5, "sample_rows": [...]}

curl -X POST http://localhost:8000/sql/datasets/7/query \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"question": "What is the average salary by department?"}'
# -> {"answer": "...", "sql": "SELECT department, AVG(salary) ... GROUP BY department", "columns": [...], "rows": [...], ...}
```

Generated SQL is sandboxed by a SQLite `set_authorizer` callback that only
allows reading the one table this dataset owns — a query engineered to read
a different table (even via `UNION`) is rejected with `422`, not silently
executed. This is enforced at the database layer, independent of whatever
the LLM was asked to do.

**Joining across datasets:** `/sql/join-query` answers a question that
spans more than one ingested dataset, generating a real SQL `JOIN`:

```bash
curl -X POST http://localhost:8000/sql/join-query \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"file_ids": [7, 9], "question": "For each employee, show their name, salary, and their departments manager and budget"}'
# -> {"sql": "SELECT t_7.name, t_7.salary, t_9.manager, t_9.budget FROM t_7 JOIN t_9 ON t_7.department = t_9.department", ...}
```

Every `file_id` is individually RBAC-checked before anything else happens —
listing a `file_id` you can't otherwise see 404s immediately, the same as
the single-dataset endpoints, and never reaches the SQL generator. The
authorizer sandbox above is likewise extended to allow reads only across
the exact set of tables in this request, nothing wider.

## Activity / audit trail

```bash
# Your own activity (logins, file access, queries) -- any authenticated user
curl "http://localhost:8000/audit?limit=25" -H "Authorization: Bearer $TOKEN"

# Admins can see everyone's, optionally filtered
curl "http://localhost:8000/audit?action=login&username=svc-account" -H "Authorization: Bearer $ADMIN_TOKEN"
```

## Rate limits

`/rag/query`, `/rag/topics`, `/rag/query/from-topics` (sharing one quota),
`/sql/datasets/{id}/query` (its own quota), and `/utility/documents/{id}/extract`
(its own quota) are limited to 20 requests/minute per user by default (`RATE_LIMIT_REQUESTS_PER_MINUTE` in
`.env`; `<= 0` disables limiting entirely). Exceeding it returns `429` with
a `Retry-After` header (seconds until the oldest request in your current
window ages out):

```bash
curl -i -X POST http://localhost:8000/rag/query \
  -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" \
  -d '{"query": "..."}'
# on the 21st call within 60s:
# HTTP/1.1 429 Too Many Requests
# retry-after: 43
# {"detail": "Rate limit exceeded. Try again in 43s."}
```

Limits are per-user, in-memory on the server process — one user's usage
never affects another's, and a `sql_query` burst doesn't eat into your
`rag_query` quota or vice versa.

## Errors

Standard HTTP status codes: `401` (missing/expired/invalid token), `403`
(authenticated but not authorized for this resource/action), `404` (not
found or not visible to you — RBAC-filtered, so a file you can't see 404s
rather than 403s, to avoid confirming its existence), `422` (validation
failure, or a SQL query the sandbox rejected), `503` (Ollama unreachable —
retriable once it's back up). Error bodies are `{"detail": "..."}`.
