-- Run this in your Supabase project's SQL editor (Project > SQL Editor > New query)
-- before setting SUPABASE_URL / SUPABASE_KEY in .env. Mirrors the shape of
-- app/core/audit.py's AuditLog and app/modules/rag/models.py's AnswerFeedback,
-- with a `source_id` column linking back to the row's id in the app's own
-- SQLite tables (Supabase is a secondary, queryable mirror -- SQLite/Chroma
-- remain the source of truth; see TechStack.md's "Supabase integration" entry).

create table if not exists audit_log (
    id bigint generated always as identity primary key,
    source_id bigint,
    user_id bigint,
    username text,
    action text not null,
    resource_type text,
    resource_id text,
    detail text,
    created_at timestamptz not null,
    mirrored_at timestamptz not null default now()
);
create index if not exists audit_log_action_idx on audit_log (action);
create index if not exists audit_log_username_idx on audit_log (username);
create index if not exists audit_log_created_at_idx on audit_log (created_at desc);

create table if not exists answer_feedback (
    id bigint generated always as identity primary key,
    source_id bigint,
    user_id bigint,
    question text not null,
    answer text not null,
    source text not null,
    rating text not null check (rating in ('up', 'down')),
    comment text,
    created_at timestamptz not null,
    mirrored_at timestamptz not null default now()
);
create index if not exists answer_feedback_rating_idx on answer_feedback (rating);
create index if not exists answer_feedback_created_at_idx on answer_feedback (created_at desc);

-- Row Level Security: enabled with no policies, so the tables are only
-- reachable via the service-role key (what SUPABASE_KEY should be -- never
-- the anon/public key, since these rows can contain user questions/answers).
alter table audit_log enable row level security;
alter table answer_feedback enable row level security;
