let token = localStorage.getItem("token") || null;
let currentUser = null;
let filesCache = [];
let chatSessions = [];
let currentSessionId = null;

function $(id) {
  return document.getElementById(id);
}

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

// A real bug found by live testing: window.confirm() silently auto-resolves
// to `false` in this app's browser environment WITHOUT ever presenting an
// actual prompt (confirmed directly: `window.confirm("...")` returns false
// immediately, no dialog, no way for a real click to change that) -- so
// every confirm()-gated action (delete-chat, clear-history) looked like it
// simply did nothing, with no error and no feedback. Replaced with this
// custom in-app modal, built from the same .modal/.modal-card styling used
// elsewhere (e.g. the file-summary modal), which never depends on browser
// dialog support at all.
function confirmDialog(message, { confirmLabel = "Delete" } = {}) {
  return new Promise((resolve) => {
    const overlay = el("div", "modal confirm-dialog");
    const card = el("div", "modal-card confirm-dialog-card");
    const body = el("div", "modal-body confirm-dialog-body", message);
    card.appendChild(body);

    const footer = el("div", "confirm-dialog-footer");
    const cancelBtn = el("button", "ghost-btn", "Cancel");
    cancelBtn.type = "button";
    const confirmBtn = el("button", "confirm-dialog-danger-btn", confirmLabel);
    confirmBtn.type = "button";
    footer.appendChild(cancelBtn);
    footer.appendChild(confirmBtn);
    card.appendChild(footer);

    overlay.appendChild(card);
    document.body.appendChild(overlay);

    const finish = (value) => {
      overlay.remove();
      resolve(value);
    };
    cancelBtn.addEventListener("click", () => finish(false));
    confirmBtn.addEventListener("click", () => finish(true));
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) finish(false);
    });
  });
}

// ---------- Theme (light/dark/auto) ----------
// Not scoped per-user like chat sessions/privacy settings -- it's a
// display preference for this browser, applied even on the (shared,
// pre-login) login screen, so it stays in a plain unscoped key.
const THEME_KEY = "theme_v1";

function getStoredThemeChoice() {
  try {
    return localStorage.getItem(THEME_KEY) || "dark";
  } catch (_) {
    return "dark";
  }
}

function setStoredThemeChoice(value) {
  try {
    localStorage.setItem(THEME_KEY, value);
  } catch (_) {
    /* ignore */
  }
}

function systemPrefersLight() {
  return window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches;
}

// Resolves "auto" against the current system preference and stamps the
// result onto <html> -- the index.html inline script already did this
// once before first paint (to avoid a flash of the wrong theme); this is
// what re-applies it after a user change or a system preference flip
// while the page is open.
function applyThemeChoice(choice) {
  const effective = choice === "auto" ? (systemPrefersLight() ? "light" : "dark") : choice;
  document.documentElement.setAttribute("data-theme", effective);
}

function initThemeSwitcher() {
  const inputs = document.querySelectorAll(".theme-switcher__input");
  if (!inputs.length) return;

  const stored = getStoredThemeChoice();
  inputs.forEach((input) => {
    input.checked = input.value === stored;
    input.addEventListener("change", () => {
      if (!input.checked) return;
      setStoredThemeChoice(input.value);
      applyThemeChoice(input.value);
    });
  });

  if (window.matchMedia) {
    window.matchMedia("(prefers-color-scheme: light)").addEventListener("change", () => {
      if (getStoredThemeChoice() === "auto") applyThemeChoice("auto");
    });
  }
}

initThemeSwitcher();

// ---------- Minimal markdown renderer ----------
// Escapes the raw text FIRST, then only the markup this function itself
// inserts becomes real HTML -- so LLM output or document content can never
// inject arbitrary tags, even though we use innerHTML below.
function escapeHtml(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// The model is asked not to use LaTeX, but doesn't always comply -- fully
// covering every LaTeX command it might use isn't realistic without a real
// math renderer, so this degrades common cases to plain readable text and
// falls back to just stripping the backslash from anything else it doesn't
// recognize (e.g. "\sum" -> "sum" is far more readable than a raw "\sum").
const _LATEX_SYMBOLS = {
  dots: "…", ldots: "…", cdot: "·", cdots: "⋯", times: "×", div: "÷",
  pm: "±", leq: "≤", geq: "≥", neq: "≠", approx: "≈", infty: "∞",
  rightarrow: "→", to: "→", leftarrow: "←", sum: "∑", prod: "∏", int: "∫",
  partial: "∂", nabla: "∇", sqrt: "√",
  alpha: "α", beta: "β", gamma: "γ", delta: "δ", epsilon: "ε", theta: "θ",
  lambda: "λ", mu: "μ", pi: "π", sigma: "σ", phi: "φ", omega: "ω",
};

// Unwraps grouping constructs (\text{}, \frac{}{}, delimiters) that use
// braces structurally rather than as LaTeX commands in their own right.
// Runs BEFORE subscript/superscript detection so e.g. "\text{head}_i"
// becomes "head_i" (subscript-eligible) rather than "head}_i" (not).
function unwrapLatexStructure(text) {
  return text
    .replace(/\\[()[\]]/g, "")
    .replace(/\\(left|right)/g, "")
    .replace(/\\text\{([^}]*)\}/g, "$1")
    .replace(/\\frac\{([^}]*)\}\{([^}]*)\}/g, "($1)/($2)");
}

// Converts remaining \command words to symbols (or, failing that, just
// drops the backslash). Runs AFTER subscript detection: a command like
// "\sum_{k}" needs its trailing letter ("m") intact as the subscript
// anchor before "\sum" gets turned into the single-character "∑".
function substituteLatexSymbols(text) {
  return text.replace(/\\([a-zA-Z]+)/g, (_match, word) => _LATEX_SYMBOLS[word] || word);
}

// Converts simple LaTeX-style sub/superscripts (x_i, x_{i-1}, x^2) into
// real <sub>/<sup> tags, since that's the most common math notation these
// documents use.
function renderSubscripts(text) {
  text = text.replace(/([A-Za-z0-9])_\{([^}]+)\}/g, "$1<sub>$2</sub>");
  text = text.replace(/([A-Za-z0-9])_([A-Za-z0-9]+)/g, "$1<sub>$2</sub>");
  text = text.replace(/([A-Za-z0-9])\^\{([^}]+)\}/g, "$1<sup>$2</sup>");
  text = text.replace(/([A-Za-z0-9])\^([A-Za-z0-9]+)/g, "$1<sup>$2</sup>");
  return text;
}

function renderInline(text) {
  // Pull code spans out first so LaTeX/subscript cleanup below can't touch
  // literal code content (e.g. a variable named x_i inside a code span
  // should stay exactly "x_i", not become "x" with a <sub>).
  const codeSpans = [];
  text = text.replace(/`([^`]+)`/g, (_match, code) => {
    codeSpans.push(code);
    return ` CODE${codeSpans.length - 1} `;
  });

  text = unwrapLatexStructure(text);
  text = renderSubscripts(text);
  text = substituteLatexSymbols(text);
  text = text.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  text = text.replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, "$1<em>$2</em>");
  text = text.replace(/ CODE(\d+) /g, (_match, i) => `<code>${codeSpans[Number(i)]}</code>`);
  // Models sometimes emit literal <br> inside table cells for line breaks.
  // The text has already been HTML-escaped by this point, so this is the
  // only tag we deliberately let back through -- everything else the
  // model writes stays inert text.
  text = text.replace(/&lt;br\s*\/?&gt;/gi, "<br>");
  return text;
}

function isTableSeparator(line) {
  return !!line && /^\s*\|?[\s:|-]+\|?\s*$/.test(line) && line.includes("-");
}

function renderMath(expr, display) {
  const fallback = () => escapeHtml(display ? `$$${expr}$$` : `$${expr}$`);
  if (typeof katex === "undefined") return fallback();
  try {
    return katex.renderToString(expr, { displayMode: display, throwOnError: false, output: "html" });
  } catch (_err) {
    return fallback();
  }
}

function renderMarkdown(raw) {
  // Extract ```mermaid fences BEFORE HTML-escaping, same reasoning as the
  // math blocks below: mermaid needs its diagram syntax's real `<`/`>`/`&`
  // (arrows, node shapes) as-is, not HTML-entity-escaped text. The
  // placeholder is swapped at the very end for a <div class="mermaid">
  // whose content IS run through escapeHtml() at that point -- so this
  // never bypasses the "LLM/document output can't inject arbitrary tags"
  // guarantee the rest of this function relies on; mermaid.js reads the
  // rendered element's .textContent (post-HTML-entity-decoding), so an
  // HTML-escaped-then-browser-decoded round trip lands back on the exact
  // original diagram source either way.
  const mermaidBlocks = [];
  let source0 = raw.replace(/```mermaid\s*\n([\s\S]+?)```/g, (_match, code) => {
    mermaidBlocks.push(code.trim());
    return `\n\n§MERMAID${mermaidBlocks.length - 1}§\n\n`;
  });

  // Extract $$...$$ (display) and $...$ (inline) math BEFORE HTML-escaping
  // -- KaTeX needs the literal LaTeX source (backslashes, braces, <, >),
  // not text that's already been escaped for safe display. The block
  // regex runs first so it consumes $$ pairs before the inline regex sees
  // them; both leave behind a placeholder that survives escapeHtml
  // untouched (§ isn't an HTML special character) and gets swapped for
  // real KaTeX-rendered HTML at the very end.
  const mathBlocks = [];
  // \[...\] / \(...\) are recognized too, as a defense-in-depth fallback --
  // every prompt tier now explicitly instructs $$/$ delimiters (a real bug:
  // that instruction originally existed on only one of five prompt
  // templates, so a math question answered via the web/general-knowledge/
  // MARX-web tiers could come back with these instead and render as
  // broken raw text), but LLM formatting instructions aren't 100%
  // reliable, so both delimiter styles are handled here regardless of
  // which tier answered.
  let source = source0.replace(/\\\[([\s\S]+?)\\\]/g, (_match, expr) => {
    mathBlocks.push({ expr, display: true });
    return `\n\n§MATH${mathBlocks.length - 1}§\n\n`;
  });
  source = source.replace(/\$\$([\s\S]+?)\$\$/g, (_match, expr) => {
    mathBlocks.push({ expr, display: true });
    return `\n\n§MATH${mathBlocks.length - 1}§\n\n`;
  });
  source = source.replace(/\\\(([\s\S]+?)\\\)/g, (_match, expr) => {
    mathBlocks.push({ expr, display: false });
    return `§MATH${mathBlocks.length - 1}§`;
  });
  source = source.replace(/\$([^$\n]+)\$/g, (_match, expr) => {
    mathBlocks.push({ expr, display: false });
    return `§MATH${mathBlocks.length - 1}§`;
  });

  const lines = escapeHtml(source).split("\n");
  const blocks = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];

    if (/^```/.test(line.trim())) {
      const codeLines = [];
      i++;
      while (i < lines.length && !/^```/.test(lines[i].trim())) {
        codeLines.push(lines[i]);
        i++;
      }
      i++;
      blocks.push(`<pre class="md-code"><code>${codeLines.join("\n")}</code></pre>`);
      continue;
    }

    if (line.includes("|") && isTableSeparator(lines[i + 1])) {
      const headerCells = line.split("|").map((c) => c.trim()).filter((c) => c !== "");
      i += 2;
      const rows = [];
      while (i < lines.length && lines[i].includes("|")) {
        rows.push(
          lines[i]
            .split("|")
            .map((c) => c.trim())
            .filter((c, idx, arr) => !(c === "" && (idx === 0 || idx === arr.length - 1)))
        );
        i++;
      }
      let table = '<table class="md-table"><thead><tr>';
      for (const h of headerCells) table += `<th>${renderInline(h)}</th>`;
      table += "</tr></thead><tbody>";
      for (const row of rows) {
        table += "<tr>";
        for (const cell of row) table += `<td>${renderInline(cell)}</td>`;
        table += "</tr>";
      }
      table += "</tbody></table>";
      blocks.push(table);
      continue;
    }

    const headerMatch = line.match(/^(#{1,6})\s+(.*)$/);
    if (headerMatch) {
      const level = headerMatch[1].length;
      blocks.push(`<h${level} class="md-heading">${renderInline(headerMatch[2])}</h${level}>`);
      i++;
      continue;
    }

    if (/^\s*[-*]\s+/.test(line)) {
      const items = [];
      while (i < lines.length && /^\s*[-*]\s+/.test(lines[i])) {
        items.push(lines[i].replace(/^\s*[-*]\s+/, ""));
        i++;
      }
      blocks.push("<ul>" + items.map((it) => `<li>${renderInline(it)}</li>`).join("") + "</ul>");
      continue;
    }

    if (/^\s*\d+\.\s+/.test(line)) {
      const items = [];
      while (i < lines.length && /^\s*\d+\.\s+/.test(lines[i])) {
        items.push(lines[i].replace(/^\s*\d+\.\s+/, ""));
        i++;
      }
      blocks.push("<ol>" + items.map((it) => `<li>${renderInline(it)}</li>`).join("") + "</ol>");
      continue;
    }

    if (line.trim() === "") {
      i++;
      continue;
    }

    const paraLines = [line];
    i++;
    while (
      i < lines.length &&
      lines[i].trim() !== "" &&
      !/^```/.test(lines[i].trim()) &&
      !/^#{1,6}\s+/.test(lines[i]) &&
      !/^\s*[-*]\s+/.test(lines[i]) &&
      !/^\s*\d+\.\s+/.test(lines[i]) &&
      !(lines[i].includes("|") && isTableSeparator(lines[i + 1]))
    ) {
      paraLines.push(lines[i]);
      i++;
    }
    blocks.push(`<p>${renderInline(paraLines.join("<br>"))}</p>`);
  }

  let html = blocks.join("\n");
  html = html.replace(/§MATH(\d+)§/g, (_match, idx) => {
    const m = mathBlocks[Number(idx)];
    return renderMath(m.expr, m.display);
  });
  html = html.replace(/§MERMAID(\d+)§/g, (_match, idx) => {
    // escapeHtml here, not the raw source -- the browser decodes the HTML
    // entities back to the real diagram syntax when mermaid later reads
    // this element's .textContent, so this keeps the same "escape
    // everything before it becomes real HTML" guarantee the rest of this
    // function relies on, without mermaid ever seeing entity-encoded text.
    return `<div class="mermaid">${escapeHtml(mermaidBlocks[Number(idx)])}</div>`;
  });
  return html;
}

// Renders any <div class="mermaid"> elements inside `container` into real
// SVG diagrams. Must be called after the container's innerHTML has
// actually been set to renderMarkdown()'s output -- mermaid.run() looks
// at live DOM nodes, not markup strings. Safe to call even when no
// mermaid diagrams are present (mermaid.run() on an empty selector is a
// no-op) and safe to call before the module has finished loading (the
// "mermaid-ready" listener re-runs it once window.mermaid exists).
function renderMermaidIn(container) {
  const nodes = container.querySelectorAll(".mermaid");
  if (!nodes.length) return;
  if (!window.mermaid) {
    window.addEventListener("mermaid-ready", () => renderMermaidIn(container), { once: true });
    return;
  }
  const nodeList = Array.from(nodes);
  // A real bug found by live testing: the model sometimes produces Mermaid
  // syntax that's invalid (e.g. unquoted punctuation in a node label,
  // `A[Do X (fast)]` instead of `A["Do X (fast)"]`). By default mermaid.run()
  // swallows that internally and draws its OWN ugly red "Syntax error"
  // diagram in place -- suppressErrorRendering:true (set at init, see
  // index.html) makes it throw instead, so we can catch it here and fall
  // back to something readable rather than a broken-looking diagram.
  // Sources must be captured BEFORE calling run(): on a suppressed error
  // mermaid's own cleanup clears the failed node's content as part of
  // unwinding (found by testing -- reading .textContent afterward came back
  // empty), so by the time the promise settles there's nothing left to read.
  const sourceByNode = new Map(nodeList.map((node) => [node, node.textContent]));
  window.mermaid
    .run({ nodes: nodeList })
    .catch((err) => {
      console.error("Mermaid render failed:", err);
    })
    .finally(() => {
      for (const node of nodeList) {
        if (node.querySelector("svg")) continue;
        const source = sourceByNode.get(node) || "";
        node.textContent = "";
        node.classList.add("mermaid-error");
        const note = el("p", "mermaid-error-note", "⚠️ Couldn't render this diagram (invalid syntax) -- showing the raw source instead:");
        const pre = document.createElement("pre");
        pre.textContent = source;
        node.append(note, pre);
      }
    });
}

// ---------- API helpers ----------
async function api(path, options = {}) {
  const headers = options.headers || {};
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const res = await fetch(path, { ...options, headers });
  if (res.status === 401) {
    logout();
    throw new Error("Session expired, please sign in again.");
  }
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail || detail;
    } catch (_) {
      /* no JSON body */
    }
    throw new Error(detail);
  }
  if (res.status === 204) return null;
  return res.json();
}

function apiJson(path, method, body) {
  return api(path, {
    method,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
}

async function apiForm(path, formData) {
  const headers = {};
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const res = await fetch(path, { method: "POST", headers, body: formData });
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail || detail;
    } catch (_) {
      /* no JSON body */
    }
    throw new Error(detail);
  }
  return res.json();
}

// ---------- View switching ----------
function showView(view) {
  $("login-view").hidden = view !== "login";
  $("app-view").hidden = view !== "app";
}

function logout() {
  token = null;
  currentUser = null;
  chatSessions = [];
  currentSessionId = null;
  localStorage.removeItem("token");
  showView("login");
}

async function loadCurrentUser() {
  currentUser = await api("/auth/me");
  $("user-badge").textContent = `${currentUser.username} · ${currentUser.role} · ${currentUser.department}`;
}

async function startApp() {
  try {
    await loadCurrentUser();
    showView("app");
    await refreshFiles();
    initChatSessions();
    initSettingsTab();
    refreshActivity();
  } catch (err) {
    $("login-error").textContent = err.message;
    logout();
  }
}

// ---------- Chat sessions (like a chatbot's chat history sidebar) ----------
// Scoped per logged-in user (not just per browser) since this app is
// multi-user/RBAC -- two accounts sharing a browser must never see each
// other's chat history.
function sessionsKey() {
  return `chat_sessions_v1_${currentUser.id}`;
}

function loadSessions() {
  try {
    chatSessions = JSON.parse(localStorage.getItem(sessionsKey()) || "[]");
  } catch (_) {
    chatSessions = [];
  }
}

function saveSessions() {
  localStorage.setItem(sessionsKey(), JSON.stringify(chatSessions));
}

function initChatSessions() {
  loadSessions();
  if (chatSessions.length > 0) {
    selectSession(chatSessions[0].id);
  } else {
    renderSessionList();
    $("chat-log").innerHTML = "";
  }
}

function createSession() {
  const session = {
    id: `s_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    title: "New chat",
    messages: [],
  };
  chatSessions.unshift(session);
  currentSessionId = session.id;
  saveSessions();
  renderSessionList();
  $("chat-log").innerHTML = "";
  return session;
}

function getCurrentSession() {
  return chatSessions.find((s) => s.id === currentSessionId) || null;
}

// Recent turns from the current session, sent to the backend so follow-up
// questions ("and its population?") can be resolved without the user
// repeating context. Capped to the last 3 exchanges (6 messages) -- enough
// for real follow-ups without ballooning every request's prompt size.
function getRecentHistory() {
  const session = getCurrentSession();
  if (!session || !session.messages.length) return [];
  return session.messages.slice(-6).map((m) => ({ role: m.role, content: m.text }));
}

function selectSession(id) {
  currentSessionId = id;
  renderSessionList();
  renderChatLogFromSession(getCurrentSession());
}

function renderSessionList() {
  const list = $("chat-session-list");
  list.innerHTML = "";
  for (const session of chatSessions) {
    const item = el("li", session.id === currentSessionId ? "chat-session-item active" : "chat-session-item");

    const title = el("span", "chat-session-title", session.title);
    title.addEventListener("click", () => selectSession(session.id));
    item.appendChild(title);

    const menuBtn = el("button", "chat-session-menu-btn", "⋮");
    menuBtn.type = "button";
    menuBtn.setAttribute("aria-label", "Chat options");
    menuBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      toggleChatSessionMenu(menuBtn, session);
    });
    item.appendChild(menuBtn);

    list.appendChild(item);
  }
}

// A single floating menu reused for whichever session's "..." was last
// clicked, rather than one pre-built hidden menu per session -- simpler to
// position (fixed, anchored to the clicked button's own screen rect) and
// there's never more than one open at a time anyway.
let _closeOpenChatSessionMenu = null;

function closeChatSessionMenu() {
  if (_closeOpenChatSessionMenu) {
    _closeOpenChatSessionMenu();
    _closeOpenChatSessionMenu = null;
  }
}

function toggleChatSessionMenu(anchorBtn, session) {
  const wasOpenForThisButton = anchorBtn.dataset.menuOpen === "true";
  closeChatSessionMenu();
  if (wasOpenForThisButton) return; // second click on the same "..." just closes it

  const menu = el("div", "chat-session-menu");

  const exportItem = el("button", "chat-session-menu-item", "Export chat");
  exportItem.type = "button";
  exportItem.addEventListener("click", () => {
    closeChatSessionMenu();
    exportSession(session);
  });
  menu.appendChild(exportItem);

  const deleteItem = el("button", "chat-session-menu-item danger", "Delete chat + documents");
  deleteItem.type = "button";
  deleteItem.addEventListener("click", () => {
    closeChatSessionMenu();
    deleteSessionAndDocuments(session);
  });
  menu.appendChild(deleteItem);

  const rect = anchorBtn.getBoundingClientRect();
  menu.style.top = `${rect.bottom + 4}px`;
  menu.style.left = `${rect.left}px`;
  document.body.appendChild(menu);
  anchorBtn.dataset.menuOpen = "true";

  // Capture phase so this fires before the click that opened the menu
  // finishes bubbling, and so a click on any other "..." button (which
  // calls closeChatSessionMenu() itself first) doesn't double-close.
  const onDocClick = (e) => {
    if (!menu.contains(e.target) && e.target !== anchorBtn) closeChatSessionMenu();
  };
  document.addEventListener("click", onDocClick, { capture: true });

  _closeOpenChatSessionMenu = () => {
    menu.remove();
    delete anchorBtn.dataset.menuOpen;
    document.removeEventListener("click", onDocClick, { capture: true });
  };
}

// Exports one session's transcript, same JSON shape as the Settings tab's
// "Export my chat history" (which exports all sessions at once) -- just
// scoped to a single session here.
function exportSession(session) {
  const blob = new Blob([JSON.stringify(session, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  const safeTitle = session.title.replace(/[^a-z0-9]+/gi, "_").slice(0, 40);
  a.download = `chat_${safeTitle}_${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

// Deletes the session AND, per explicit user confirmation of scope, every
// file actually cited as a source in that session's answers -- a real,
// irreversible DELETE against the backend (files are shared/RBAC-scoped,
// so this can affect other chats or other users), which is why the confirm
// dialog spells out every filename before anything happens rather than
// just naming a count.
async function deleteSessionAndDocuments(session) {
  const fileMap = new Map();
  for (const msg of session.messages) {
    for (const src of msg.sources || []) {
      if (src && src.file_id != null) fileMap.set(src.file_id, src.filename || `file #${src.file_id}`);
    }
  }
  const files = Array.from(fileMap.entries());

  const fileListText = files.length
    ? `\n\nThis will also PERMANENTLY delete the following file(s) referenced in this chat (this may affect other chats or users if these files are shared):\n${files.map(([, name]) => `- ${name}`).join("\n")}`
    : "";
  const proceed = await confirmDialog(`Delete "${session.title}"?${fileListText}\n\nThis cannot be undone.`);
  if (!proceed) return;

  const failures = [];
  for (const [fileId, name] of files) {
    try {
      await api(`/files/${fileId}`, { method: "DELETE" });
    } catch (err) {
      failures.push(`${name}: ${err.message}`);
    }
  }

  chatSessions = chatSessions.filter((s) => s.id !== session.id);
  if (currentSessionId === session.id) {
    currentSessionId = chatSessions.length ? chatSessions[0].id : null;
  }
  saveSessions();
  renderSessionList();
  if (currentSessionId) {
    renderChatLogFromSession(getCurrentSession());
  } else {
    $("chat-log").innerHTML = "";
  }
  await refreshFiles();

  if (failures.length) {
    alert(`Chat deleted, but some file(s) could not be deleted:\n${failures.join("\n")}`);
  }
}

function renderChatLogFromSession(session) {
  const log = $("chat-log");
  log.innerHTML = "";
  if (!session) return;
  let lastUserQuestion = null;
  for (const msg of session.messages) {
    if (msg.role === "user") {
      appendMessage(log, "user", msg.text);
      lastUserQuestion = msg.text;
    } else {
      renderAnswerInto(appendMessage(log, "assistant", ""), { answer: msg.text, sources: msg.sources || [] }, lastUserQuestion);
    }
  }
}

function addMessageToCurrentSession(role, text, sources) {
  let session = getCurrentSession();
  if (!session) session = createSession();
  session.messages.push({ role, text, sources: sources || null });
  if (role === "user" && session.title === "New chat") {
    session.title = text.length > 42 ? text.slice(0, 42) + "..." : text;
  }
  saveSessions();
  renderSessionList();
}

// Guarded (unlike the other top-level listeners) because this element was
// added after initial deployment: a returning user whose browser serves a
// stale cached index.html alongside a fresh app.js would otherwise hit a
// null reference here and silently lose every other event handler below
// it, since an uncaught top-level error stops the rest of the script.
if ($("new-chat-btn")) {
  $("new-chat-btn").addEventListener("click", () => createSession());
}

// ---------- Settings (privacy) ----------
// Scoped per logged-in user, same rationale as chat sessions -- two
// accounts sharing a browser must not see or inherit each other's
// preferences.
function webSearchSettingKey() {
  return `allow_web_search_v1_${currentUser.id}`;
}

function getAllowWebSearch() {
  const stored = localStorage.getItem(webSearchSettingKey());
  return stored === null ? true : stored === "true";
}

function setAllowWebSearch(value) {
  localStorage.setItem(webSearchSettingKey(), String(value));
}

async function refreshActivity() {
  const list = $("activity-list");
  if (!list) return;
  list.innerHTML = "<li class='activity-empty'>Loading...</li>";
  try {
    const rows = await api("/audit?limit=25");
    if (!rows.length) {
      list.innerHTML = "<li class='activity-empty'>No activity recorded yet.</li>";
      return;
    }
    list.innerHTML = "";
    for (const row of rows) {
      const when = new Date(row.created_at).toLocaleString();
      const parts = [row.action];
      if (row.resource_type) parts.push(`${row.resource_type}${row.resource_id ? ":" + row.resource_id : ""}`);
      if (row.detail) parts.push(`"${row.detail.length > 60 ? row.detail.slice(0, 60) + "..." : row.detail}"`);
      const item = el("li", "activity-item");
      item.appendChild(el("span", "activity-when", when));
      item.appendChild(el("span", "activity-detail", parts.join(" · ")));
      list.appendChild(item);
    }
  } catch (err) {
    list.innerHTML = `<li class="activity-empty">Failed to load: ${err.message}</li>`;
  }
}

// All the places a user can flip the web-search setting -- the Settings
// tab's checkbox and the liquid toggle in each chat input row. Kept in
// sync with each other (not just with storage) so switching it in one
// place is immediately reflected everywhere else without a page reload.
function getAllWebSearchToggleInputs() {
  const inputs = Array.from(document.querySelectorAll("[data-web-search-toggle]"));
  const settingsToggle = $("setting-allow-web-search");
  if (settingsToggle) inputs.push(settingsToggle);
  return inputs;
}

function initWebSearchToggles() {
  const inputs = getAllWebSearchToggleInputs();
  const current = getAllowWebSearch();
  inputs.forEach((input) => {
    input.checked = current;
    input.addEventListener("change", () => {
      setAllowWebSearch(input.checked);
      inputs.forEach((other) => {
        if (other !== input) other.checked = input.checked;
      });
    });
  });
}

function initSettingsTab() {
  initWebSearchToggles();

  const exportBtn = $("export-history-btn");
  if (exportBtn) {
    exportBtn.addEventListener("click", () => {
      const blob = new Blob([JSON.stringify(chatSessions, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `chat_history_${currentUser.username}_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      $("settings-history-status").textContent = `Exported ${chatSessions.length} session(s).`;
    });
  }

  const clearBtn = $("clear-history-btn");
  if (clearBtn) {
    clearBtn.addEventListener("click", async () => {
      const proceed = await confirmDialog("Delete all of your chat sessions from this browser? This cannot be undone.");
      if (!proceed) return;
      chatSessions = [];
      currentSessionId = null;
      saveSessions();
      renderSessionList();
      $("chat-log").innerHTML = "";
      $("settings-history-status").textContent = "Chat history cleared.";
    });
  }

  const refreshActivityBtn = $("refresh-activity-btn");
  if (refreshActivityBtn) {
    refreshActivityBtn.addEventListener("click", refreshActivity);
  }
}

// ---------- Auth forms ----------
$("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("login-error").textContent = "";
  try {
    const body = new URLSearchParams({
      username: $("login-username").value,
      password: $("login-password").value,
    });
    const res = await fetch("/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.detail || "Login failed");
    }
    const data = await res.json();
    token = data.access_token;
    localStorage.setItem("token", token);
    await startApp();
  } catch (err) {
    $("login-error").textContent = err.message;
  }
});

$("register-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("register-error").textContent = "";
  const username = $("register-username").value;
  const password = $("register-password").value;
  try {
    await apiJson("/auth/register", "POST", {
      username,
      password,
      department: $("register-department").value,
    });
    const body = new URLSearchParams({ username, password });
    const res = await fetch("/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
    });
    const data = await res.json();
    token = data.access_token;
    localStorage.setItem("token", token);
    await startApp();
  } catch (err) {
    $("register-error").textContent = err.message;
  }
});

$("show-register").addEventListener("click", (e) => {
  e.preventDefault();
  $("register-card").hidden = false;
  document.querySelector("#login-view > .login-card").hidden = true;
});
$("show-login").addEventListener("click", (e) => {
  e.preventDefault();
  $("register-card").hidden = true;
  document.querySelector("#login-view > .login-card").hidden = false;
});
$("logout-btn").addEventListener("click", logout);

// ---------- Files ----------
async function refreshFiles() {
  filesCache = await api("/files");
  renderFileList();
  renderSqlDatasetOptions();
}

function renderFileList() {
  const list = $("file-list");
  list.innerHTML = "";
  if (filesCache.length === 0) {
    list.appendChild(el("li", "status", "No files yet."));
    return;
  }
  for (const f of filesCache) {
    const li = el("li", "file-item");
    li.appendChild(el("div", "file-name", f.original_filename));
    li.appendChild(
      el(
        "div",
        "file-meta",
        `#${f.id} · ${f.scope}${f.department ? " · " + f.department : ""} · ${(f.size_bytes / 1024).toFixed(1)} KB`
      )
    );

    const statusLine = el("div", "file-status");
    statusLine.appendChild(el("span", f.rag_indexed ? "status-pill on" : "status-pill", f.rag_indexed ? "✓ Indexed" : "Not indexed"));
    statusLine.appendChild(el("span", f.sql_ingested ? "status-pill on" : "status-pill", f.sql_ingested ? "✓ Ingested" : "Not ingested"));
    li.appendChild(statusLine);

    const actions = el("div", "file-actions");

    const indexBtn = el("button", "", f.rag_indexed ? "Re-index (RAG)" : "Index (RAG)");
    indexBtn.addEventListener("click", () =>
      handleAction(
        () => api(`/rag/documents/${f.id}/index`, { method: "POST" }).then(refreshFiles),
        indexBtn,
        "Indexed"
      )
    );
    actions.appendChild(indexBtn);

    const ingestBtn = el("button", "", f.sql_ingested ? "Re-ingest (SQL)" : "Ingest (SQL)");
    ingestBtn.addEventListener("click", () =>
      handleAction(
        () => api(`/sql/datasets/${f.id}/ingest`, { method: "POST" }).then(refreshFiles),
        ingestBtn,
        "Ingested"
      )
    );
    actions.appendChild(ingestBtn);

    const summarizeBtn = el("button", "", "Summarize");
    summarizeBtn.addEventListener("click", () => summarizeFile(f));
    actions.appendChild(summarizeBtn);

    const extractBtn = el("button", "", "Extract fields");
    extractBtn.addEventListener("click", () => extractFieldsFromFile(f));
    actions.appendChild(extractBtn);

    const deleteBtn = el("button", "danger", "Delete");
    deleteBtn.addEventListener("click", () =>
      handleAction(() => api(`/files/${f.id}`, { method: "DELETE" }).then(refreshFiles), deleteBtn, "Deleted")
    );
    actions.appendChild(deleteBtn);

    li.appendChild(actions);
    list.appendChild(li);
  }
}

async function handleAction(fn, button, successLabel) {
  const original = button.textContent;
  button.disabled = true;
  button.textContent = "...";
  try {
    await fn();
    button.textContent = successLabel;
    setTimeout(() => {
      button.textContent = original;
      button.disabled = false;
    }, 1500);
  } catch (err) {
    alert(err.message);
    button.textContent = original;
    button.disabled = false;
  }
}

async function summarizeFile(f) {
  $("summary-modal-title").textContent = `Summary: ${f.original_filename}`;
  $("summary-modal-body").textContent = "Summarizing...";
  $("summary-modal").hidden = false;
  try {
    const result = await api(`/utility/documents/${f.id}/summarize`, { method: "POST" });
    $("summary-modal-body").innerHTML = renderMarkdown(result.summary);
    renderMermaidIn($("summary-modal-body"));
  } catch (err) {
    $("summary-modal-body").textContent = `Error: ${err.message}`;
  }
}
$("summary-modal-close").addEventListener("click", () => {
  $("summary-modal").hidden = true;
});

// Reuses the same generic modal as summarizeFile() -- title + body are
// swapped out per use, rather than building a second modal for what's
// fundamentally the same "run an LLM operation on this file, show the
// result" interaction.
function extractFieldsFromFile(f) {
  $("summary-modal-title").textContent = `Extract fields: ${f.original_filename}`;
  const body = $("summary-modal-body");
  body.innerHTML = "";

  body.appendChild(
    el("p", "extract-hint", 'Enter field names to extract, separated by commas (e.g. "default port, data structures").')
  );

  const inputRow = el("div", "extract-input-row");
  const input = document.createElement("input");
  input.type = "text";
  input.placeholder = "field one, field two, ...";
  const runBtn = el("button", "", "Extract");
  runBtn.type = "button";
  inputRow.appendChild(input);
  inputRow.appendChild(runBtn);
  body.appendChild(inputRow);

  const resultsArea = el("div", "extract-results");
  body.appendChild(resultsArea);

  runBtn.addEventListener("click", async () => {
    const fieldNames = input.value.split(",").map((s) => s.trim()).filter(Boolean);
    if (!fieldNames.length) {
      resultsArea.textContent = "Enter at least one field name.";
      return;
    }
    runBtn.disabled = true;
    resultsArea.textContent = "Extracting...";
    try {
      const result = await apiJson(`/utility/documents/${f.id}/extract`, "POST", {
        fields: fieldNames.map((name) => ({ name })),
      });
      resultsArea.innerHTML = "";
      const table = document.createElement("table");
      table.className = "extract-results-table";
      for (const [key, value] of Object.entries(result.data)) {
        const row = document.createElement("tr");
        row.appendChild(el("td", "extract-key", key));
        const valCell = el(
          "td",
          "extract-value",
          value === null ? "(not found)" : typeof value === "object" ? JSON.stringify(value) : String(value)
        );
        row.appendChild(valCell);
        table.appendChild(row);
      }
      resultsArea.appendChild(table);
    } catch (err) {
      resultsArea.textContent = `Error: ${err.message}`;
    }
    runBtn.disabled = false;
  });

  $("summary-modal").hidden = false;
}

$("upload-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const fileInput = $("upload-file");
  if (!fileInput.files.length) return;
  const formData = new FormData();
  formData.append("file", fileInput.files[0]);
  formData.append("scope", $("upload-scope").value);
  $("upload-status").textContent = "Uploading...";
  $("upload-status").classList.remove("warning");
  try {
    const result = await apiForm("/files/upload", formData);
    if (result.auto_process_warning) {
      $("upload-status").textContent = `Uploaded, but not auto-indexed: ${result.auto_process_warning}`;
      $("upload-status").classList.add("warning");
    } else {
      $("upload-status").textContent = "Uploaded and indexed.";
    }
    fileInput.value = "";
    await refreshFiles();
  } catch (err) {
    $("upload-status").textContent = `Error: ${err.message}`;
    $("upload-status").classList.add("warning");
  }
});
$("refresh-files-btn").addEventListener("click", refreshFiles);

// ---------- Tabs ----------
document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
    btn.classList.add("active");
    $(`tab-${btn.dataset.tab}`).classList.add("active");
  });
});

// ---------- Chat (RAG) ----------
function appendMessage(container, role, text) {
  const msg = el("div", `msg ${role}`, text);
  container.appendChild(msg);
  container.scrollTop = container.scrollHeight;
  return msg;
}

function renderAnswerInto(container, result, question) {
  container.innerHTML = "";

  if (result.source === "web") {
    container.appendChild(el("div", "answer-source-badge web", "🌐 From the web — not your documents"));
  } else if (result.source === "general_knowledge") {
    container.appendChild(el("div", "answer-source-badge general", "⚠ General knowledge — not from your documents"));
  } else if (result.source === "insufficient") {
    container.appendChild(el("div", "answer-source-badge insufficient", "🚫 Not found in your material or the web"));
  }

  const body = el("div", "");
  body.innerHTML = renderMarkdown(result.answer);
  container.appendChild(body);
  renderMermaidIn(body);

  if (result.sources && result.sources.length) {
    const details = document.createElement("details");
    details.className = "sources";
    details.open = true;
    const summary = document.createElement("summary");
    summary.textContent = `${result.sources.length} source(s)`;
    details.appendChild(summary);
    for (const s of result.sources) {
      const snippet = s.text.length > 160 ? s.text.slice(0, 160) + "..." : s.text;
      details.appendChild(el("div", "source-item", `${s.filename} (chunk ${s.chunk_index}): ${snippet}`));
    }
    container.appendChild(details);
  }

  if (result.web_sources && result.web_sources.length) {
    const details = document.createElement("details");
    details.className = "sources";
    details.open = true;
    const summary = document.createElement("summary");
    summary.textContent = `${result.web_sources.length} web result(s)`;
    details.appendChild(summary);
    for (const w of result.web_sources) {
      const item = el("div", "source-item web-source-item");
      const link = document.createElement("a");
      link.href = w.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = w.title;
      item.appendChild(link);
      item.appendChild(el("div", "web-source-snippet", w.snippet));
      details.appendChild(item);
    }
    container.appendChild(details);
  }

  if (question) {
    container.appendChild(renderFeedbackRow(question, result));
  }
}

// A 👍/👎 row under each answer. Feedback is submitted once per answer --
// after a rating is sent the buttons are replaced with a static
// confirmation rather than left clickable, since editing a already-sent
// rating isn't a feature and leaving both buttons live invites duplicate
// submissions for the same answer.
function renderFeedbackRow(question, result) {
  const row = el("div", "feedback-row");
  const label = el("span", "feedback-label", "Was this helpful?");
  row.appendChild(label);

  const submit = async (rating, btnUp, btnDown) => {
    btnUp.disabled = true;
    btnDown.disabled = true;
    try {
      await apiJson("/rag/feedback", "POST", {
        question,
        answer: result.answer,
        source: result.source || "documents",
        rating,
      });
      label.textContent = rating === "up" ? "Thanks for the feedback! 👍" : "Thanks for the feedback — noted. 👎";
      btnUp.remove();
      btnDown.remove();
    } catch (err) {
      label.textContent = `Feedback failed: ${err.message}`;
      btnUp.disabled = false;
      btnDown.disabled = false;
    }
  };

  const upBtn = el("button", "feedback-btn", "👍");
  upBtn.type = "button";
  const downBtn = el("button", "feedback-btn", "👎");
  downBtn.type = "button";
  upBtn.addEventListener("click", () => submit("up", upBtn, downBtn));
  downBtn.addEventListener("click", () => submit("down", upBtn, downBtn));
  row.appendChild(upBtn);
  row.appendChild(downBtn);

  return row;
}

// Plain, non-interactive rendering for the "what topics do you have" meta-
// question -- deliberately NOT the checkbox/"Get answer" picker used for a
// real ambiguous question, since there's no follow-up LLM call to make
// here (see the is_document_list branch in the chat-form handler for why).
function renderDocumentList(container, topics) {
  container.innerHTML = "";
  container.appendChild(
    el("div", "topic-picker-title", "Here's what I have indexed — ask a question about any of these:")
  );
  const list = el("ul", "document-list");
  for (const topic of topics) {
    const item = el("li", "document-list-item");
    item.appendChild(el("span", "document-list-name", topic.filename));
    list.appendChild(item);
  }
  container.appendChild(list);
}

function renderTopicPicker(container, log, question, topics, history) {
  container.innerHTML = "";
  container.appendChild(el("div", "topic-picker-title", "Which topic(s) do you want to know about?"));

  const list = el("div", "topic-list");
  const checkboxes = [];
  for (const topic of topics) {
    const row = el("label", "topic-row");
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.value = topic.topic_id;
    checkboxes.push(checkbox);
    row.appendChild(checkbox);
    const text = el("span", "topic-text");
    text.appendChild(el("span", "topic-label", topic.label));
    text.appendChild(el("span", "topic-source", ` — ${topic.filename}`));
    row.appendChild(text);
    list.appendChild(row);
  }
  container.appendChild(list);

  const controls = el("div", "topic-controls");
  const selectAllBtn = el("button", "ghost-btn small", "Select all");
  selectAllBtn.type = "button";
  selectAllBtn.addEventListener("click", () => {
    const allChecked = checkboxes.every((cb) => cb.checked);
    checkboxes.forEach((cb) => (cb.checked = !allChecked));
  });
  controls.appendChild(selectAllBtn);

  const answerBtn = el("button", "", "Get answer");
  answerBtn.type = "button";
  answerBtn.addEventListener("click", async () => {
    const selected = checkboxes.filter((cb) => cb.checked).map((cb) => cb.value);
    if (selected.length === 0) {
      alert("Select at least one topic first.");
      return;
    }
    answerBtn.disabled = true;
    answerBtn.textContent = "Thinking...";
    try {
      const result = await apiJson("/rag/query/from-topics", "POST", {
        query: question,
        topic_ids: selected,
        history,
        allow_web_search: getAllowWebSearch(),
      });
      renderAnswerInto(container, result, question);
      addMessageToCurrentSession("assistant", result.answer, result.sources);
    } catch (err) {
      container.textContent = `Error: ${err.message}`;
    }
    log.scrollTop = log.scrollHeight;
  });
  controls.appendChild(answerBtn);
  container.appendChild(controls);

  log.scrollTop = log.scrollHeight;
}

$("chat-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const input = $("chat-input");
  const question = input.value.trim();
  if (!question) return;
  input.value = "";
  const log = $("chat-log");
  // Captured BEFORE adding the current question to the session, so this
  // history snapshot doesn't end up containing the very question it's
  // meant to provide context for (which would just duplicate `query`).
  const history = getRecentHistory();
  appendMessage(log, "user", question);
  addMessageToCurrentSession("user", question);
  const pending = appendMessage(log, "assistant", "Thinking...");
  try {
    const result = await apiJson("/rag/topics", "POST", { query: question, history, allow_web_search: getAllowWebSearch() });
    if (result.direct_answer) {
      // The top matches were dominated by a single source document -- not
      // actually ambiguous, so answer directly instead of making the user
      // pick a topic every time.
      renderAnswerInto(pending, result.direct_answer, question);
      addMessageToCurrentSession("assistant", result.direct_answer.answer, result.direct_answer.sources);
    } else if (!result.topics || result.topics.length === 0) {
      pending.textContent = "No relevant indexed documents found for this question.";
    } else if (result.is_document_list) {
      // A meta-question ("what topics do you have") -- these topics are
      // every indexed document, not candidates to disambiguate a real
      // question, so this must NOT reuse the interactive picker: picking
      // documents and hitting "Get answer" there would just re-ask this
      // literal meta-question against whichever files got checked, which
      // produces a real but confusingly-repetitive-looking LLM answer
      // instead of what the user actually wants here.
      renderDocumentList(pending, result.topics);
    } else {
      renderTopicPicker(pending, log, question, result.topics, history);
    }
  } catch (err) {
    pending.textContent = `Error: ${err.message}`;
  }
  log.scrollTop = log.scrollHeight;
});

// ---------- Text-to-SQL ----------
function renderSqlDatasetOptions() {
  const select = $("sql-dataset-select");
  select.innerHTML = "";
  const tabular = filesCache.filter((f) => /\.(csv|xlsx|xls)$/i.test(f.original_filename));
  if (tabular.length === 0) {
    select.appendChild(el("option", "", "No CSV/Excel files uploaded yet"));
    return;
  }
  for (const f of tabular) {
    const opt = document.createElement("option");
    opt.value = f.id;
    opt.textContent = `#${f.id} ${f.original_filename}`;
    select.appendChild(opt);
  }
}

$("sql-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const selected = Array.from($("sql-dataset-select").selectedOptions).map((o) => o.value).filter(Boolean);
  const input = $("sql-input");
  const question = input.value.trim();
  if (!question || selected.length === 0) return;
  input.value = "";
  const log = $("sql-log");
  appendMessage(log, "user", question);
  const pending = appendMessage(log, "assistant", "Querying...");
  try {
    // Two or more datasets selected -> ask for a cross-dataset JOIN;
    // exactly one -> the plain single-dataset endpoint, unchanged from
    // before this feature existed.
    const result =
      selected.length > 1
        ? await apiJson("/sql/join-query", "POST", { file_ids: selected.map(Number), question })
        : await apiJson(`/sql/datasets/${selected[0]}/query`, "POST", { question });
    pending.innerHTML = renderMarkdown(result.answer);
    renderMermaidIn(pending);
    pending.appendChild(el("div", "sql-code", result.sql));
    if (result.rows.length) {
      const table = document.createElement("table");
      table.className = "sql-result-table";
      const thead = document.createElement("tr");
      for (const col of result.columns) thead.appendChild(el("th", "", col));
      table.appendChild(thead);
      for (const row of result.rows) {
        const tr = document.createElement("tr");
        for (const col of result.columns) tr.appendChild(el("td", "", String(row[col])));
        table.appendChild(tr);
      }
      pending.appendChild(table);
      if (result.truncated) pending.appendChild(el("div", "status", `Showing first ${result.rows.length} rows.`));
    } else {
      pending.appendChild(el("div", "status", "Query returned no rows."));
    }
  } catch (err) {
    pending.textContent = `Error: ${err.message}`;
  }
  log.scrollTop = log.scrollHeight;
});

// ---------- Agent (automatic multi-tool reasoning) ----------
function renderAgentAnswer(container, result) {
  container.innerHTML = "";

  const body = el("div", "");
  body.innerHTML = renderMarkdown(result.answer);
  container.appendChild(body);
  renderMermaidIn(body);

  if (result.steps && result.steps.length) {
    const details = document.createElement("details");
    details.className = "sources agent-steps";
    details.open = true;
    const summary = document.createElement("summary");
    summary.textContent = `${result.steps.length} step(s) taken`;
    details.appendChild(summary);
    for (const step of result.steps) {
      const item = el("div", "source-item agent-step-item");
      const label = step.file_id != null ? `${step.tool} (file #${step.file_id})` : step.tool;
      item.appendChild(el("div", "agent-step-tool", label));
      item.appendChild(el("div", "agent-step-question", step.question));
      item.appendChild(el("div", "agent-step-summary", step.summary));
      details.appendChild(item);
    }
    container.appendChild(details);
  }

  if (result.sources && result.sources.length) {
    const details = document.createElement("details");
    details.className = "sources";
    const summary = document.createElement("summary");
    summary.textContent = `${result.sources.length} document source(s)`;
    details.appendChild(summary);
    for (const s of result.sources) {
      const snippet = s.text.length > 160 ? s.text.slice(0, 160) + "..." : s.text;
      details.appendChild(el("div", "source-item", `${s.filename} (chunk ${s.chunk_index}): ${snippet}`));
    }
    container.appendChild(details);
  }

  if (result.web_sources && result.web_sources.length) {
    const details = document.createElement("details");
    details.className = "sources";
    const summary = document.createElement("summary");
    summary.textContent = `${result.web_sources.length} web result(s)`;
    details.appendChild(summary);
    for (const w of result.web_sources) {
      const item = el("div", "source-item web-source-item");
      const link = document.createElement("a");
      link.href = w.url;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      link.textContent = w.title;
      item.appendChild(link);
      item.appendChild(el("div", "web-source-snippet", w.snippet));
      details.appendChild(item);
    }
    container.appendChild(details);
  }
}

if ($("agent-form")) {
  $("agent-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const input = $("agent-input");
    const question = input.value.trim();
    if (!question) return;
    input.value = "";
    const log = $("agent-log");
    appendMessage(log, "user", question);
    const pending = appendMessage(log, "assistant", "Planning...");
    try {
      const result = await apiJson("/agent/query", "POST", { query: question, allow_web_search: getAllowWebSearch() });
      renderAgentAnswer(pending, result);
    } catch (err) {
      pending.textContent = `Error: ${err.message}`;
    }
    log.scrollTop = log.scrollHeight;
  });
}

// ---------- MARX (education mode) ----------
if ($("marx-form")) {
  $("marx-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const input = $("marx-input");
    const question = input.value.trim();
    if (!question) return;
    input.value = "";
    const log = $("marx-log");
    appendMessage(log, "user", question);
    const pending = appendMessage(log, "assistant", "Thinking...");
    try {
      const result = await apiJson("/rag/marx/query", "POST", { query: question, allow_web_search: getAllowWebSearch() });
      renderAnswerInto(pending, result, question);
    } catch (err) {
      pending.textContent = `Error: ${err.message}`;
    }
    log.scrollTop = log.scrollHeight;
  });
}

// ---------- Init ----------
if (token) {
  startApp();
} else {
  showView("login");
}
