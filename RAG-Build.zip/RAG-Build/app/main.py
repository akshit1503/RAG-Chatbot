import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app.api.routes import audit, health
from app.core.config import get_settings
from app.core.ollama_client import OllamaUnavailableError, ensure_running
from app.core.rate_limit import RateLimitExceededError
from app.modules.agent.routes import router as agent_router
from app.modules.file_access import crud
from app.modules.file_access.database import SessionLocal, init_db
from app.modules.file_access.models import Role
from app.modules.file_access.routes_auth import router as auth_router
from app.modules.file_access.routes_files import router as files_router
from app.modules.file_access.routes_users import router as users_router
from app.modules.file_access.schemas import UserCreate
from app.modules.rag.routes import router as rag_router
from app.modules.text_to_sql.database import init_tabular_db
from app.modules.text_to_sql.routes import router as sql_router
from app.modules.utility.routes import router as utility_router

settings = get_settings()
STATIC_DIR = Path(__file__).resolve().parent.parent / "static"
logger = logging.getLogger(__name__)


def _bootstrap_admin() -> None:
    if not settings.bootstrap_admin_password:
        return
    db = SessionLocal()
    try:
        if crud.count_users(db) == 0:
            crud.create_user(
                db,
                UserCreate(
                    username=settings.bootstrap_admin_username,
                    password=settings.bootstrap_admin_password,
                    department=settings.bootstrap_admin_department,
                ),
                role=Role.admin,
            )
    finally:
        db.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    for path in (
        settings.chroma_persist_dir,
        settings.upload_dir,
        Path(settings.app_db_path).parent,
        Path(settings.sqlite_db_path).parent,
    ):
        Path(path).mkdir(parents=True, exist_ok=True)
    init_db()
    init_tabular_db()
    _bootstrap_admin()

    ollama_ok, ollama_detail = ensure_running()
    if ollama_ok:
        logger.info("Ollama reachable at %s", settings.ollama_host)
    else:
        logger.warning(
            "Ollama is NOT reachable at %s (%s). Auth and file browsing will work, but "
            "chat, indexing, SQL queries, and summarization will fail until it's running "
            "(`ollama serve`).",
            settings.ollama_host,
            ollama_detail,
        )

    yield


class NoCacheStaticFiles(StaticFiles):
    """Force browsers to always revalidate the chat UI's JS/CSS/HTML via a
    conditional request (still cheap -- a 304 when unchanged) instead of
    serving a stale cached copy after a fix ships. Plain StaticFiles relies
    on HTTP heuristic caching here (no explicit Cache-Control), which can
    silently serve stale assets for an unpredictable amount of time.
    """

    async def get_response(self, path: str, scope):
        response = await super().get_response(path, scope)
        response.headers["Cache-Control"] = "no-cache"
        return response


app = FastAPI(
    title=settings.app_name,
    description="Enterprise RAG + Text-to-SQL Chatbot backend (RAG + LLM, per Haque 2025)",
    version="0.1.0",
    lifespan=lifespan,
)

@app.exception_handler(OllamaUnavailableError)
async def ollama_unavailable_handler(request: Request, exc: OllamaUnavailableError) -> JSONResponse:
    return JSONResponse(status_code=503, content={"detail": exc.detail})


@app.exception_handler(RateLimitExceededError)
async def rate_limit_exceeded_handler(request: Request, exc: RateLimitExceededError) -> JSONResponse:
    retry_after = max(1, round(exc.retry_after_seconds))
    return JSONResponse(
        status_code=429,
        content={"detail": f"Rate limit exceeded. Try again in {retry_after}s."},
        headers={"Retry-After": str(retry_after)},
    )


app.include_router(health.router)
app.include_router(audit.router)
app.include_router(auth_router)
app.include_router(users_router)
app.include_router(files_router)
app.include_router(rag_router)
app.include_router(sql_router)
app.include_router(utility_router)
app.include_router(agent_router)

# Mounted last so it only catches paths not matched by an API router above
# (the chat UI at "/", plus its JS/CSS assets).
app.mount("/", NoCacheStaticFiles(directory=STATIC_DIR, html=True), name="frontend")
