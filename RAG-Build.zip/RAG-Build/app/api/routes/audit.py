from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.audit import AuditLog
from app.modules.file_access.database import get_db
from app.modules.file_access.deps import get_current_user
from app.modules.file_access.models import Role, User

router = APIRouter(prefix="/audit", tags=["audit"])


@router.get("")
def list_audit_log(
    action: str | None = Query(default=None, description="Filter to a single action, e.g. 'login' or 'file_upload'"),
    username: str | None = Query(default=None, description="Filter to a single username (admin only -- ignored for non-admins, see below)"),
    limit: int = Query(default=200, le=1000),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Admins can see everyone's activity (optionally filtered to one user);
    # a non-admin can only ever see their own -- this is also what powers
    # the Settings tab's "My recent activity" privacy view, so a regular
    # user gets transparency into what's logged about them without needing
    # elevated access.
    if current_user.role != Role.admin:
        username = current_user.username

    stmt = select(AuditLog).order_by(AuditLog.created_at.desc())
    if action:
        stmt = stmt.where(AuditLog.action == action)
    if username:
        stmt = stmt.where(AuditLog.username == username)
    stmt = stmt.limit(limit)

    rows = db.scalars(stmt).all()
    return [
        {
            "id": r.id,
            "user_id": r.user_id,
            "username": r.username,
            "action": r.action,
            "resource_type": r.resource_type,
            "resource_id": r.resource_id,
            "detail": r.detail,
            "created_at": r.created_at,
        }
        for r in rows
    ]
