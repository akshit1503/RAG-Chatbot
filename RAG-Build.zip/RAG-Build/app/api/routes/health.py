import httpx
from fastapi import APIRouter

from app.core.config import get_settings

router = APIRouter(tags=["health"])


@router.get("/health")
async def health_check():
    settings = get_settings()
    return {"status": "ok", "app_name": settings.app_name, "env": settings.app_env}


@router.get("/health/ollama")
async def ollama_health_check():
    settings = get_settings()
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.get(f"{settings.ollama_host}/api/tags")
            response.raise_for_status()
            data = response.json()
    except httpx.HTTPError as exc:
        return {
            "status": "unreachable",
            "ollama_host": settings.ollama_host,
            "error": str(exc),
        }

    models = [model["name"] for model in data.get("models", [])]
    return {
        "status": "ok",
        "ollama_host": settings.ollama_host,
        "models_available": models,
        "embed_model_pulled": settings.ollama_embed_model in models
        or any(m.startswith(f"{settings.ollama_embed_model}:") for m in models),
        "generation_model_pulled": settings.ollama_generation_model in models
        or any(m.startswith(f"{settings.ollama_generation_model}:") for m in models),
    }
