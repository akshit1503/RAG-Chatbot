from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from app.modules.file_access.models import FileScope, Role


class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=64)
    password: str = Field(min_length=8, max_length=72)
    department: str = Field(min_length=1, max_length=64)


class UserCreateAdmin(UserCreate):
    role: Role = Role.user


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    username: str
    role: Role
    department: str
    created_at: datetime


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class FileOut(BaseModel):
    id: int
    original_filename: str
    content_type: str
    size_bytes: int
    scope: FileScope
    department: str | None
    owner_id: int
    uploaded_at: datetime
    rag_indexed: bool
    sql_ingested: bool
    # Only populated by POST /files/upload, when best-effort auto-indexing/
    # ingestion failed right after upload (e.g. a scanned PDF with no text
    # layer). None everywhere else -- it's upload-response-only context.
    auto_process_warning: str | None = None
