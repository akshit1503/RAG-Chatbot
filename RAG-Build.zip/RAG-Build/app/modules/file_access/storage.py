import uuid
from pathlib import Path

from fastapi import HTTPException, UploadFile, status

from app.core.config import get_settings

settings = get_settings()

_CHUNK_SIZE = 1024 * 1024  # 1 MB read chunks while streaming to disk


def save_upload(file: UploadFile) -> tuple[str, int]:
    """Stream an UploadFile to disk under a random name, enforcing type/size limits.

    Returns (stored_filename, size_bytes).
    """
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in settings.allowed_upload_extensions:
        raise HTTPException(
            status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,
            detail=f"Unsupported file type '{suffix}'. Allowed: {settings.allowed_upload_extensions}",
        )

    # max_upload_size_mb <= 0 means no limit.
    max_bytes = settings.max_upload_size_mb * 1024 * 1024 if settings.max_upload_size_mb > 0 else None
    stored_filename = f"{uuid.uuid4().hex}{suffix}"
    destination = Path(settings.upload_dir) / stored_filename

    size = 0
    try:
        with destination.open("wb") as out_file:
            while chunk := file.file.read(_CHUNK_SIZE):
                size += len(chunk)
                if max_bytes is not None and size > max_bytes:
                    raise HTTPException(
                        status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                        detail=f"File exceeds max upload size of {settings.max_upload_size_mb} MB",
                    )
                out_file.write(chunk)
    except HTTPException:
        destination.unlink(missing_ok=True)
        raise

    return stored_filename, size
