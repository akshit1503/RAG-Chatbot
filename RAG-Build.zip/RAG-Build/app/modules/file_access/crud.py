from sqlalchemy import select
from sqlalchemy.orm import Session

from app.modules.file_access import models, schemas
from app.modules.file_access.security import hash_password


def get_user_by_username(db: Session, username: str) -> models.User | None:
    return db.scalar(select(models.User).where(models.User.username == username))


def count_users(db: Session) -> int:
    return db.query(models.User).count()


def create_user(db: Session, user_in: schemas.UserCreate, role: models.Role = models.Role.user) -> models.User:
    user = models.User(
        username=user_in.username,
        hashed_password=hash_password(user_in.password),
        role=role,
        department=user_in.department,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def create_file_record(
    db: Session,
    *,
    original_filename: str,
    stored_filename: str,
    content_type: str,
    size_bytes: int,
    scope: models.FileScope,
    department: str | None,
    owner_id: int,
) -> models.FileRecord:
    record = models.FileRecord(
        original_filename=original_filename,
        stored_filename=stored_filename,
        content_type=content_type,
        size_bytes=size_bytes,
        scope=scope,
        department=department,
        owner_id=owner_id,
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return record


def get_file_by_id(db: Session, file_id: int) -> models.FileRecord | None:
    return db.get(models.FileRecord, file_id)


def list_files(db: Session) -> list[models.FileRecord]:
    return list(db.scalars(select(models.FileRecord).order_by(models.FileRecord.uploaded_at.desc())))


def delete_file_record(db: Session, record: models.FileRecord) -> None:
    db.delete(record)
    db.commit()
