import logging
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.core.audit import log_event
from app.core.config import get_settings
from app.modules.file_access import crud, rbac, schemas
from app.modules.file_access.database import get_db
from app.modules.file_access.deps import get_current_user
from app.modules.file_access.models import FileRecord, FileScope, User
from app.modules.file_access.storage import save_upload
from app.modules.rag.service import deindex_file, get_index_status, index_document
from app.modules.text_to_sql.service import get_dataset, ingest_dataset, remove_dataset

router = APIRouter(prefix="/files", tags=["files"])
settings = get_settings()
logger = logging.getLogger(__name__)

_RAG_DOCUMENT_SUFFIXES = {".pdf", ".docx", ".txt", ".md"}
_TABULAR_SUFFIXES = {".csv", ".xlsx", ".xls"}


def _to_file_out(db: Session, record: FileRecord) -> schemas.FileOut:
    return schemas.FileOut(
        id=record.id,
        original_filename=record.original_filename,
        content_type=record.content_type,
        size_bytes=record.size_bytes,
        scope=record.scope,
        department=record.department,
        owner_id=record.owner_id,
        uploaded_at=record.uploaded_at,
        rag_indexed=get_index_status(db, record.id) is not None,
        sql_ingested=get_dataset(db, record.id) is not None,
    )


def _auto_process(db: Session, record: FileRecord) -> str | None:
    """Best-effort auto-index/ingest right after upload, so a file is
    immediately searchable without a separate manual step. Failures here
    (e.g. Ollama unreachable, a malformed file) don't fail the upload --
    the existing manual /rag and /sql endpoints remain available to retry.
    Returns a warning message if auto-processing failed, else None, so the
    caller can surface it instead of silently leaving the file un-indexed.
    """
    suffix = Path(record.stored_filename).suffix.lower()
    try:
        if suffix in _RAG_DOCUMENT_SUFFIXES:
            index_document(db, record)
        elif suffix in _TABULAR_SUFFIXES:
            ingest_dataset(db, record)
    except Exception as exc:
        logger.warning("Auto-processing failed for file %s (%s)", record.id, record.original_filename, exc_info=True)
        return str(exc)
    return None


@router.post("/upload", response_model=schemas.FileOut, status_code=status.HTTP_201_CREATED)
def upload_file(
    file: UploadFile = File(...),
    scope: FileScope = Form(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if not rbac.can_upload_scope(current_user.role, scope):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Role '{current_user.role.value}' cannot upload to scope '{scope.value}'",
        )

    stored_filename, size_bytes = save_upload(file)
    department = current_user.department if scope != FileScope.global_ else None

    record = crud.create_file_record(
        db,
        original_filename=file.filename or stored_filename,
        stored_filename=stored_filename,
        content_type=file.content_type or "application/octet-stream",
        size_bytes=size_bytes,
        scope=scope,
        department=department,
        owner_id=current_user.id,
    )
    warning = _auto_process(db, record)
    file_out = _to_file_out(db, record)
    file_out.auto_process_warning = warning
    log_event(
        db,
        user_id=current_user.id,
        username=current_user.username,
        action="file_upload",
        resource_type="file",
        resource_id=record.id,
        detail=f"{record.original_filename} ({scope.value})",
    )
    return file_out


@router.get("", response_model=list[schemas.FileOut])
def list_files(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    visible = [f for f in crud.list_files(db) if rbac.can_view_file(current_user, f)]
    return [_to_file_out(db, f) for f in visible]


@router.get("/{file_id}", response_model=schemas.FileOut)
def get_file_metadata(file_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    record = crud.get_file_by_id(db, file_id)
    if record is None or not rbac.can_view_file(current_user, record):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found")
    return _to_file_out(db, record)


@router.get("/{file_id}/download")
def download_file(file_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    record = crud.get_file_by_id(db, file_id)
    if record is None or not rbac.can_view_file(current_user, record):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found")

    path = Path(settings.upload_dir) / record.stored_filename
    if not path.exists():
        raise HTTPException(status_code=status.HTTP_410_GONE, detail="Stored file is missing on disk")
    log_event(
        db,
        user_id=current_user.id,
        username=current_user.username,
        action="file_download",
        resource_type="file",
        resource_id=record.id,
        detail=record.original_filename,
    )
    return FileResponse(path, filename=record.original_filename, media_type=record.content_type)


@router.delete("/{file_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_file(file_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    record = crud.get_file_by_id(db, file_id)
    if record is None or not rbac.can_view_file(current_user, record):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found")
    if not rbac.can_delete_file(current_user, record):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Not allowed to delete this file")

    deindex_file(db, record.id)
    remove_dataset(db, record.id)
    (Path(settings.upload_dir) / record.stored_filename).unlink(missing_ok=True)
    log_event(
        db,
        user_id=current_user.id,
        username=current_user.username,
        action="file_delete",
        resource_type="file",
        resource_id=record.id,
        detail=record.original_filename,
    )
    crud.delete_file_record(db, record)
