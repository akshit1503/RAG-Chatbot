"""Permission rules for the personal / departmental / global file access model.

Interpretation (the paper specifies the three roles and three scopes but not
the exact matrix between them):
  - personal:     visible only to the file's owner (and admins)
  - departmental: visible to operators and admins within the same department
                  as the file (and admins across departments)
  - global:       visible to any authenticated user

Upload rights scale with role: any role may upload personal files; only
operator/admin may upload departmental files; only admin may upload global
files. Deletion is restricted to the file's owner or an admin.
"""

from app.modules.file_access.models import FileRecord, FileScope, Role, User


def can_upload_scope(role: Role, scope: FileScope) -> bool:
    if scope == FileScope.personal:
        return True
    if scope == FileScope.departmental:
        return role in (Role.operator, Role.admin)
    if scope == FileScope.global_:
        return role == Role.admin
    return False


def can_view_file(user: User, file: FileRecord) -> bool:
    if user.role == Role.admin:
        return True
    if file.scope == FileScope.global_:
        return True
    if file.scope == FileScope.personal:
        return file.owner_id == user.id
    if file.scope == FileScope.departmental:
        return user.role in (Role.operator, Role.admin) and user.department == file.department
    return False


def can_delete_file(user: User, file: FileRecord) -> bool:
    if user.role == Role.admin:
        return True
    return file.owner_id == user.id
