from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.modules.file_access import crud, schemas
from app.modules.file_access.database import get_db
from app.modules.file_access.deps import require_role
from app.modules.file_access.models import Role, User

router = APIRouter(prefix="/users", tags=["users"])


@router.post("", response_model=schemas.UserOut, status_code=status.HTTP_201_CREATED)
def create_user(
    user_in: schemas.UserCreateAdmin,
    db: Session = Depends(get_db),
    _admin: User = Depends(require_role(Role.admin)),
) -> User:
    """Admin-only: create a user with an explicit role (operator/admin included)."""
    if crud.get_user_by_username(db, user_in.username):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Username already taken")
    return crud.create_user(db, user_in, role=user_in.role)
