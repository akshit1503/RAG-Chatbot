import enum
from datetime import datetime, timezone

from sqlalchemy import DateTime, Enum, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.modules.file_access.database import Base


class DocumentIndex(Base):
    """Tracks which uploaded files have been chunked/embedded into ChromaDB.

    Lives on the shared Base/app metadata DB (keyed by file_id) rather than
    a RAG-specific database, since it's small bookkeeping tightly coupled to
    the files table, not the document content itself (that lives in Chroma).
    """

    __tablename__ = "document_index"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    file_id: Mapped[int] = mapped_column(ForeignKey("files.id"), unique=True, nullable=False)
    chunk_count: Mapped[int] = mapped_column(Integer, nullable=False)
    indexed_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))


class FeedbackRating(str, enum.Enum):
    up = "up"
    down = "down"


class AnswerFeedback(Base):
    """A user's thumbs-up/down on a single answer, plus enough of the
    question/answer/source to review later without needing to replay the
    chat session it came from (chat history itself is client-side only).
    """

    __tablename__ = "answer_feedback"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    question: Mapped[str] = mapped_column(Text, nullable=False)
    answer: Mapped[str] = mapped_column(Text, nullable=False)
    source: Mapped[str] = mapped_column(String(32), nullable=False)
    rating: Mapped[FeedbackRating] = mapped_column(
        Enum(FeedbackRating, values_callable=lambda enum_cls: [member.value for member in enum_cls]),
        nullable=False,
    )
    comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))
