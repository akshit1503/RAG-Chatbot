DEFAULT_SEPARATORS = ["\n\n", "\n", ". ", " ", ""]


class RecursiveCharacterTextSplitter:
    """Splits text into ~chunk_size character chunks with chunk_overlap.

    Tries progressively finer separators (paragraph, line, sentence, word,
    character) so splits land on natural boundaries where possible, per the
    chunking strategy described in the paper (Haque, 2025): ~1000 chars,
    100-char overlap.
    """

    def __init__(self, chunk_size: int = 1000, chunk_overlap: int = 100, separators: list[str] | None = None):
        if chunk_overlap >= chunk_size:
            raise ValueError("chunk_overlap must be smaller than chunk_size")
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.separators = separators or DEFAULT_SEPARATORS

    def split_text(self, text: str) -> list[str]:
        return [chunk for chunk in self._split(text, self.separators) if chunk.strip()]

    def _split(self, text: str, separators: list[str]) -> list[str]:
        if not text:
            return []

        separator = separators[-1]
        next_separators: list[str] = []
        for i, candidate in enumerate(separators):
            if candidate == "" or candidate in text:
                separator = candidate
                next_separators = separators[i + 1 :]
                break

        pieces = list(text) if separator == "" else text.split(separator)
        pieces = [p for p in pieces if p != ""]

        chunks: list[str] = []
        buffer: list[str] = []
        for piece in pieces:
            if len(piece) < self.chunk_size:
                buffer.append(piece)
                continue
            if buffer:
                chunks.extend(self._merge(buffer, separator))
                buffer = []
            chunks.extend(self._split(piece, next_separators) if next_separators else [piece])
        if buffer:
            chunks.extend(self._merge(buffer, separator))
        return chunks

    def _merge(self, pieces: list[str], separator: str) -> list[str]:
        chunks: list[str] = []
        window: list[str] = []

        for piece in pieces:
            if window and len(separator.join(window + [piece])) > self.chunk_size:
                chunks.append(separator.join(window))
                while window and len(separator.join(window)) > self.chunk_overlap:
                    window.pop(0)
            window.append(piece)

        if window:
            chunks.append(separator.join(window))
        return chunks
