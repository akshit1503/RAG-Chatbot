import chromadb
from chromadb.config import Settings as ChromaSettings

from app.core.config import get_settings
from app.modules.file_access.models import FileScope, Role, User

settings = get_settings()

_COLLECTION_NAME = "documents"

_client = chromadb.PersistentClient(
    path=settings.chroma_persist_dir,
    settings=ChromaSettings(anonymized_telemetry=False),
)


def get_collection():
    # Cosine similarity per the paper's retrieval spec; embeddings are
    # supplied explicitly (Ollama) so Chroma's default embedding function
    # (which would otherwise download its own model) is never invoked.
    return _client.get_or_create_collection(name=_COLLECTION_NAME, metadata={"hnsw:space": "cosine"})


def add_chunks(
    *,
    file_id: int,
    chunks: list[str],
    embeddings: list[list[float]],
    owner_id: int,
    scope: FileScope,
    department: str | None,
    filename: str,
) -> None:
    collection = get_collection()
    ids = [f"{file_id}:{i}" for i in range(len(chunks))]
    metadatas = [
        {
            "file_id": file_id,
            "chunk_index": i,
            "owner_id": owner_id,
            "scope": scope.value,
            "department": department or "",
            "filename": filename,
        }
        for i in range(len(chunks))
    ]
    collection.add(ids=ids, documents=chunks, embeddings=embeddings, metadatas=metadatas)


def delete_document(file_id: int) -> None:
    collection = get_collection()
    collection.delete(where={"file_id": {"$eq": file_id}})


def build_access_filter(user: User) -> dict | None:
    """Mirror app.modules.file_access.rbac.can_view_file as a Chroma 'where' filter."""
    if user.role == Role.admin:
        return None

    clauses = [
        {"$and": [{"scope": {"$eq": FileScope.personal.value}}, {"owner_id": {"$eq": user.id}}]},
        {"scope": {"$eq": FileScope.global_.value}},
    ]
    if user.role == Role.operator:
        clauses.append(
            {
                "$and": [
                    {"scope": {"$eq": FileScope.departmental.value}},
                    {"department": {"$eq": user.department}},
                ]
            }
        )
    return {"$or": clauses}


def query_chunks(*, query_embedding: list[float], top_k: int, user: User) -> dict:
    collection = get_collection()
    return collection.query(
        query_embeddings=[query_embedding],
        n_results=top_k,
        where=build_access_filter(user),
        # embeddings included (Chroma omits them by default) so the caller
        # can run MMR reranking, which needs pairwise similarity between
        # candidates, not just each one's distance to the query.
        include=["documents", "metadatas", "distances", "embeddings"],
    )


def metadata_allows(user: User, meta: dict) -> bool:
    """Mirror rbac.can_view_file, but against a raw Chroma metadata dict
    instead of a FileRecord. Needed when chunks are fetched directly by ID
    (get_chunks_by_ids) rather than through query_chunks()'s 'where' filter
    -- RBAC must still be enforced on that path, not just at search time.
    """
    if user.role == Role.admin:
        return True
    if meta["scope"] == FileScope.global_.value:
        return True
    if meta["scope"] == FileScope.personal.value:
        return meta["owner_id"] == user.id
    if meta["scope"] == FileScope.departmental.value:
        return user.role in (Role.operator, Role.admin) and user.department == meta["department"]
    return False


def get_chunks_by_ids(chunk_ids: list[str]) -> dict:
    collection = get_collection()
    return collection.get(ids=chunk_ids)
