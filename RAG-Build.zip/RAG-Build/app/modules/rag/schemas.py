from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict


class IndexResult(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    file_id: int
    chunk_count: int
    indexed_at: datetime


class SourceChunk(BaseModel):
    file_id: int
    filename: str
    chunk_index: int
    text: str
    distance: float | None = None


class WebSource(BaseModel):
    title: str
    url: str
    snippet: str


class ChatTurn(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class QueryRequest(BaseModel):
    query: str
    top_k: int | None = None
    # Recent prior turns from the same chat session (frontend sends a short
    # rolling window), so the model can resolve follow-ups like "and its
    # population?" without the user having to repeat context. This feeds
    # generation only -- retrieval still embeds just the raw current
    # question, so a follow-up whose topic isn't restated may not retrieve
    # well. Query rewriting for retrieval is a documented future step, not
    # done here (see TechStack.md).
    history: list[ChatTurn] = []
    # Per-request privacy control (Settings tab): when false, the web-search
    # fallback tier is skipped for this request even if the server has it
    # enabled globally, so a user who doesn't want their questions leaving
    # the box for a DuckDuckGo lookup can opt out without an admin having to
    # disable it for everyone.
    allow_web_search: bool = True


# Where an answer actually came from -- the frontend must render each of
# these with a visibly different treatment so a user never mistakes a
# web-search or general-knowledge answer for one grounded in their own
# documents. "insufficient" is MARX-only: unlike the main chat flow, MARX
# never falls through to ungrounded general knowledge -- if neither the
# student's documents nor the web cover the question, it says so plainly
# rather than answering from raw parametric memory (see the MARX entry in
# TechStack.md for why: a tutor silently mixing in unstated outside
# knowledge is bad pedagogy, the student can't tell what they're
# responsible for knowing).
AnswerSource = Literal["documents", "web", "general_knowledge", "insufficient"]


class QueryResponse(BaseModel):
    answer: str
    sources: list[SourceChunk] = []
    web_sources: list[WebSource] = []
    source: AnswerSource = "documents"


class TopicOption(BaseModel):
    topic_id: str
    label: str
    file_id: int
    filename: str
    chunk_index: int
    preview: str


class TopicsRequest(BaseModel):
    query: str
    top_k: int | None = None
    history: list[ChatTurn] = []
    allow_web_search: bool = True


class TopicsResponse(BaseModel):
    query: str
    topics: list[TopicOption]
    # Populated instead of `topics` when the top matches are dominated by a
    # single source document -- nothing to disambiguate, so the question is
    # answered directly rather than making the user pick every time.
    direct_answer: QueryResponse | None = None
    # True when `topics` is every indexed document (answering a meta-
    # question like "what topics do you have"), not a set of candidates to
    # disambiguate a real content question. The frontend must render this
    # as a plain informational list, not the interactive picker -- picking
    # documents here and hitting "Get answer" would just re-ask the literal
    # meta-question against whichever files got checked, which produces a
    # real but confusingly-repetitive-looking LLM answer instead of what
    # the user actually wants (to see what's available, then ask a real
    # follow-up question of their own).
    is_document_list: bool = False


class AnswerFromTopicsRequest(BaseModel):
    query: str
    topic_ids: list[str]
    history: list[ChatTurn] = []
    allow_web_search: bool = True


FeedbackRatingValue = Literal["up", "down"]


class FeedbackRequest(BaseModel):
    question: str
    answer: str
    source: AnswerSource
    rating: FeedbackRatingValue
    comment: str | None = None


class FeedbackOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    user_id: int
    question: str
    answer: str
    source: str
    rating: FeedbackRatingValue
    comment: str | None
    created_at: datetime
