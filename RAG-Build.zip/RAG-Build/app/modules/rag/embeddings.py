from app.core.ollama_client import embed as _embed

_BATCH_SIZE = 32


def embed_texts(texts: list[str]) -> list[list[float]]:
    """Embed a batch of chunks via Ollama, preserving input order."""
    if not texts:
        return []

    embeddings: list[list[float]] = []
    for start in range(0, len(texts), _BATCH_SIZE):
        batch = texts[start : start + _BATCH_SIZE]
        embeddings.extend(_embed(batch))
    return embeddings


def embed_query(text: str) -> list[float]:
    return _embed([text])[0]
