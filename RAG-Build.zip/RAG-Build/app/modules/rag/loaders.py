import base64
import logging
from pathlib import Path

import docx
import pymupdf
from pypdf import PdfReader

from app.core.config import get_settings
from app.core.ollama_client import generate_vision

settings = get_settings()
logger = logging.getLogger(__name__)

_OCR_PROMPT = (
    "Transcribe all text visible in this document page as accurately as possible. "
    "Preserve structure using Markdown (tables, headings, lists) where the page has "
    "structure. Output only the transcribed content, no commentary."
)


class UnsupportedDocumentType(Exception):
    pass


def extract_text(path: Path, suffix: str) -> str:
    """Extract raw text from a stored upload for RAG chunking.

    Only unstructured document types are supported here; CSV/Excel files
    are handled by the Text-to-SQL module instead.
    """
    suffix = suffix.lower()
    if suffix == ".pdf":
        return _extract_pdf(path)
    if suffix == ".docx":
        return _extract_docx(path)
    if suffix in (".txt", ".md"):
        return path.read_text(encoding="utf-8", errors="replace")
    raise UnsupportedDocumentType(f"RAG ingestion does not support '{suffix}' files")


def _extract_pdf(path: Path) -> str:
    reader = PdfReader(str(path))
    pages = [page.extract_text() or "" for page in reader.pages]
    text = "\n\n".join(pages)
    if text.strip():
        return text
    # No extractable text layer -- likely a scanned document. Fall back to
    # OCR via a vision model rather than failing outright.
    logger.info("No text layer in '%s', falling back to vision OCR", path.name)
    return _ocr_pdf(path)


def _ocr_pdf(path: Path) -> str:
    doc = pymupdf.open(str(path))
    try:
        # max_ocr_pages <= 0 means no limit.
        page_count = min(len(doc), settings.max_ocr_pages) if settings.max_ocr_pages > 0 else len(doc)
        transcripts = []
        for i in range(page_count):
            pixmap = doc[i].get_pixmap(dpi=150)
            image_b64 = base64.b64encode(pixmap.tobytes("png")).decode()
            transcripts.append(generate_vision(_OCR_PROMPT, image_b64))
        return "\n\n".join(transcripts)
    finally:
        doc.close()


def _extract_docx(path: Path) -> str:
    document = docx.Document(str(path))
    return "\n\n".join(paragraph.text for paragraph in document.paragraphs)
