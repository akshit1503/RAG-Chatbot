import math
import re
from collections import Counter

_TOKEN_RE = re.compile(r"[a-z0-9]+")


def _tokenize(text: str) -> list[str]:
    return _TOKEN_RE.findall(text.lower())


def bm25_scores(query: str, documents: list[str], k1: float = 1.5, b: float = 0.75) -> list[float]:
    """Minimal BM25 over an in-memory candidate set. This deliberately isn't
    a full-corpus inverted index -- it scores only the handful of chunks a
    vector search already narrowed down to (see hybrid_rank below), so a
    plain O(n) implementation is fine and avoids pulling in a separate
    search engine (Elasticsearch/Whoosh/etc.) for what's a small re-ranking
    step, not primary retrieval.
    """
    query_terms = _tokenize(query)
    if not query_terms or not documents:
        return [0.0] * len(documents)

    doc_tokens = [_tokenize(d) for d in documents]
    doc_lens = [len(toks) for toks in doc_tokens]
    avg_len = (sum(doc_lens) / len(doc_lens)) if doc_lens else 0.0

    n_docs = len(documents)
    doc_freq: Counter = Counter()
    for toks in doc_tokens:
        for term in set(toks):
            doc_freq[term] += 1

    scores = [0.0] * n_docs
    for i, toks in enumerate(doc_tokens):
        term_counts = Counter(toks)
        doc_len = doc_lens[i] or 1
        for term in query_terms:
            tf = term_counts.get(term)
            if not tf:
                continue
            df = doc_freq.get(term, 0)
            idf = math.log(1 + (n_docs - df + 0.5) / (df + 0.5))
            denom = tf + k1 * (1 - b + b * doc_len / (avg_len or 1))
            scores[i] += idf * (tf * (k1 + 1)) / (denom or 1)
    return scores


def reciprocal_rank_fusion(vector_ranked_indices: list[int], keyword_scores: list[float], k: int = 60) -> list[int]:
    """Fuses a vector-similarity ranking with a keyword (BM25) ranking using
    Reciprocal Rank Fusion: each item's score is 1/(k+rank) summed across
    both rankings, so an item doesn't need to be top-ranked by both signals
    to surface -- being strong on either (an exact keyword hit a vector
    search under-weights, or a semantic match with no literal keyword
    overlap) is enough to rank well. `k=60` is the standard RRF constant
    from the original paper (Cormack et al., 2009) -- large enough that a
    single top-1 hit doesn't dominate the fused score.

    `vector_ranked_indices` are indices into the candidate list, already in
    vector-similarity order (best first, as Chroma returns them).
    `keyword_scores` are BM25 scores in the *original* candidate order (not
    rank order) -- this function ranks them internally.

    Returns indices into the candidate list, reordered by fused score
    (best first).
    """
    n = len(vector_ranked_indices)
    vector_rank_of = {idx: rank for rank, idx in enumerate(vector_ranked_indices)}

    keyword_ranked_indices = sorted(range(n), key=lambda i: keyword_scores[i], reverse=True)
    keyword_rank_of = {idx: rank for rank, idx in enumerate(keyword_ranked_indices)}

    fused_scores = {
        i: 1.0 / (k + vector_rank_of[i]) + 1.0 / (k + keyword_rank_of[i])
        for i in range(n)
    }
    return sorted(range(n), key=lambda i: fused_scores[i], reverse=True)


def hybrid_rank(question: str, candidates: list[dict], top_k: int) -> list[dict]:
    """Re-ranks a vector-search candidate list (already in vector-similarity
    order) by fusing it with a BM25 keyword ranking over the same
    candidates, then returns the top_k. A no-op passthrough (just a slice)
    when there's nothing meaningful to fuse -- 0 or 1 candidates, or a
    query with no scoreable keyword terms (BM25 all-zero).
    """
    if len(candidates) <= 1:
        return candidates[:top_k]

    texts = [c["text"] for c in candidates]
    keyword_scores = bm25_scores(question, texts)
    if not any(keyword_scores):
        return candidates[:top_k]

    vector_order = list(range(len(candidates)))
    fused_order = reciprocal_rank_fusion(vector_order, keyword_scores)
    return [candidates[i] for i in fused_order[:top_k]]
