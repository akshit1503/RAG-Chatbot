import math


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def mmr_rerank(candidates: list[dict], top_k: int, lambda_mult: float = 0.7) -> list[dict]:
    """Maximal Marginal Relevance: picks a final top_k from an already
    relevance-ranked candidate list (e.g. the output of hybrid_search's
    RRF fusion), balancing each candidate's relevance against how similar
    it is to chunks already selected. Without this, a small context window
    can end up dominated by 3-4 near-duplicate chunks (adjacent paragraphs
    covering the same point) purely because they're all individually
    relevant, crowding out a genuinely different piece of information
    ranked just below them.

    lambda_mult=1.0 is pure relevance (no diversity penalty, equivalent to
    a plain truncation); 0.0 is pure diversity (ignores relevance
    entirely). 0.7 is a common default that favors relevance while still
    meaningfully penalizing redundancy.

    Fails open (falls back to a plain top_k truncation, preserving the
    incoming order) if there aren't enough candidates to matter, or if any
    candidate is missing an embedding (e.g. chunks fetched directly by ID
    via answer_from_topics, which don't currently carry embeddings) --
    diversity can't be computed without one, and a hard failure here would
    take down the whole answer over what's just a quality refinement.
    """
    if len(candidates) <= top_k:
        return candidates
    if any(c.get("embedding") is None for c in candidates):
        return candidates[:top_k]

    def relevance(c: dict) -> float:
        # Chroma's cosine distance is 1 - cosine_similarity, so this
        # recovers a relevance score in the same direction as similarity
        # (higher = more relevant). Chunks with no distance (shouldn't
        # happen here, but defensively) are treated as neutral.
        d = c.get("distance")
        return 1.0 - d if d is not None else 0.5

    selected: list[int] = []
    remaining = list(range(len(candidates)))

    while remaining and len(selected) < top_k:
        if not selected:
            # First pick: whatever's already ranked best -- no prior
            # selection to be redundant with yet.
            chosen = remaining[0]
        else:
            chosen = remaining[0]
            best_score = None
            for idx in remaining:
                max_sim_to_selected = max(
                    _cosine_similarity(candidates[idx]["embedding"], candidates[s]["embedding"])
                    for s in selected
                )
                score = lambda_mult * relevance(candidates[idx]) - (1 - lambda_mult) * max_sim_to_selected
                if best_score is None or score > best_score:
                    best_score = score
                    chosen = idx
        selected.append(chosen)
        remaining.remove(chosen)

    return [candidates[i] for i in selected]
