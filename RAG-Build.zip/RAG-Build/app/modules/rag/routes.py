from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.audit import log_event
from app.core.config import get_settings
from app.core.rate_limit import check_rate_limit
from app.modules.file_access import crud, rbac
from app.modules.file_access.database import get_db
from app.modules.file_access.deps import get_current_user
from app.modules.file_access.models import Role, User
from app.modules.rag import schemas, service
from app.modules.rag.loaders import UnsupportedDocumentType

router = APIRouter(prefix="/rag", tags=["rag"])
settings = get_settings()

# Server-side cap on how much history is ever fed into a prompt, regardless
# of what the client sends -- keeps prompt size bounded even if a client
# sends a much longer window than intended.
_MAX_HISTORY_TURNS = 10


def _history_dicts(history: list[schemas.ChatTurn]) -> list[dict]:
    return [turn.model_dump() for turn in history[-_MAX_HISTORY_TURNS:]]


@router.post("/documents/{file_id}/index", response_model=schemas.IndexResult, status_code=status.HTTP_201_CREATED)
def index_document(file_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    file = crud.get_file_by_id(db, file_id)
    if file is None or not rbac.can_view_file(current_user, file):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found")
    if not rbac.can_delete_file(current_user, file):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Only the file owner or an admin may index it")

    try:
        return service.index_document(db, file)
    except UnsupportedDocumentType as exc:
        raise HTTPException(status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)) from exc


@router.get("/documents/{file_id}/index", response_model=schemas.IndexResult)
def get_index_status(file_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    file = crud.get_file_by_id(db, file_id)
    if file is None or not rbac.can_view_file(current_user, file):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found")

    record = service.get_index_status(db, file_id)
    if record is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File has not been indexed yet")
    return record


@router.post("/query", response_model=schemas.QueryResponse)
def query(request: schemas.QueryRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    check_rate_limit(current_user.id, "rag_query")
    top_k = request.top_k or settings.retrieval_top_k
    result = service.answer_query(
        current_user, request.query, top_k, _history_dicts(request.history), request.allow_web_search
    )
    log_event(
        db, user_id=current_user.id, username=current_user.username,
        action="rag_query", resource_type="answer_source", resource_id=result.get("source"), detail=request.query,
    )
    return schemas.QueryResponse(**result)


@router.post("/topics", response_model=schemas.TopicsResponse)
def discover_topics(request: schemas.TopicsRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    check_rate_limit(current_user.id, "rag_query")
    top_k = request.top_k or settings.retrieval_top_k * 2
    result = service.ask(
        current_user, request.query, top_k, _history_dicts(request.history), request.allow_web_search
    )

    direct_answer = None
    if result["answer"] is not None:
        direct_answer = schemas.QueryResponse(**{k: v for k, v in result.items() if k != "topics"})

    log_event(
        db, user_id=current_user.id, username=current_user.username,
        action="rag_query", resource_type="answer_source",
        resource_id=(result.get("source") if direct_answer else "topic_picker"), detail=request.query,
    )
    return schemas.TopicsResponse(
        query=request.query,
        topics=result["topics"],
        direct_answer=direct_answer,
        is_document_list=result.get("is_document_list", False),
    )


@router.post("/query/from-topics", response_model=schemas.QueryResponse)
def query_from_topics(request: schemas.AnswerFromTopicsRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    check_rate_limit(current_user.id, "rag_query")
    if not request.topic_ids:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Select at least one topic")
    result = service.answer_from_topics(
        current_user, request.query, request.topic_ids, _history_dicts(request.history), request.allow_web_search
    )
    log_event(
        db, user_id=current_user.id, username=current_user.username,
        action="rag_query", resource_type="answer_source", resource_id=result.get("source"), detail=request.query,
    )
    return schemas.QueryResponse(**result)


@router.post("/marx/query", response_model=schemas.QueryResponse)
def marx_query(request: schemas.QueryRequest, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    check_rate_limit(current_user.id, "rag_query")
    top_k = request.top_k or settings.retrieval_top_k
    result = service.answer_marx_query(
        current_user, request.query, top_k, _history_dicts(request.history), request.allow_web_search
    )
    log_event(
        db, user_id=current_user.id, username=current_user.username,
        action="marx_query", resource_type="answer_source", resource_id=result.get("source"), detail=request.query,
    )
    return schemas.QueryResponse(**result)


@router.post("/feedback", response_model=schemas.FeedbackOut, status_code=status.HTTP_201_CREATED)
def submit_feedback(
    request: schemas.FeedbackRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    entry = service.record_feedback(
        db, current_user, request.question, request.answer, request.source, request.rating, request.comment
    )
    return entry


@router.get("/feedback", response_model=list[schemas.FeedbackOut])
def get_feedback(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    if current_user.role != Role.admin:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin only")
    return service.list_feedback(db)
