import json
import re

from app.core.ollama_client import generate as _generate

# A distinctive, made-up token rather than a free-text phrase like "I don't
# know" -- free text is easy for a model to phrase a dozen slightly
# different ways, which makes it unreliable to detect programmatically.
# Checking for this exact token is robust regardless of wording.
INSUFFICIENT_CONTEXT_SENTINEL = "INSUFFICIENT_CONTEXT"

# A real bug found and fixed: this instruction originally existed only on
# the document-grounded prompt, not on the general-knowledge, web, or
# MARX-web prompts -- so a math question landing on any of those other
# three tiers came back with the model's own default delimiters (`\[...\]`,
# `\(...\)`), which static/app.js's renderMarkdown() doesn't recognize
# (only `$$...$$` and `$...$`), rendering as broken raw text instead of a
# formula. Caught by testing a real math question end-to-end, not by
# reading the code. Pulled into one shared constant, interpolated into
# every prompt tier below, so this can't drift out of sync again the way
# it silently did the first time.
_LATEX_INSTRUCTIONS = """
If the answer involves a mathematical formula or equation, reproduce it as real LaTeX, wrapped in $$ on its own line for a standalone equation, or $...$ inline within a sentence. Always use one of these two delimiter styles -- never \\[...\\] or \\(...\\), and never write LaTeX commands (\\sum, \\alpha, \\frac, etc.) outside of $ delimiters. For example, write:

$$a_i = \\sum_{{j \\le i}} \\alpha_{{ij}} x_j$$

not "a_i = sum_j(alpha_ij * x_j)", not "\\[a_i = \\sum_{{j \\le i}} \\alpha_{{ij}} x_j\\]", and not a bare "\\sum_{{j \\le i}}" outside of $ signs."""

# The frontend (static/app.js renderMarkdown()) already extracts ```mermaid
# fenced code blocks and renders them as real diagrams via the vendored
# mermaid.js library -- the model just needs to know it's allowed to
# produce that syntax. Kept as its own constant (not folded into
# _LATEX_INSTRUCTIONS) since it's only wired into the tiers where a
# diagram is likely to actually help (document-grounded and MARX), not
# the general-knowledge/web tiers.
_MERMAID_INSTRUCTIONS = """
If a flowchart, process, sequence, or relationship diagram would help explain the answer, you may include one as a Mermaid diagram in a fenced code block, e.g.:

```mermaid
flowchart TD
    A[Start] --> B{{Decision}}
    B -->|Yes| C[Do X]
    B -->|No| D[Do Y]
```

Node labels must be plain text or, if they contain punctuation like parentheses, slashes, or colons, wrapped in double quotes -- e.g. write C["File sync policy (always/everysec/no)"], never C[File sync policy (always/everysec/no)], since unquoted punctuation like that breaks the diagram. Only include one if it genuinely clarifies a process or relationship described in the material -- don't add one for simple factual answers."""

_PROMPT_TEMPLATE = """You are an enterprise document assistant. Answer the user's question using ONLY the context below. If the context does not contain the answer, respond with EXACTLY this and nothing else: """ + INSUFFICIENT_CONTEXT_SENTINEL + """

Format the answer in Markdown where it helps readability (bold for key terms, bullet lists for multiple points, tables for structured comparisons). Keep it concise.
""" + _LATEX_INSTRUCTIONS + _MERMAID_INSTRUCTIONS + """
{history}
Context:
{context}

Question: {question}

Answer:"""

_FALLBACK_PROMPT_TEMPLATE = """Answer the following question using your own general knowledge. Be accurate and concise, and say so if you're not confident. Format the answer in Markdown where it helps readability.
""" + _LATEX_INSTRUCTIONS + """
{history}
Question: {question}

Answer:"""

_WEB_PROMPT_TEMPLATE = """Answer the user's question using ONLY the web search results below. Cite sources inline using [1], [2], etc. matching the numbered results below. If the results don't actually answer the question, respond with EXACTLY this and nothing else: """ + INSUFFICIENT_CONTEXT_SENTINEL + """

Format the answer in Markdown where it helps readability.
""" + _LATEX_INSTRUCTIONS + """
{history}
Search results:
{results}

Question: {question}

Answer:"""


def _format_history(history: list[dict] | None) -> str:
    """Recent-turns block inserted into every prompt tier, so a follow-up
    like "and its population?" can be resolved against what was just
    discussed. Empty string (not even a heading) when there's no history,
    so the prompt reads identically to before this feature for a fresh chat.
    """
    if not history:
        return ""
    lines = "\n".join(f"{turn['role'].capitalize()}: {turn['content']}" for turn in history)
    return f"\nRecent conversation (for context on follow-up questions):\n{lines}\n"


def build_prompt(question: str, context_chunks: list[dict], history: list[dict] | None = None) -> str:
    context = "\n\n".join(
        f"[Source {i + 1}: {chunk['filename']}, chunk {chunk['chunk_index']}]\n{chunk['text']}"
        for i, chunk in enumerate(context_chunks)
    )
    return _PROMPT_TEMPLATE.format(
        context=context or "(no relevant context found)", question=question, history=_format_history(history)
    )


def build_fallback_prompt(question: str, history: list[dict] | None = None) -> str:
    return _FALLBACK_PROMPT_TEMPLATE.format(question=question, history=_format_history(history))


def build_web_prompt(question: str, web_results: list[dict], history: list[dict] | None = None) -> str:
    results_text = "\n\n".join(
        f"[{i + 1}] {r['title']}\n{r['url']}\n{r['snippet']}" for i, r in enumerate(web_results)
    )
    return _WEB_PROMPT_TEMPLATE.format(
        results=results_text or "(no results found)", question=question, history=_format_history(history)
    )


# ---------- MARX (education mode) ----------
# A distinct persona, not just a different prompt wrapper: a patient tutor
# that teaches FROM the student's own materials, and is explicit about
# citing which source (their PDF, or the web) an answer came from -- a
# tutor mixing in unstated outside knowledge without saying so would be
# actively bad pedagogy (the student can't tell what they're responsible
# for knowing vs. what MARX added). Reuses INSUFFICIENT_CONTEXT_SENTINEL
# from the main document prompt so is_insufficient() works unchanged.
_MARX_DOCUMENT_PROMPT_TEMPLATE = """You are MARX, a patient, encouraging study tutor. A student has given you their course material below -- teach from it directly, the way a good tutor walks through a textbook with a student, not like a generic search result.

Rules:
- Answer using ONLY the material below. If it doesn't cover the question, respond with EXACTLY this and nothing else: """ + INSUFFICIENT_CONTEXT_SENTINEL + """
- Explain clearly, like you're teaching, not just quoting -- define terms the first time you use them, and briefly say *why* something is true when the material supports it, not just *that* it's true.
- Format in Markdown (bold key terms, bullet/numbered steps for processes, tables for comparisons).
""" + _LATEX_INSTRUCTIONS + _MERMAID_INSTRUCTIONS + """
{history}
Student's material:
{context}

Student's question: {question}

MARX:"""

_MARX_WEB_PROMPT_TEMPLATE = """You are MARX, a patient, encouraging study tutor. The student's own course material didn't cover this question, so you're now answering from a web search instead -- make that switch clear to the student rather than blending it in silently.

Rules:
- Start the answer by briefly noting this wasn't in their material and you're answering from the web instead.
- Answer using ONLY the search results below. Cite sources inline using [1], [2], etc. If the results don't actually answer the question either, respond with EXACTLY this and nothing else: """ + INSUFFICIENT_CONTEXT_SENTINEL + """
- Explain clearly, like you're teaching, not just quoting.
- Format in Markdown where it helps readability.
""" + _LATEX_INSTRUCTIONS + """
{history}
Web search results:
{results}

Student's question: {question}

MARX:"""


def build_marx_document_prompt(question: str, context_chunks: list[dict], history: list[dict] | None = None) -> str:
    context = "\n\n".join(
        f"[Source {i + 1}: {chunk['filename']}, chunk {chunk['chunk_index']}]\n{chunk['text']}"
        for i, chunk in enumerate(context_chunks)
    )
    return _MARX_DOCUMENT_PROMPT_TEMPLATE.format(
        context=context or "(no material provided)", question=question, history=_format_history(history)
    )


def build_marx_web_prompt(question: str, web_results: list[dict], history: list[dict] | None = None) -> str:
    results_text = "\n\n".join(
        f"[{i + 1}] {r['title']}\n{r['url']}\n{r['snippet']}" for i, r in enumerate(web_results)
    )
    return _MARX_WEB_PROMPT_TEMPLATE.format(
        results=results_text or "(no results found)", question=question, history=_format_history(history)
    )


def generate(prompt: str) -> str:
    return _generate(prompt)


def is_insufficient(answer: str) -> bool:
    return INSUFFICIENT_CONTEXT_SENTINEL in answer


_SEARCH_QUERY_REWRITE_PROMPT = """Given the question below, output a JSON object with two fields:
- "topic": the single main subject, as a short proper-noun-style topic name the way it would appear as an encyclopedia article title (e.g. "Eiffel Tower", "Photosynthesis", "Redis (software)") -- just the topic itself, no extra descriptive words.
- "query": a short, effective web search query for the full question, the way a person would actually type it into a search engine -- fix obvious typos, drop filler words ("in which year", "can you tell me"), keep only the key facts needed.

Output ONLY the JSON object, nothing else -- no markdown code fences, no explanation.

Question: {question}

JSON:"""


def rewrite_search_query(question: str) -> tuple[str, str]:
    """Returns (topic, query). A raw natural-language question (especially
    a misspelled or verbosely-phrased one) often searches poorly:
    DuckDuckGo's Instant Answer API does a near-exact topic-name lookup
    (found by direct testing: "Eiffel Tower" returns a real abstract,
    "eiffel tower built year" returns nothing at all, even though it's
    the more natural search phrasing) rather than full-text search, while
    the HTML results page wants a fuller descriptive query like a normal
    search engine. One LLM call produces both, since they're needed
    together at every call site anyway. This is standard query-rewriting-
    for-retrieval practice, not an attempt to work around anything -- the
    same thing a person does instinctively when they type a search query
    instead of pasting their whole question. Degrades to the original
    question for both if the model's output doesn't parse as the expected
    JSON shape.
    """
    raw = _generate(_SEARCH_QUERY_REWRITE_PROMPT.format(question=question)).strip()
    text = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    try:
        data = json.loads(text)
        topic = data.get("topic")
        query = data.get("query")
        if isinstance(topic, str) and topic.strip() and isinstance(query, str) and query.strip():
            return topic.strip(), query.strip()
    except json.JSONDecodeError:
        pass
    return question, question


_TOPIC_LABEL_PROMPT = """The user asked: "{question}"

Below are numbered excerpts retrieved from company documents that may be relevant. For EACH excerpt, write a short topic label (3-6 words) describing what that specific excerpt covers, in the context of the question.

Output ONLY a JSON array of strings, one label per excerpt, in the same order as the excerpts. No explanation, no markdown code fences, no extra text.

Excerpts:
{excerpts}

JSON array:"""


def generate_topic_labels(question: str, chunks: list[dict]) -> list[str] | None:
    """One short topic label per chunk, in order. Returns None (caller
    should fall back to a deterministic label) if the model doesn't
    produce a clean same-length JSON array -- LLM JSON output isn't
    reliable enough to trust blindly here.
    """
    excerpts = "\n\n".join(f"{i + 1}. [{c['filename']}] {c['text'][:300]}" for i, c in enumerate(chunks))
    prompt = _TOPIC_LABEL_PROMPT.format(question=question, excerpts=excerpts)
    raw = _generate(prompt)

    text = raw.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)

    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return None

    if isinstance(data, list) and len(data) == len(chunks) and all(isinstance(x, str) for x in data):
        return data
    return None
