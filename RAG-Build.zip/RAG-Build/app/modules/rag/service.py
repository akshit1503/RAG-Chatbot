import re
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.supabase_client import mirror_row
from app.core.web_search import WebSearchError, search_web
from app.modules.file_access.models import FileRecord, User
from app.modules.rag import vectorstore
from app.modules.rag.chunking import RecursiveCharacterTextSplitter
from app.modules.rag.embeddings import embed_query, embed_texts
from app.modules.rag.hybrid_search import hybrid_rank
from app.modules.rag.reranking import mmr_rerank
from app.modules.rag.generation import (
    build_fallback_prompt,
    build_marx_document_prompt,
    build_marx_web_prompt,
    build_prompt,
    build_web_prompt,
    generate,
    generate_topic_labels,
    is_insufficient,
    rewrite_search_query,
)
from app.modules.rag.loaders import extract_text
from app.modules.rag.models import AnswerFeedback, DocumentIndex, FeedbackRating

settings = get_settings()


def get_index_status(db: Session, file_id: int) -> DocumentIndex | None:
    return db.scalar(select(DocumentIndex).where(DocumentIndex.file_id == file_id))


def index_document(db: Session, file: FileRecord) -> DocumentIndex:
    path = Path(settings.upload_dir) / file.stored_filename
    text = extract_text(path, path.suffix)
    if not text.strip():
        raise ValueError(f"No extractable text found in '{file.original_filename}'")

    splitter = RecursiveCharacterTextSplitter(chunk_size=settings.chunk_size, chunk_overlap=settings.chunk_overlap)
    chunks = splitter.split_text(text)
    if not chunks:
        raise ValueError(f"Document '{file.original_filename}' produced no chunks")

    embeddings = embed_texts(chunks)

    # Re-indexing an already-indexed file: drop its prior vectors first.
    vectorstore.delete_document(file.id)
    vectorstore.add_chunks(
        file_id=file.id,
        chunks=chunks,
        embeddings=embeddings,
        owner_id=file.owner_id,
        scope=file.scope,
        department=file.department,
        filename=file.original_filename,
    )

    record = get_index_status(db, file.id)
    if record is None:
        record = DocumentIndex(file_id=file.id, chunk_count=len(chunks))
        db.add(record)
    else:
        record.chunk_count = len(chunks)
        record.indexed_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(record)
    return record


def deindex_file(db: Session, file_id: int) -> None:
    vectorstore.delete_document(file_id)
    record = get_index_status(db, file_id)
    if record is not None:
        db.delete(record)
        db.commit()


# How much wider a net the vector search casts than what's actually
# returned, so hybrid_rank() has a meaningful pool of candidates to
# re-rank by keyword overlap rather than just the final top_k already
# pruned to pure vector order. Capped at 40 so a very large top_k request
# doesn't balloon the BM25 pass or the RBAC-filtered Chroma query.
_HYBRID_CANDIDATE_MULTIPLIER = 4
_HYBRID_CANDIDATE_CAP = 40


def _search(user: User, question: str, top_k: int, use_mmr: bool = False) -> list[dict]:
    """Retrieves and ranks the top_k most relevant chunks.

    `use_mmr` controls whether the final trim to top_k also applies MMR
    diversity reranking (see reranking.py) on top of the hybrid-fused
    order, or just takes the hybrid order's top_k directly. This is NOT a
    quality toggle -- it's a correctness one. `ask()`'s single-dominant-
    source detection (_CONFIDENCE_WINDOW below) needs the *pure* hybrid
    relevance order for its top-N window: MMR can deliberately promote a
    lower-relevance, different-document chunk purely for diversity, which
    would corrupt that window into looking like a multi-source match and
    wrongly send an otherwise-unambiguous question to the topic picker.
    So `ask()` always searches with use_mmr=False, and only
    `answer_query()` (the direct single-turn endpoint, with no
    picker/dominance decision downstream) opts into MMR.
    """
    candidate_k = min(top_k * _HYBRID_CANDIDATE_MULTIPLIER, _HYBRID_CANDIDATE_CAP)
    query_embedding = embed_query(question)
    results = vectorstore.query_chunks(query_embedding=query_embedding, top_k=candidate_k, user=user)

    documents = results.get("documents") or [[]]
    metadatas = results.get("metadatas") or [[]]
    distances = results.get("distances") or [[]]
    ids = results.get("ids") or [[]]
    embeddings = results.get("embeddings")
    embeddings = embeddings[0] if embeddings is not None and len(embeddings) else [None] * len(ids[0] if ids else [])

    candidates = [
        {
            "topic_id": cid,
            "file_id": meta["file_id"],
            "filename": meta["filename"],
            "chunk_index": meta["chunk_index"],
            "text": doc,
            "distance": dist,
            "embedding": emb,
        }
        for cid, doc, meta, dist, emb in zip(ids[0], documents[0], metadatas[0], distances[0], embeddings)
    ]
    # Hybrid search: fuse this vector-similarity ranking with a BM25
    # keyword ranking over the same candidates (Reciprocal Rank Fusion).
    # Surfaces exact keyword/name/code matches (e.g. "RBAC", a function
    # name, a port number) that a purely semantic vector search can
    # under-rank relative to paraphrased text.
    if not use_mmr:
        final = hybrid_rank(question, candidates, top_k)
        for chunk in final:
            chunk.pop("embedding", None)
        return final

    # Reranking (MMR): shortlist wider than top_k so there's genuine room
    # to trade a little top-ranked relevance for diversity, instead of
    # reranking a set that's already been pruned to exactly top_k (where
    # there'd be nothing left to swap in).
    shortlist_k = min(top_k * 2, len(candidates)) or top_k
    shortlisted = hybrid_rank(question, candidates, shortlist_k)
    final = mmr_rerank(shortlisted, top_k)
    for chunk in final:
        chunk.pop("embedding", None)
    return final


def _answer_from_web(question: str, history: list[dict] | None, allow_web_search: bool = True) -> dict | None:
    """Try a web-search-grounded answer. Returns None (caller should fall
    further back) if web search is disabled (globally, or for this request
    via the caller's privacy setting), unavailable, returns nothing useful,
    or the model decides the results still don't answer the question --
    never raises, since web search is inherently a best-effort step in the
    fallback chain, not a hard requirement.
    """
    if not settings.enable_web_search or not allow_web_search:
        return None
    try:
        topic, search_query = rewrite_search_query(question)
        web_results = search_web(search_query, topic=topic)
    except WebSearchError:
        return None
    if not web_results:
        return None

    answer = generate(build_web_prompt(question, web_results, history))
    if is_insufficient(answer):
        return None
    return {"answer": answer, "sources": [], "web_sources": web_results, "source": "web"}


def _web_or_general_fallback(question: str, history: list[dict] | None, allow_web_search: bool = True) -> dict:
    """The tail of the fallback chain: try a web-search-grounded answer,
    and only fall back to the model's raw parametric knowledge if web
    search is disabled, unavailable, or also insufficient.
    """
    web_result = _answer_from_web(question, history, allow_web_search)
    if web_result is not None:
        return web_result
    answer = generate(build_fallback_prompt(question, history))
    return {"answer": answer, "sources": [], "web_sources": [], "source": "general_knowledge"}


def web_or_general_answer(question: str, history: list[dict] | None = None, allow_web_search: bool = True) -> dict:
    """Public entry point for a web-search/general-knowledge-only answer,
    with no document retrieval step -- used by the agent module (see
    app/modules/agent/) for a "web" plan step, so it reuses this exact,
    already-tested fallback chain instead of re-implementing web search +
    general-knowledge fallback a second time.
    """
    return _web_or_general_fallback(question, history, allow_web_search)


def _answer_or_fallback(
    question: str,
    context_chunks: list[dict],
    history: list[dict] | None = None,
    allow_web_search: bool = True,
) -> dict:
    """Answer strictly from document context first; if that's insufficient,
    fall through to _web_or_general_fallback. The result's `source` field
    tells the caller (and ultimately the UI) exactly which tier produced
    the answer -- document-grounded results must never be presented the
    same way as a web or general-knowledge one.
    """
    prompt = build_prompt(question, context_chunks, history)
    answer = generate(prompt)
    if not is_insufficient(answer):
        return {"answer": answer, "sources": context_chunks, "web_sources": [], "source": "documents"}
    return _web_or_general_fallback(question, history, allow_web_search)


def answer_query(
    user: User, question: str, top_k: int, history: list[dict] | None = None, allow_web_search: bool = True
) -> dict:
    # use_mmr=True is safe here: this endpoint has no topic-picker/dominance
    # decision downstream that MMR's diversity reordering could disturb.
    context_chunks = _search(user, question, top_k, use_mmr=True)
    return _answer_or_fallback(question, context_chunks, history, allow_web_search)


# ---------- MARX (education mode) ----------
# A distinct answer path, not a flag on the existing one: MARX's whole
# point is that it NEVER answers from raw parametric knowledge the way the
# main chat's _web_or_general_fallback does as its last resort -- only the
# student's own documents, or a web search that's clearly labeled as such.
# Sharing _answer_or_fallback's tail would silently reintroduce the exact
# behavior MARX exists to avoid, so this has its own small fallback chain
# instead, built from the same primitives (_search, _answer_from_web).


def _marx_web_or_insufficient(question: str, history: list[dict] | None, allow_web_search: bool = True) -> dict:
    """MARX's tail of the fallback chain. Tries a web-search-grounded
    answer using the MARX tutor persona (which explicitly tells the
    student the switch happened, rather than blending web content in
    silently); if that's also unavailable or insufficient, returns a
    plain "insufficient" result instead of falling through to ungrounded
    general knowledge -- the one behavior that actually distinguishes
    MARX from the main chat flow.
    """
    if allow_web_search and settings.enable_web_search:
        try:
            topic, search_query = rewrite_search_query(question)
            web_results = search_web(search_query, topic=topic)
        except WebSearchError:
            web_results = []
        if web_results:
            answer = generate(build_marx_web_prompt(question, web_results, history))
            if not is_insufficient(answer):
                return {"answer": answer, "sources": [], "web_sources": web_results, "source": "web"}

    return {
        "answer": (
            "I couldn't find this in your course material"
            + (" or the web" if allow_web_search and settings.enable_web_search else "")
            + ". Try rephrasing the question, double-check the relevant document has been uploaded and indexed, "
            "or ask your instructor."
        ),
        "sources": [],
        "web_sources": [],
        "source": "insufficient",
    }


def answer_marx_query(
    user: User, question: str, top_k: int, history: list[dict] | None = None, allow_web_search: bool = True
) -> dict:
    context_chunks = _search(user, question, top_k, use_mmr=True)
    prompt = build_marx_document_prompt(question, context_chunks, history)
    answer = generate(prompt)
    if not is_insufficient(answer):
        return {"answer": answer, "sources": context_chunks, "web_sources": [], "source": "documents"}
    return _marx_web_or_insufficient(question, history, allow_web_search)


def _label_topics(question: str, chunks: list[dict]) -> list[dict]:
    labels = generate_topic_labels(question, chunks)
    if labels is None:
        labels = [f"{c['filename']} (chunk {c['chunk_index']})" for c in chunks]

    return [
        {
            "topic_id": chunk["topic_id"],
            "label": label,
            "file_id": chunk["file_id"],
            "filename": chunk["filename"],
            "chunk_index": chunk["chunk_index"],
            "preview": chunk["text"][:200],
        }
        for chunk, label in zip(chunks, labels)
    ]


def discover_topics(user: User, question: str, top_k: int) -> list[dict]:
    chunks = _search(user, question, top_k)
    if not chunks:
        return []
    return _label_topics(question, chunks)


# How many of the closest-matching chunks are checked for single-source
# dominance. Small enough that a couple of stray cross-document matches
# further down the ranked list don't block a direct answer, large enough
# that genuinely mixed-topic results still get disambiguated.
_CONFIDENCE_WINDOW = 4

# A real bug found by live testing: a plain greeting ("hi", "hello") has no
# content to disambiguate, but ask() was still running it through document
# search -- a couple of chunks always come back (there's no similarity
# threshold), often spanning multiple documents purely by coincidence, which
# incorrectly triggered the topic picker for a message that isn't a content
# question at all. Matched against the WHOLE (stripped) message, not a
# substring, so "hi, what's the AWS lab about?" -- a real question that
# happens to start with a greeting -- is correctly left alone.
_SALUTATION_PATTERN = re.compile(
    r"^(hi+|hello+|hey+|hiya|yo+|howdy|greetings?|good\s*(morning|afternoon|evening|day)|what'?s\s*up|sup)[\s!.,?]*$",
    re.IGNORECASE,
)

# Same idea for the opposite case: a meta-question about what's available
# to ask ("what topics do you have?") isn't a content question either, and
# a similarity search against it would rank essentially at random. Detected
# by a small set of common phrasings rather than an LLM call -- cheap, and
# a false negative here just falls through to the normal search path
# instead of breaking anything.
_TOPIC_LIST_PATTERN = re.compile(
    r"\b(what|which)\s+(topics?|documents?|files?|subjects?|things?)\b.*\b(have|available|know about|"
    r"can i ask|can you (help|answer))\b"
    r"|\b(list|show)\s+(me\s+)?(the\s+)?(topics?|documents?|files?)\b"
    r"|\bwhat\s+(can|could)\s+i\s+ask\b",
    re.IGNORECASE,
)


def _list_document_topics(user: User) -> list[dict]:
    """One topic entry per distinct document the user can see, for the
    "what topics/documents do you have" meta-question. Deliberately skips
    both the similarity search and the LLM topic-labeling call used
    elsewhere (_label_topics) -- there's no real question to rank chunks
    against or to label a chunk's relevance to, so the filename itself is
    the honest label; the whole point is to show what's actually indexed.
    """
    collection = vectorstore.get_collection()
    raw = collection.get(where=vectorstore.build_access_filter(user), include=["documents", "metadatas"])
    ids = raw.get("ids") or []
    documents = raw.get("documents") or []
    metadatas = raw.get("metadatas") or []

    seen_files: set[int] = set()
    topics = []
    for cid, doc, meta in zip(ids, documents, metadatas):
        file_id = meta["file_id"]
        if file_id in seen_files:
            continue
        seen_files.add(file_id)
        topics.append(
            {
                "topic_id": cid,
                "label": meta["filename"],
                "file_id": file_id,
                "filename": meta["filename"],
                "chunk_index": meta["chunk_index"],
                "preview": doc[:200],
            }
        )
    return topics


def ask(
    user: User, question: str, top_k: int, history: list[dict] | None = None, allow_web_search: bool = True
) -> dict:
    """Skip the topic picker when the question isn't actually ambiguous.

    If the closest-matching chunks all come from the same source document,
    there's nothing to disambiguate -- answer directly via the fallback
    chain (documents -> web -> general knowledge), with the result's
    `source` field always telling the caller which tier actually answered.
    Otherwise, the top matches span multiple distinct documents and
    genuinely need the user to pick which one they mean, so topics are
    returned instead.
    """
    stripped = question.strip()

    if _SALUTATION_PATTERN.match(stripped):
        result = _web_or_general_fallback(question, history, allow_web_search)
        return {"topics": [], **result}

    if _TOPIC_LIST_PATTERN.search(stripped):
        return {"topics": _list_document_topics(user), "answer": None, "is_document_list": True}

    chunks = _search(user, question, top_k)
    if not chunks:
        # Nothing indexed is even a candidate match -- skip straight to the
        # web-search/general-knowledge fallback chain rather than a bare
        # "no relevant documents" dead end.
        result = _web_or_general_fallback(question, history, allow_web_search)
        return {"topics": [], **result}

    dominant_file_ids = {c["file_id"] for c in chunks[:_CONFIDENCE_WINDOW]}
    if len(dominant_file_ids) == 1:
        context_chunks = [c for c in chunks if c["file_id"] in dominant_file_ids]
        result = _answer_or_fallback(question, context_chunks, history, allow_web_search)
        return {"topics": [], **result}

    return {"topics": _label_topics(question, chunks), "answer": None}


def answer_from_topics(
    user: User,
    question: str,
    topic_ids: list[str],
    history: list[dict] | None = None,
    allow_web_search: bool = True,
) -> dict:
    raw = vectorstore.get_chunks_by_ids(topic_ids)
    ids = raw.get("ids") or []
    documents = raw.get("documents") or []
    metadatas = raw.get("metadatas") or []

    context_chunks = [
        {
            "file_id": meta["file_id"],
            "filename": meta["filename"],
            "chunk_index": meta["chunk_index"],
            "text": doc,
            "distance": None,
        }
        for cid, doc, meta in zip(ids, documents, metadatas)
        if vectorstore.metadata_allows(user, meta)  # defense in depth: re-check RBAC on direct ID fetch
    ]

    return _answer_or_fallback(question, context_chunks, history, allow_web_search)


def record_feedback(
    db: Session,
    user: User,
    question: str,
    answer: str,
    source: str,
    rating: str,
    comment: str | None,
) -> AnswerFeedback:
    entry = AnswerFeedback(
        user_id=user.id,
        question=question,
        answer=answer,
        source=source,
        rating=FeedbackRating(rating),
        comment=comment,
    )
    db.add(entry)
    db.commit()
    db.refresh(entry)
    mirror_row(
        "answer_feedback",
        {
            "source_id": entry.id,
            "user_id": entry.user_id,
            "question": entry.question,
            "answer": entry.answer,
            "source": entry.source,
            "rating": entry.rating.value,
            "comment": entry.comment,
            "created_at": entry.created_at.isoformat(),
        },
    )
    return entry


def list_feedback(db: Session, limit: int = 200) -> list[AnswerFeedback]:
    return list(
        db.scalars(select(AnswerFeedback).order_by(AnswerFeedback.created_at.desc()).limit(limit))
    )
