from pydantic import BaseModel

from app.modules.rag.schemas import ChatTurn, SourceChunk, WebSource


class AgentQueryRequest(BaseModel):
    query: str
    history: list[ChatTurn] = []
    allow_web_search: bool = True


class AgentStep(BaseModel):
    tool: str  # "rag" | "sql" | "web"
    file_id: int | None
    question: str
    summary: str


class AgentQueryResponse(BaseModel):
    query: str
    answer: str
    steps: list[AgentStep]
    sources: list[SourceChunk] = []
    web_sources: list[WebSource] = []
