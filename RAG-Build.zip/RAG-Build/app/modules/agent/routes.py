from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.audit import log_event
from app.core.rate_limit import check_rate_limit
from app.modules.agent import schemas, service
from app.modules.file_access.database import get_db
from app.modules.file_access.deps import get_current_user
from app.modules.file_access.models import User

router = APIRouter(prefix="/agent", tags=["agent"])


@router.post("/query", response_model=schemas.AgentQueryResponse)
def agent_query(
    request: schemas.AgentQueryRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Its own rate-limit bucket, not shared with rag_query/sql_query -- an
    # agent call can itself trigger up to MAX_STEPS RAG/SQL/web calls, so
    # it deserves a tighter budget rather than quietly eating into the
    # quota of the plain single-tool endpoints.
    check_rate_limit(current_user.id, "agent_query", limit=10)

    history = [turn.model_dump() for turn in request.history[-10:]]
    result = service.run_agent_query(db, current_user, request.query, history, request.allow_web_search)

    log_event(
        db, user_id=current_user.id, username=current_user.username,
        action="agent_query", resource_type="steps", resource_id=len(result["steps"]), detail=request.query,
    )
    return schemas.AgentQueryResponse(query=request.query, **result)
