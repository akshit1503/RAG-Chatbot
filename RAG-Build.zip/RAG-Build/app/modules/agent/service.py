import logging

from sqlalchemy.orm import Session

from app.modules.agent.planning import (
    build_plan_prompt,
    build_synthesis_prompt,
    generate_plan_raw,
    parse_plan,
    synthesize,
)
from app.modules.file_access import crud, rbac
from app.modules.file_access.models import User
from app.modules.rag import service as rag_service
from app.modules.text_to_sql import service as sql_service
from app.modules.text_to_sql.query_executor import UnsafeQueryError

logger = logging.getLogger(__name__)

# Fixed retrieval width for each RAG sub-step. Not user-configurable here --
# an agent step asks a narrow, planner-written sub-question, so it doesn't
# need the wider top_k a direct user question might.
_STEP_TOP_K = 4
_SUMMARY_CHARS = 200


def _visible_manifest(db: Session, user: User) -> tuple[list[str], list[dict]]:
    """Everything this user is allowed to see, split into what's usable by
    each tool: indexed documents for "rag" steps, ingested datasets (with
    schema) for "sql" steps. This is the ONLY thing the planner LLM is
    told exists -- it never sees a file the user can't view, so it can
    never plan a step that would leak one, before RBAC is even re-checked
    a second time at execution.
    """
    files = [f for f in crud.list_files(db) if rbac.can_view_file(user, f)]
    documents: list[str] = []
    datasets: list[dict] = []
    for f in files:
        if rag_service.get_index_status(db, f.id) is not None:
            documents.append(f.original_filename)
        dataset = sql_service.get_dataset(db, f.id)
        if dataset is not None:
            datasets.append({"file_id": f.id, "filename": f.original_filename, "columns": dataset.columns.split(",")})
    return documents, datasets


def _fallback_to_plain_rag(user: User, question: str, history: list[dict] | None, allow_web_search: bool) -> dict:
    """Used whenever planning produces nothing usable (empty/malformed
    plan, or every planned step failed RBAC/execution) -- an agent that
    can't plan still shouldn't leave the user without an answer, so it
    degrades to the same single-tool RAG flow (documents -> web -> general
    knowledge) used everywhere else in the app.
    """
    result = rag_service.answer_query(user, question, _STEP_TOP_K, history, allow_web_search)
    return {
        "answer": result["answer"],
        "steps": [],
        "sources": result["sources"],
        "web_sources": result["web_sources"],
    }


def run_agent_query(
    db: Session,
    user: User,
    question: str,
    history: list[dict] | None = None,
    allow_web_search: bool = True,
) -> dict:
    documents, datasets = _visible_manifest(db, user)
    valid_file_ids = {d["file_id"] for d in datasets}

    raw_plan = generate_plan_raw(build_plan_prompt(question, documents, datasets))
    steps = parse_plan(raw_plan, valid_file_ids)
    if not steps:
        return _fallback_to_plain_rag(user, question, history, allow_web_search)

    executed_steps = []  # returned to the caller, for transparency (truncated summaries)
    synthesis_inputs = []  # full-length answers, fed to the synthesis prompt
    sources: list[dict] = []
    web_sources: list[dict] = []

    for step in steps:
        answer = None
        if step["tool"] == "rag":
            result = rag_service.answer_query(user, step["question"], _STEP_TOP_K, history, allow_web_search)
            sources.extend(result["sources"])
            web_sources.extend(result["web_sources"])
            answer = result["answer"]

        elif step["tool"] == "sql":
            # Defense in depth: re-verify RBAC on this exact file_id even
            # though the planner was only ever shown visible datasets --
            # never trust the model's own output as the security boundary.
            file = crud.get_file_by_id(db, step["file_id"])
            if file is None or not rbac.can_view_file(user, file):
                logger.warning("Agent plan referenced file_id %s not visible to user %s -- skipped", step["file_id"], user.id)
                continue
            dataset = sql_service.get_dataset(db, step["file_id"])
            if dataset is None:
                continue
            try:
                sql_answer, _sql, _cols, _rows, _truncated = sql_service.answer_query(dataset, step["question"])
                answer = sql_answer
            except UnsafeQueryError as exc:
                logger.warning("Agent SQL step rejected by authorizer sandbox: %s", exc)
                continue

        else:  # "web"
            result = rag_service.web_or_general_answer(step["question"], history, allow_web_search)
            web_sources.extend(result["web_sources"])
            answer = result["answer"]

        if answer is None:
            continue
        executed_steps.append(
            {"tool": step["tool"], "file_id": step["file_id"], "question": step["question"], "summary": answer[:_SUMMARY_CHARS]}
        )
        synthesis_inputs.append({"tool": step["tool"], "question": step["question"], "answer": answer})

    if not executed_steps:
        return _fallback_to_plain_rag(user, question, history, allow_web_search)

    final_answer = synthesize(build_synthesis_prompt(question, synthesis_inputs))

    return {"answer": final_answer, "steps": executed_steps, "sources": sources, "web_sources": web_sources}
