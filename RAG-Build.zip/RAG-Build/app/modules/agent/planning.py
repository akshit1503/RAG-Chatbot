import json
import re

from app.core.ollama_client import generate as _generate

# Hard cap on how many tool calls a single question can trigger -- bounds
# both latency (each step is a real LLM/tool call) and cost, and rules out
# a pathological plan the model might otherwise generate.
MAX_STEPS = 3

_PLAN_PROMPT = """You are the planner for a multi-tool question-answering agent. Given the user's question and the resources listed below, decide which tool call(s) are needed to answer it, in order.

Available tools:
- "rag": search the user's indexed documents. Use for questions about document content.
- "sql": run a question against ONE specific ingested dataset (must give its file_id from the list below). Use for questions about structured/tabular data -- counts, sums, averages, filters, comparisons.
- "web": search the public web. Use only for current events, real-time facts, or anything clearly outside both the documents and datasets below.

Available indexed documents: {documents}
Available datasets: {datasets}

Output ONLY a JSON object of the form {{"steps": [{{"tool": "rag", "question": "..."}}]}} (a "sql" step also needs "file_id": <int>). Use at most {max_steps} steps -- most questions need only one. If the question is simple, output just one step. If nothing above looks relevant to the question, output {{"steps": []}}. No explanation, no markdown code fences, no extra keys.

User's question: {question}

JSON:"""


def build_plan_prompt(question: str, documents: list[str], datasets: list[dict]) -> str:
    documents_text = ", ".join(documents) if documents else "(none indexed)"
    datasets_text = (
        "; ".join(f"file_id={d['file_id']} ({d['filename']}: columns {', '.join(d['columns'])})" for d in datasets)
        if datasets
        else "(none ingested)"
    )
    return _PLAN_PROMPT.format(documents=documents_text, datasets=datasets_text, question=question, max_steps=MAX_STEPS)


def generate_plan_raw(prompt: str) -> str:
    return _generate(prompt)


def parse_plan(raw: str, valid_file_ids: set[int]) -> list[dict]:
    """Parses and validates the planner's JSON output. Never trusts it
    blindly:
    - a step naming a tool other than rag/sql/web is dropped
    - a "sql" step naming a file_id not in valid_file_ids is dropped --
      defense in depth: the caller only ever put RBAC-visible datasets in
      the prompt, but nothing stops a model from hallucinating an id that
      wasn't offered
    - malformed JSON, or a non-list "steps", degrades to an empty plan

    An empty return is not an error -- the caller (agent/service.py)
    treats it as "fall back to the standard single-tool RAG flow", so
    planner failure never leaves the user without an answer.
    """
    text = raw.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)

    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return []

    if not isinstance(data, dict) or not isinstance(data.get("steps"), list):
        return []

    steps = []
    for raw_step in data["steps"][:MAX_STEPS]:
        if not isinstance(raw_step, dict):
            continue
        tool = raw_step.get("tool")
        step_question = raw_step.get("question")
        if tool not in ("rag", "sql", "web") or not isinstance(step_question, str) or not step_question.strip():
            continue

        if tool == "sql":
            file_id = raw_step.get("file_id")
            if not isinstance(file_id, int) or file_id not in valid_file_ids:
                continue
            steps.append({"tool": "sql", "file_id": file_id, "question": step_question})
        else:
            steps.append({"tool": tool, "file_id": None, "question": step_question})
    return steps


_SYNTHESIS_PROMPT = """You are answering a user's question using results already gathered from one or more tools (document search, a specific dataset, and/or a web search). Combine them into one clear, well-formatted final answer to the original question. If a tool's result doesn't actually help answer the question, ignore it rather than forcing it in. Do not invent information that isn't present in the tool results below. Format the answer in Markdown where it helps readability.

Original question: {question}

Tool results:
{results}

Final answer:"""


def build_synthesis_prompt(question: str, results: list[dict]) -> str:
    blocks = [f"[{r['tool']}] Sub-question: {r['question']}\nResult: {r['answer']}" for r in results]
    return _SYNTHESIS_PROMPT.format(question=question, results="\n\n".join(blocks) if blocks else "(no tool results)")


def synthesize(prompt: str) -> str:
    return _generate(prompt).strip()
