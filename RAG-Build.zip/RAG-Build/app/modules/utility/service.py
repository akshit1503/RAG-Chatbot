from pathlib import Path

import pandas as pd

from app.core.config import get_settings
from app.modules.file_access.models import FileRecord
from app.modules.rag.loaders import UnsupportedDocumentType, extract_text
from app.modules.text_to_sql.ingest import UnsupportedDatasetType, load_dataframe
from app.modules.utility.extraction import extract_fields
from app.modules.utility.summarization import summarize_profile, summarize_text

settings = get_settings()

_DOCUMENT_SUFFIXES = {".pdf", ".docx", ".txt", ".md"}
_TABULAR_SUFFIXES = {".csv", ".xlsx", ".xls"}


def _profile_dataframe(df: pd.DataFrame) -> str:
    lines = [
        f"Rows: {len(df)}",
        f"Columns ({len(df.columns)}): {', '.join(str(c) for c in df.columns)}",
        "",
        "Column statistics:",
        df.describe(include="all").fillna("").to_string(),
        "",
        "Sample rows:",
        df.head(5).to_string(index=False),
    ]
    return "\n".join(lines)


def summarize_file(file: FileRecord) -> str:
    path = Path(settings.upload_dir) / file.stored_filename
    suffix = path.suffix.lower()

    if suffix in _DOCUMENT_SUFFIXES:
        try:
            text = extract_text(path, suffix)
        except UnsupportedDocumentType as exc:
            raise ValueError(str(exc)) from exc
        if not text.strip():
            raise ValueError(f"No extractable text found in '{file.original_filename}'")
        return summarize_text(text)

    if suffix in _TABULAR_SUFFIXES:
        try:
            df = load_dataframe(path, suffix)
        except UnsupportedDatasetType as exc:
            raise ValueError(str(exc)) from exc
        return summarize_profile(_profile_dataframe(df))

    raise ValueError(f"Summarization is not supported for '{suffix}' files")


def extract_from_file(file: FileRecord, field_names: list[str], descriptions: dict[str, str]) -> dict:
    """Structured field extraction. Documents only (RAG-loader text) --
    tabular files already have a real schema (see /sql/datasets/{id}/schema);
    asking an LLM to "extract fields" from a CSV would just be a worse way
    to read a column that's already directly queryable.
    """
    path = Path(settings.upload_dir) / file.stored_filename
    suffix = path.suffix.lower()

    if suffix not in _DOCUMENT_SUFFIXES:
        raise ValueError(
            f"Structured extraction is not supported for '{suffix}' files -- "
            "tabular files already have a queryable schema, see /sql/datasets/{file_id}/schema"
        )

    try:
        text = extract_text(path, suffix)
    except UnsupportedDocumentType as exc:
        raise ValueError(str(exc)) from exc
    if not text.strip():
        raise ValueError(f"No extractable text found in '{file.original_filename}'")

    return extract_fields(text, field_names, descriptions)
