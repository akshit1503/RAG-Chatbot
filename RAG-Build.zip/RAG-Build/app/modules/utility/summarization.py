from app.core.ollama_client import generate as _generate
from app.modules.rag.chunking import RecursiveCharacterTextSplitter

# Rough char budget for a single LLM call before we fall back to map-reduce.
_SINGLE_PASS_CHAR_LIMIT = 12000

_SUMMARIZE_PROMPT = """Summarize the following text concisely, in 3-6 sentences. Capture the key facts, figures, and conclusions. Do not add information that isn't in the text.

Text:
{text}

Summary:"""

_COMBINE_PROMPT = """The following are summaries of consecutive sections of a single document. Combine them into one concise, coherent overall summary of 4-8 sentences, removing redundancy.

Section summaries:
{summaries}

Overall summary:"""

_PROFILE_PROMPT = """The following is a statistical profile of a tabular dataset (row/column counts, per-column statistics, and sample rows). Write a short natural-language summary (3-5 sentences) describing what the dataset contains and any notable patterns. Only describe what's in the profile -- do not invent figures.

Profile:
{profile}

Summary:"""


def _call_llm(prompt: str) -> str:
    return _generate(prompt).strip()


def summarize_text(text: str) -> str:
    """Summarize arbitrary document text, falling back to map-reduce
    (chunk -> summarize each -> combine) for text too long for one call.
    """
    text = text.strip()
    if not text:
        raise ValueError("No text to summarize")

    if len(text) <= _SINGLE_PASS_CHAR_LIMIT:
        return _call_llm(_SUMMARIZE_PROMPT.format(text=text))

    splitter = RecursiveCharacterTextSplitter(chunk_size=_SINGLE_PASS_CHAR_LIMIT, chunk_overlap=200)
    chunk_summaries = [_call_llm(_SUMMARIZE_PROMPT.format(text=chunk)) for chunk in splitter.split_text(text)]

    combined = "\n\n".join(chunk_summaries)
    if len(combined) <= _SINGLE_PASS_CHAR_LIMIT:
        return _call_llm(_COMBINE_PROMPT.format(summaries=combined))

    # Combined summaries still too large (very long source doc) -- reduce again.
    return summarize_text(combined)


def summarize_profile(profile: str) -> str:
    """Summarize a deterministically-computed tabular data profile.

    Kept separate from summarize_text: the profile is always small
    regardless of dataset size (it's stats + a few sample rows, not raw
    data), so it never needs map-reduce, and it uses a prompt tailored to
    describing statistics rather than prose.
    """
    profile = profile.strip()
    if not profile:
        raise ValueError("No data to summarize")
    return _call_llm(_PROFILE_PROMPT.format(profile=profile))
