import json
import re

from app.core.ollama_client import generate as _generate
from app.modules.rag.chunking import RecursiveCharacterTextSplitter

# Same single-pass budget as summarization.py -- long documents fall back to
# per-chunk extraction + merge instead of one call that would truncate or
# blow the model's context.
_SINGLE_PASS_CHAR_LIMIT = 12000

_EXTRACT_PROMPT = """Extract the following fields from the text below. Output ONLY a single JSON object with exactly these keys: {field_list}. If a field's value isn't present in the text, use null for that key -- never guess or invent a value. Do not add extra keys, explanation, or markdown code fences.

Fields to extract:
{field_descriptions}

Text:
{text}

JSON:"""


def _format_fields(fields: list[str]) -> str:
    return ", ".join(f'"{f}"' for f in fields)


def _format_field_descriptions(fields: list[str], descriptions: dict[str, str]) -> str:
    lines = []
    for f in fields:
        desc = descriptions.get(f)
        lines.append(f"- {f}: {desc}" if desc else f"- {f}")
    return "\n".join(lines)


def _parse_json_object(raw: str, fields: list[str]) -> dict:
    """Parses the model's JSON response, robust to the same failure modes
    as generate_topic_labels() in rag/generation.py (code-fenced output,
    extra prose) -- LLM JSON output isn't reliable enough to trust blindly.
    Reconciles the result against the requested field list regardless of
    what came back: missing keys become None, extra keys are dropped, so
    callers always get a dict with exactly the requested shape.
    """
    text = raw.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)

    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        data = {}

    if not isinstance(data, dict):
        data = {}

    return {f: data.get(f) for f in fields}


def _merge_chunk_results(chunk_results: list[dict], fields: list[str]) -> dict:
    """Merges per-chunk extractions for a long document: for each field,
    take the first non-null, non-empty value found across chunks in
    document order. A field genuinely absent everywhere stays None.
    """
    merged: dict = {f: None for f in fields}
    for result in chunk_results:
        for f in fields:
            if merged[f] in (None, "") and result.get(f) not in (None, ""):
                merged[f] = result[f]
    return merged


def extract_fields(text: str, fields: list[str], descriptions: dict[str, str] | None = None) -> dict:
    """Extracts the requested fields from document text as a dict. Always
    returns exactly `fields` as keys (missing/unparseable -> None), so
    callers never need to defensively check for a key's presence.
    """
    text = text.strip()
    if not text:
        raise ValueError("No text to extract from")
    if not fields:
        raise ValueError("At least one field must be requested")

    descriptions = descriptions or {}
    field_list = _format_fields(fields)
    field_descriptions = _format_field_descriptions(fields, descriptions)

    if len(text) <= _SINGLE_PASS_CHAR_LIMIT:
        raw = _generate(_EXTRACT_PROMPT.format(field_list=field_list, field_descriptions=field_descriptions, text=text))
        return _parse_json_object(raw, fields)

    splitter = RecursiveCharacterTextSplitter(chunk_size=_SINGLE_PASS_CHAR_LIMIT, chunk_overlap=200)
    chunk_results = []
    for chunk in splitter.split_text(text):
        raw = _generate(_EXTRACT_PROMPT.format(field_list=field_list, field_descriptions=field_descriptions, text=chunk))
        chunk_results.append(_parse_json_object(raw, fields))
    return _merge_chunk_results(chunk_results, fields)
