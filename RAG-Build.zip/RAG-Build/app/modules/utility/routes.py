from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.rate_limit import check_rate_limit
from app.modules.file_access import crud, rbac
from app.modules.file_access.database import get_db
from app.modules.file_access.deps import get_current_user
from app.modules.file_access.models import User
from app.modules.utility import schemas, service

router = APIRouter(prefix="/utility", tags=["utility"])


@router.post("/documents/{file_id}/summarize", response_model=schemas.SummaryResponse)
def summarize_document(file_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    file = crud.get_file_by_id(db, file_id)
    if file is None or not rbac.can_view_file(current_user, file):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found")

    try:
        summary = service.summarize_file(file)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)) from exc

    return schemas.SummaryResponse(file_id=file.id, filename=file.original_filename, summary=summary)


@router.post("/documents/{file_id}/extract", response_model=schemas.ExtractResponse)
def extract_document_fields(
    file_id: int,
    request: schemas.ExtractRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    check_rate_limit(current_user.id, "extract")
    file = crud.get_file_by_id(db, file_id)
    if file is None or not rbac.can_view_file(current_user, file):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found")
    if not request.fields:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="At least one field must be requested")

    field_names = [f.name for f in request.fields]
    descriptions = {f.name: f.description for f in request.fields if f.description}

    try:
        data = service.extract_from_file(file, field_names, descriptions)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)) from exc

    return schemas.ExtractResponse(file_id=file.id, filename=file.original_filename, data=data)
