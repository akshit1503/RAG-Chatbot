from typing import Any

from pydantic import BaseModel


class SummaryResponse(BaseModel):
    file_id: int
    filename: str
    summary: str


class ExtractField(BaseModel):
    name: str
    # Optional hint to the model about what this field means, e.g.
    # "invoice total, including currency symbol" -- helps disambiguate a
    # generic field name like "total" or "date" against the document.
    description: str | None = None


class ExtractRequest(BaseModel):
    fields: list[ExtractField]


class ExtractResponse(BaseModel):
    file_id: int
    filename: str
    # Exactly the requested field names as keys; a field not found in the
    # document is null rather than the key being absent, so a client never
    # needs to defensively check for a key's existence. Typed as Any (not
    # a narrower union) because the model occasionally returns a nested
    # list/object for a field despite the prompt asking for a flat value
    # (e.g. a "line_items" field) -- better to pass that through than to
    # have our own response fail validation over the model's phrasing.
    data: dict[str, Any]
