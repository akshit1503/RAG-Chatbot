from datetime import datetime, timezone

from sqlalchemy import DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.modules.file_access.database import Base


class DatasetTable(Base):
    """Tracks which uploaded CSV/Excel files have been ingested into
    tabular.db, and under what table name. Lives on the shared app metadata
    Base (like rag.models.DocumentIndex) since it's small bookkeeping, not
    the tabular data itself -- that lives in the separate tabular.db.
    """

    __tablename__ = "dataset_tables"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    file_id: Mapped[int] = mapped_column(ForeignKey("files.id"), unique=True, nullable=False)
    table_name: Mapped[str] = mapped_column(String(64), nullable=False)
    columns: Mapped[str] = mapped_column(String, nullable=False)  # comma-separated sanitized column names
    row_count: Mapped[int] = mapped_column(Integer, nullable=False)
    ingested_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))
