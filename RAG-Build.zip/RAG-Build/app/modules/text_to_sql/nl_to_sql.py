import re

from app.core.ollama_client import generate as _generate

_PROMPT_TEMPLATE = """You are a SQL generator for a SQLite database. Given the table schema and sample rows below, translate the user's question into a single valid SQLite SELECT statement that answers it.

Rules:
- Output ONLY the SQL query. No explanation, no markdown code fences, no commentary.
- Query ONLY the table "{table_name}". Do not reference any other table.
- Only generate a SELECT statement. Never generate INSERT, UPDATE, DELETE, DROP, ALTER, ATTACH, PRAGMA, or any other statement.
- End the query without a trailing semicolon.

Table: {table_name}
Columns: {columns}
Sample rows:
{sample_rows}

Question: {question}

SQL:"""


def build_prompt(*, table_name: str, columns: list[str], sample_rows: list[dict], question: str) -> str:
    samples_text = "\n".join(str(row) for row in sample_rows) if sample_rows else "(no sample rows)"
    return _PROMPT_TEMPLATE.format(
        table_name=table_name,
        columns=", ".join(columns),
        sample_rows=samples_text,
        question=question,
    )


_JOIN_PROMPT_TEMPLATE = """You are a SQL generator for a SQLite database. Given the schemas and sample rows for MULTIPLE tables below, translate the user's question into a single valid SQLite SELECT statement -- using a JOIN across these tables if the question needs data from more than one of them.

Rules:
- Output ONLY the SQL query. No explanation, no markdown code fences, no commentary.
- Query ONLY the tables listed below. Do not reference any other table, under any name or alias trick.
- Only generate a SELECT statement. Never generate INSERT, UPDATE, DELETE, DROP, ALTER, ATTACH, PRAGMA, or any other statement.
- If the question can be answered from a single one of these tables, don't force an unnecessary JOIN.
- End the query without a trailing semicolon.

Tables:
{tables_block}

Question: {question}

SQL:"""

_JOIN_TABLE_BLOCK = """Table: {table_name}
Columns: {columns}
Sample rows:
{sample_rows}"""


def build_join_prompt(*, tables: list[dict], question: str) -> str:
    """`tables` is a list of {"table_name": str, "columns": list[str],
    "sample_rows": list[dict]} -- one entry per dataset the caller has
    already confirmed the requesting user is allowed to see (RBAC is
    enforced before this is ever called, in service.answer_join_query).
    """
    blocks = [
        _JOIN_TABLE_BLOCK.format(
            table_name=t["table_name"],
            columns=", ".join(t["columns"]),
            sample_rows="\n".join(str(row) for row in t["sample_rows"]) if t["sample_rows"] else "(no sample rows)",
        )
        for t in tables
    ]
    return _JOIN_PROMPT_TEMPLATE.format(tables_block="\n\n".join(blocks), question=question)


def generate_sql(prompt: str) -> str:
    return _clean_sql(_generate(prompt))


def _clean_sql(raw: str) -> str:
    text = raw.strip()
    text = re.sub(r"^```(?:sql)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    return text.strip().rstrip(";").strip()


_ANSWER_PROMPT = """You answered a user's question about a dataset by running the SQL query below. Write a concise natural-language answer to the original question based on the results. Format it in Markdown where it helps readability (bold key numbers, a bullet list or small table for multiple rows). Do not restate the raw SQL, and do not invent data not present in the results.

Question: {question}

SQL executed: {sql}

Results ({row_count} row(s) returned{truncated_note}):
{rows_preview}

Answer:"""

_ANSWER_ROW_PREVIEW_LIMIT = 20


def build_answer_prompt(*, question: str, sql: str, rows: list[dict], truncated: bool) -> str:
    preview = rows[:_ANSWER_ROW_PREVIEW_LIMIT]
    rows_preview = "\n".join(str(row) for row in preview) if preview else "(no rows returned)"
    truncated_note = ""
    if truncated:
        truncated_note = ", truncated to the row limit"
    elif len(rows) > len(preview):
        truncated_note = f", showing first {len(preview)}"
    return _ANSWER_PROMPT.format(
        question=question, sql=sql, row_count=len(rows), truncated_note=truncated_note, rows_preview=rows_preview
    )


def summarize_results(prompt: str) -> str:
    return _generate(prompt).strip()
