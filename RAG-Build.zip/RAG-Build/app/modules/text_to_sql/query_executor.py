import re
import sqlite3

from app.modules.text_to_sql.database import get_readonly_connection

MAX_ROWS = 200

_FORBIDDEN_KEYWORDS = (
    "insert", "update", "delete", "drop", "alter", "attach", "detach",
    "pragma", "create", "replace", "truncate", "grant", "vacuum",
    "reindex", "into",
)


class UnsafeQueryError(Exception):
    pass


def validate_sql(sql: str, allowed_tables: set[str]) -> None:
    """Fast sanity check with a clear error message. The real security
    boundary is the SQLite authorizer in execute_readonly(), which enforces
    read access to exactly `allowed_tables` regardless of what this check
    catches -- this just rejects obviously-wrong output (empty, multiple
    statements, a write keyword, referencing none of the allowed tables at
    all) before bothering to open a connection and run it.
    """
    if not sql.strip():
        raise UnsafeQueryError("Model produced an empty query")
    if not re.match(r"^\s*select\b", sql, re.IGNORECASE):
        raise UnsafeQueryError("Only SELECT statements are allowed")
    if ";" in sql:
        raise UnsafeQueryError("Multiple statements are not allowed")

    lowered = sql.lower()
    for keyword in _FORBIDDEN_KEYWORDS:
        if re.search(rf"\b{keyword}\b", lowered):
            raise UnsafeQueryError(f"Query contains a disallowed keyword: '{keyword}'")

    if not any(table.lower() in lowered for table in allowed_tables):
        raise UnsafeQueryError(f"Query must reference at least one of: {', '.join(sorted(allowed_tables))}")


def _make_authorizer(allowed_tables: set[str]):
    """Default-deny SQLite authorizer: only allows reading columns from
    the given set of tables and running SELECTs/functions/JOINs over them.
    This is what actually stops a query from reading a *different*
    dataset's table in the same tabular.db -- read-only file mode alone
    would not, since reading another table isn't a write. Generalizing
    this from a single table to a set is exactly what makes a real
    cross-dataset JOIN possible while still hard-denying every table
    outside the caller-verified, RBAC-checked set (see
    service.answer_join_query -- every table here has already been
    confirmed visible to the requesting user before this authorizer is
    ever installed).
    """

    def authorizer(action, arg1, arg2, db_name, trigger_name):
        if action == sqlite3.SQLITE_READ:
            return sqlite3.SQLITE_OK if arg1 in allowed_tables else sqlite3.SQLITE_DENY
        if action in (sqlite3.SQLITE_SELECT, sqlite3.SQLITE_FUNCTION):
            return sqlite3.SQLITE_OK
        return sqlite3.SQLITE_DENY

    return authorizer


def execute_readonly(sql: str, allowed_tables: set[str]) -> tuple[list[str], list[dict], bool]:
    """Run a validated SELECT against exactly the given set of tables
    (one table for a normal dataset query, more than one for a join --
    see answer_join_query). Returns (columns, rows, truncated).
    """
    validate_sql(sql, allowed_tables)

    conn = get_readonly_connection()
    try:
        conn.set_authorizer(_make_authorizer(allowed_tables))
        cursor = conn.execute(sql)
        columns = [desc[0] for desc in cursor.description] if cursor.description else []
        fetched = cursor.fetchmany(MAX_ROWS + 1)
        truncated = len(fetched) > MAX_ROWS
        rows = [dict(zip(columns, row)) for row in fetched[:MAX_ROWS]]
        return columns, rows, truncated
    except sqlite3.DatabaseError as exc:
        raise UnsafeQueryError(f"Query rejected or failed: {exc}") from exc
    finally:
        conn.close()
