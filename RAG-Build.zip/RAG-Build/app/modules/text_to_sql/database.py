import sqlite3
from pathlib import Path

from sqlalchemy import create_engine

from app.core.config import get_settings

settings = get_settings()
Path(settings.sqlite_db_path).parent.mkdir(parents=True, exist_ok=True)

# Read-write engine used ONLY by the trusted ingestion pipeline -- never
# exposed to LLM-generated SQL. Deliberately a separate database file from
# the app metadata DB (users/files); see app/core/config.py.
tabular_engine = create_engine(
    f"sqlite:///{settings.sqlite_db_path}",
    connect_args={"check_same_thread": False},
)


def init_tabular_db() -> None:
    """Ensure tabular.db exists on disk before any read-only connection is opened."""
    tabular_engine.connect().close()


def get_readonly_connection() -> sqlite3.Connection:
    """A genuinely read-only connection for executing LLM-generated SQL.

    Uses SQLite's mode=ro URI (rejects writes at the file level) plus
    PRAGMA query_only (rejects writes at the SQL-engine level, including
    through an ATTACHed database) as defense in depth against a
    hallucinated or prompt-injected write/DDL statement.
    """
    uri = f"file:{Path(settings.sqlite_db_path).as_posix()}?mode=ro"
    conn = sqlite3.connect(uri, uri=True)
    conn.execute("PRAGMA query_only = ON")
    return conn
