import pandas as pd
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.audit import log_event
from app.core.rate_limit import check_rate_limit
from app.modules.file_access import crud, rbac
from app.modules.file_access.database import get_db
from app.modules.file_access.deps import get_current_user
from app.modules.file_access.models import User
from app.modules.text_to_sql import schemas, service
from app.modules.text_to_sql.ingest import UnsupportedDatasetType
from app.modules.text_to_sql.query_executor import UnsafeQueryError

router = APIRouter(prefix="/sql", tags=["text-to-sql"])


def _get_authorized_file(db: Session, file_id: int, current_user: User, require_manage: bool = False):
    file = crud.get_file_by_id(db, file_id)
    if file is None or not rbac.can_view_file(current_user, file):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found")
    if require_manage and not rbac.can_delete_file(current_user, file):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Only the file owner or an admin may do this")
    return file


@router.post("/datasets/{file_id}/ingest", response_model=schemas.DatasetOut, status_code=status.HTTP_201_CREATED)
def ingest_dataset(file_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    file = _get_authorized_file(db, file_id, current_user, require_manage=True)
    try:
        record = service.ingest_dataset(db, file)
    except UnsupportedDatasetType as exc:
        raise HTTPException(status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE, detail=str(exc)) from exc
    except (pd.errors.ParserError, ValueError) as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=f"Could not parse file: {exc}") from exc

    return schemas.DatasetOut(
        file_id=record.file_id,
        table_name=record.table_name,
        columns=record.columns.split(","),
        row_count=record.row_count,
        ingested_at=record.ingested_at,
    )


@router.get("/datasets/{file_id}/schema", response_model=schemas.SchemaResponse)
def get_schema(file_id: int, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    _get_authorized_file(db, file_id, current_user)
    dataset = service.get_dataset(db, file_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File has not been ingested yet")

    columns = dataset.columns.split(",")
    return schemas.SchemaResponse(
        table_name=dataset.table_name,
        columns=columns,
        row_count=dataset.row_count,
        sample_rows=service.get_sample_rows(dataset.table_name),
    )


@router.post("/datasets/{file_id}/query", response_model=schemas.QueryResponse)
def query_dataset(
    file_id: int,
    request: schemas.QueryRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    check_rate_limit(current_user.id, "sql_query")
    _get_authorized_file(db, file_id, current_user)
    dataset = service.get_dataset(db, file_id)
    if dataset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File has not been ingested yet")

    try:
        answer, sql, columns, rows, truncated = service.answer_query(dataset, request.question)
    except UnsafeQueryError as exc:
        # The authorizer sandbox rejected the LLM-generated SQL -- worth a
        # distinct audit action from a normal query, since a pattern of
        # these could indicate a prompt-injection attempt via the question.
        log_event(
            db, user_id=current_user.id, username=current_user.username,
            action="sql_query_blocked", resource_type="dataset", resource_id=file_id, detail=f"{request.question} -- {exc}",
        )
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)) from exc

    log_event(
        db, user_id=current_user.id, username=current_user.username,
        action="sql_query", resource_type="dataset", resource_id=file_id, detail=request.question,
    )
    return schemas.QueryResponse(
        question=request.question,
        answer=answer,
        sql=sql,
        columns=columns,
        rows=rows,
        row_count=len(rows),
        truncated=truncated,
    )


@router.post("/join-query", response_model=schemas.JoinQueryResponse)
def query_join_datasets(
    request: schemas.JoinQueryRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Answers a question that may need to JOIN across multiple ingested
    datasets. Security-sensitive: every file_id is individually RBAC-checked
    here, up front, before any dataset/table name is ever handed to the SQL
    generator or the authorizer sandbox -- a user can never get a table
    they can't already see included in the allowed set just by listing it
    in file_ids, and a duplicate/repeated id is harmless (the set-based
    authorizer collapses it).
    """
    check_rate_limit(current_user.id, "sql_query")
    if len(request.file_ids) < 2:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Provide at least 2 file_ids to join")

    datasets = []
    for file_id in request.file_ids:
        _get_authorized_file(db, file_id, current_user)  # 404s if not visible to this user -- no exceptions for this endpoint
        dataset = service.get_dataset(db, file_id)
        if dataset is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"File {file_id} has not been ingested yet")
        datasets.append(dataset)

    resource_id = ",".join(str(fid) for fid in request.file_ids)
    try:
        answer, sql, columns, rows, truncated = service.answer_join_query(datasets, request.question)
    except UnsafeQueryError as exc:
        log_event(
            db, user_id=current_user.id, username=current_user.username,
            action="sql_query_blocked", resource_type="dataset_join", resource_id=resource_id,
            detail=f"{request.question} -- {exc}",
        )
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)) from exc

    log_event(
        db, user_id=current_user.id, username=current_user.username,
        action="sql_join_query", resource_type="dataset_join", resource_id=resource_id, detail=request.question,
    )
    return schemas.JoinQueryResponse(
        question=request.question,
        answer=answer,
        sql=sql,
        columns=columns,
        rows=rows,
        row_count=len(rows),
        truncated=truncated,
        file_ids=request.file_ids,
    )
