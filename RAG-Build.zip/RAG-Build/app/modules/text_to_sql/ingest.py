import re
from pathlib import Path

import pandas as pd

from app.modules.text_to_sql.database import tabular_engine


class UnsupportedDatasetType(Exception):
    pass


def _sanitize_identifier(name: str, fallback: str) -> str:
    cleaned = re.sub(r"\W+", "_", str(name).strip()).strip("_").lower()
    if not cleaned:
        return fallback
    if cleaned[0].isdigit():
        cleaned = f"c_{cleaned}"
    return cleaned


def _dedupe_columns(columns: list[str]) -> list[str]:
    seen: dict[str, int] = {}
    result = []
    for col in columns:
        if col not in seen:
            seen[col] = 0
            result.append(col)
        else:
            seen[col] += 1
            result.append(f"{col}_{seen[col]}")
    return result


def load_dataframe(path: Path, suffix: str) -> pd.DataFrame:
    suffix = suffix.lower()
    if suffix == ".csv":
        return pd.read_csv(path)
    if suffix in (".xlsx", ".xls"):
        return pd.read_excel(path)
    raise UnsupportedDatasetType(f"Text-to-SQL ingestion does not support '{suffix}' files")


def ingest_dataframe(df: pd.DataFrame, table_name: str) -> tuple[list[str], int]:
    """Write a DataFrame into tabular.db under table_name, sanitizing column
    names into safe SQL identifiers first. Returns (columns, row_count).
    """
    sanitized_columns = _dedupe_columns(
        [_sanitize_identifier(col, f"col_{i}") for i, col in enumerate(df.columns)]
    )
    df = df.copy()
    df.columns = sanitized_columns
    df.to_sql(table_name, tabular_engine, if_exists="replace", index=False)
    return sanitized_columns, len(df)
