from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.modules.file_access.models import FileRecord
from app.modules.text_to_sql.database import tabular_engine
from app.modules.text_to_sql.ingest import ingest_dataframe, load_dataframe
from app.modules.text_to_sql.models import DatasetTable
from app.modules.text_to_sql.nl_to_sql import (
    build_answer_prompt,
    build_join_prompt,
    build_prompt,
    generate_sql,
    summarize_results,
)
from app.modules.text_to_sql.query_executor import execute_readonly

settings = get_settings()


def _table_name_for(file_id: int) -> str:
    return f"t_{file_id}"


def get_dataset(db: Session, file_id: int) -> DatasetTable | None:
    return db.scalar(select(DatasetTable).where(DatasetTable.file_id == file_id))


def get_sample_rows(table_name: str, limit: int = 5) -> list[dict]:
    with tabular_engine.connect() as conn:
        result = conn.exec_driver_sql(f'SELECT * FROM "{table_name}" LIMIT {limit}')
        columns = list(result.keys())
        return [dict(zip(columns, row)) for row in result.fetchall()]


def ingest_dataset(db: Session, file: FileRecord) -> DatasetTable:
    path = Path(settings.upload_dir) / file.stored_filename
    df = load_dataframe(path, path.suffix)
    table_name = _table_name_for(file.id)
    columns, row_count = ingest_dataframe(df, table_name)

    record = get_dataset(db, file.id)
    if record is None:
        record = DatasetTable(file_id=file.id, table_name=table_name, columns=",".join(columns), row_count=row_count)
        db.add(record)
    else:
        record.table_name = table_name
        record.columns = ",".join(columns)
        record.row_count = row_count
        record.ingested_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(record)
    return record


def remove_dataset(db: Session, file_id: int) -> None:
    record = get_dataset(db, file_id)
    if record is None:
        return
    with tabular_engine.begin() as conn:
        conn.exec_driver_sql(f'DROP TABLE IF EXISTS "{record.table_name}"')
    db.delete(record)
    db.commit()


def answer_query(dataset: DatasetTable, question: str) -> tuple[str, str, list[str], list[dict], bool]:
    columns = dataset.columns.split(",")
    sample_rows = get_sample_rows(dataset.table_name)
    prompt = build_prompt(table_name=dataset.table_name, columns=columns, sample_rows=sample_rows, question=question)
    sql = generate_sql(prompt)
    result_columns, rows, truncated = execute_readonly(sql, {dataset.table_name})

    answer_prompt = build_answer_prompt(question=question, sql=sql, rows=rows, truncated=truncated)
    answer = summarize_results(answer_prompt)

    return answer, sql, result_columns, rows, truncated


def answer_join_query(datasets: list[DatasetTable], question: str) -> tuple[str, str, list[str], list[dict], bool]:
    """Same as answer_query, but across multiple datasets, allowing the
    generated SQL to JOIN between them. Callers MUST have already verified
    the requesting user can view every file these datasets belong to --
    this function has no user/RBAC context of its own, by design, so that
    responsibility can't be silently skipped by a future call site (it's a
    required, visible step at the route layer instead -- see
    routes.query_join_datasets).
    """
    tables = [
        {"table_name": d.table_name, "columns": d.columns.split(","), "sample_rows": get_sample_rows(d.table_name)}
        for d in datasets
    ]
    prompt = build_join_prompt(tables=tables, question=question)
    sql = generate_sql(prompt)

    allowed_tables = {d.table_name for d in datasets}
    result_columns, rows, truncated = execute_readonly(sql, allowed_tables)

    answer_prompt = build_answer_prompt(question=question, sql=sql, rows=rows, truncated=truncated)
    answer = summarize_results(answer_prompt)

    return answer, sql, result_columns, rows, truncated
