from datetime import datetime

from pydantic import BaseModel


class DatasetOut(BaseModel):
    file_id: int
    table_name: str
    columns: list[str]
    row_count: int
    ingested_at: datetime


class SchemaResponse(BaseModel):
    table_name: str
    columns: list[str]
    row_count: int
    sample_rows: list[dict]


class QueryRequest(BaseModel):
    question: str


class QueryResponse(BaseModel):
    question: str
    answer: str
    sql: str
    columns: list[str]
    rows: list[dict]
    row_count: int
    truncated: bool


class JoinQueryRequest(BaseModel):
    file_ids: list[int]
    question: str


class JoinQueryResponse(QueryResponse):
    file_ids: list[int]
