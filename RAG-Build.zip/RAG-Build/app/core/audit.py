import logging
from datetime import datetime, timezone

from sqlalchemy import DateTime, Integer, String, Text
from sqlalchemy.orm import Mapped, Session, mapped_column

from app.core.supabase_client import mirror_row
from app.modules.file_access.database import Base

logger = logging.getLogger(__name__)


class AuditLog(Base):
    """Who did what, to which resource, and when -- a flat append-only log
    of security/compliance-relevant actions (auth, file access, queries).
    Deliberately denormalized (username copied alongside user_id) so a row
    stays readable even if the user account is later deleted.
    """

    __tablename__ = "audit_log"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    action: Mapped[str] = mapped_column(String(64), nullable=False)
    resource_type: Mapped[str | None] = mapped_column(String(64), nullable=True)
    resource_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))


def log_event(
    db: Session,
    *,
    user_id: int | None,
    username: str | None,
    action: str,
    resource_type: str | None = None,
    resource_id: str | int | None = None,
    detail: str | None = None,
) -> None:
    """Best-effort audit write. Never raises -- an audit-logging failure
    (e.g. a locked SQLite file) must not take down the actual request it's
    describing, so any error here is logged and swallowed rather than
    propagated.
    """
    resource_id_str = str(resource_id) if resource_id is not None else None
    detail_str = detail[:2000] if detail else None
    try:
        entry = AuditLog(
            user_id=user_id,
            username=username,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id_str,
            detail=detail_str,
        )
        db.add(entry)
        db.commit()
        row_id = entry.id
        created_at = entry.created_at
    except Exception:
        logger.warning("Failed to write audit log entry for action=%s", action, exc_info=True)
        db.rollback()
        return

    mirror_row(
        "audit_log",
        {
            "source_id": row_id,
            "user_id": user_id,
            "username": username,
            "action": action,
            "resource_type": resource_type,
            "resource_id": resource_id_str,
            "detail": detail_str,
            "created_at": created_at.isoformat(),
        },
    )
