import logging
import shutil
import subprocess
import sys
import time
from pathlib import Path
from urllib.parse import urlparse

import httpx

from app.core.config import get_settings

settings = get_settings()
logger = logging.getLogger(__name__)
_TIMEOUT = httpx.Timeout(120.0)
_CONNECTIVITY_TIMEOUT = httpx.Timeout(5.0)
_AUTO_START_POLL_TIMEOUT = 20.0


class OllamaUnavailableError(Exception):
    """Raised whenever Ollama can't be reached, times out, or errors out.

    Caught by a global FastAPI exception handler (see app/main.py) and
    turned into a clean 503 response instead of a raw 500 traceback.
    """

    def __init__(self, detail: str):
        self.detail = detail
        super().__init__(detail)


def _post(path: str, json: dict) -> dict:
    try:
        with httpx.Client(timeout=_TIMEOUT) as client:
            response = client.post(f"{settings.ollama_host}{path}", json=json)
            response.raise_for_status()
            return response.json()
    except httpx.ConnectError as exc:
        raise OllamaUnavailableError(
            f"Cannot reach Ollama at {settings.ollama_host}. Make sure it's running (`ollama serve`)."
        ) from exc
    except httpx.TimeoutException as exc:
        raise OllamaUnavailableError(
            f"Ollama at {settings.ollama_host} timed out. It may be overloaded, or the model may still be loading."
        ) from exc
    except httpx.HTTPStatusError as exc:
        raise OllamaUnavailableError(
            f"Ollama returned an error ({exc.response.status_code}): {exc.response.text[:300]}"
        ) from exc


def embed(texts: list[str]) -> list[list[float]]:
    data = _post("/api/embed", {"model": settings.ollama_embed_model, "input": texts})
    return data["embeddings"]


def generate(prompt: str) -> str:
    data = _post("/api/generate", {"model": settings.ollama_generation_model, "prompt": prompt, "stream": False})
    return data["response"]


def generate_vision(prompt: str, image_b64: str) -> str:
    data = _post(
        "/api/generate",
        {"model": settings.ollama_vision_model, "prompt": prompt, "images": [image_b64], "stream": False},
    )
    return data["response"]


def check_connectivity() -> tuple[bool, str]:
    """Used at app startup and by GET /health/ollama."""
    try:
        with httpx.Client(timeout=_CONNECTIVITY_TIMEOUT) as client:
            response = client.get(f"{settings.ollama_host}/api/tags")
            response.raise_for_status()
            return True, "ok"
    except httpx.HTTPError as exc:
        return False, str(exc)


def _find_ollama_executable() -> str | None:
    if settings.ollama_executable_path and Path(settings.ollama_executable_path).exists():
        return settings.ollama_executable_path

    on_path = shutil.which("ollama")
    if on_path:
        return on_path

    if sys.platform == "win32":
        candidate = Path.home() / "AppData" / "Local" / "Programs" / "Ollama" / "ollama.exe"
        if candidate.exists():
            return str(candidate)
    elif sys.platform == "darwin":
        candidate = Path("/Applications/Ollama.app/Contents/Resources/ollama")
        if candidate.exists():
            return str(candidate)

    return None


def _launch_ollama_serve(executable: str) -> None:
    log_path = Path(settings.upload_dir).parent / "ollama_serve.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_file = open(log_path, "a")

    kwargs: dict = {"stdout": log_file, "stderr": subprocess.STDOUT, "stdin": subprocess.DEVNULL}
    if sys.platform == "win32":
        kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW | subprocess.DETACHED_PROCESS
    else:
        kwargs["start_new_session"] = True

    subprocess.Popen([executable, "serve"], **kwargs)


def ensure_running() -> tuple[bool, str]:
    """Called at app startup. If Ollama isn't reachable and ollama_host is
    local, try to launch `ollama serve` ourselves and wait briefly for it
    to come up. Returns the same (ok, detail) shape as check_connectivity().
    """
    ok, detail = check_connectivity()
    if ok or not settings.ollama_auto_start:
        return ok, detail

    host = urlparse(settings.ollama_host).hostname or ""
    if host not in ("localhost", "127.0.0.1", "::1"):
        return ok, detail  # remote host -- nothing we can launch

    executable = _find_ollama_executable()
    if executable is None:
        return False, "Ollama not reachable and no local ollama executable was found to auto-start."

    logger.info("Ollama not reachable at %s -- launching `%s serve`", settings.ollama_host, executable)
    try:
        _launch_ollama_serve(executable)
    except OSError as exc:
        return False, f"Failed to launch Ollama: {exc}"

    deadline = time.monotonic() + _AUTO_START_POLL_TIMEOUT
    while time.monotonic() < deadline:
        ok, detail = check_connectivity()
        if ok:
            logger.info("Ollama came up after auto-start")
            return True, "ok"
        time.sleep(0.5)

    return False, f"Launched Ollama but it did not become reachable within {_AUTO_START_POLL_TIMEOUT:.0f}s."
