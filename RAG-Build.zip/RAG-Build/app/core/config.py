from functools import lru_cache
from pathlib import Path

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent.parent
_PATH_FIELDS = ("chroma_persist_dir", "app_db_path", "sqlite_db_path", "upload_dir")


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # App
    app_name: str = "Enterprise RAG + Text-to-SQL Chatbot"
    app_env: str = "development"
    debug: bool = True

    # Ollama
    ollama_host: str = "http://localhost:11434"
    ollama_embed_model: str = "nomic-embed-text"
    ollama_generation_model: str = "gpt-oss:20b-cloud"
    # Vision-capable model used to OCR PDF pages that have no extractable
    # text layer (scanned documents). Free on Ollama's cloud tier, unlike
    # most other cloud vision models which require a paid plan.
    ollama_vision_model: str = "gemma4:cloud"
    # Cap on OCR'd pages per document (<= 0 means no limit). Each page costs
    # a real vision-model call (tens of seconds), so uncapping this means a
    # large scanned PDF can make indexing take a very long time.
    max_ocr_pages: int = 0
    # Chat fallback chain: if a question isn't answered by your documents,
    # try a web search (with clickable citations) before falling back to
    # the model's raw parametric knowledge. Uses DuckDuckGo's public HTML
    # results page -- free, no API key, but an unofficial scrape rather
    # than a supported API. Set false to disable outbound web requests
    # entirely (e.g. for an air-gapped/enterprise deployment).
    enable_web_search: bool = True
    # If Ollama isn't reachable at startup and ollama_host points at
    # localhost, try to launch `ollama serve` ourselves. Set to false to
    # disable (e.g. if Ollama runs elsewhere / is managed separately).
    ollama_auto_start: bool = True
    # Optional explicit path to ollama.exe/ollama, if it's not on PATH and
    # not in the usual per-user install location.
    ollama_executable_path: str = ""

    # ChromaDB
    chroma_persist_dir: str = str(BASE_DIR / "data" / "chroma")

    # App metadata DB (users, file records). Deliberately separate from the
    # Text-to-SQL ingestion DB (sqlite_db_path) so the Text-to-SQL LLM never
    # gets schema visibility into auth tables / password hashes.
    app_db_path: str = str(BASE_DIR / "data" / "sqlite" / "app_metadata.db")

    # SQLite (Text-to-SQL ingestion target for uploaded CSV/Excel data)
    sqlite_db_path: str = str(BASE_DIR / "data" / "sqlite" / "tabular.db")

    # Uploads
    upload_dir: str = str(BASE_DIR / "data" / "uploads")
    max_upload_size_mb: int = 0  # <= 0 means no limit
    allowed_upload_extensions: list[str] = [".pdf", ".txt", ".md", ".docx", ".csv", ".xlsx", ".xls"]

    # JWT / Auth
    jwt_secret_key: str = "change-me-in-.env"
    jwt_algorithm: str = "HS256"
    jwt_access_token_expire_minutes: int = 60

    # Bootstrap admin (created on first startup if no users exist; leave
    # password blank to skip bootstrapping)
    bootstrap_admin_username: str = "admin"
    bootstrap_admin_password: str = ""
    bootstrap_admin_department: str = "global"

    # Chunking (per paper spec)
    chunk_size: int = 1000
    chunk_overlap: int = 100
    retrieval_top_k: int = 4

    # Supabase (optional). Both empty (the default) means the integration
    # is fully inactive and the app behaves exactly as it did before this
    # existed -- SQLite/Chroma remain the only source of truth. Set both to
    # mirror audit-log and feedback rows to a Supabase project as a
    # secondary, queryable store. See supabase_schema.sql for the tables to
    # create in the Supabase SQL editor first, and app/core/supabase_client.py
    # for the integration itself.
    supabase_url: str = ""
    supabase_key: str = ""
    supabase_sync_enabled: bool = True

    # Per-user rate limiting on expensive (LLM-backed) endpoints. <= 0 means
    # unlimited, same "0 = no limit" convention as max_upload_size_mb /
    # max_ocr_pages above. In-memory / per-process -- see app/core/rate_limit.py.
    rate_limit_enabled: bool = True
    rate_limit_requests_per_minute: int = 20

    @field_validator(*_PATH_FIELDS, mode="after")
    @classmethod
    def _anchor_to_base_dir(cls, value: str) -> str:
        """Resolve relative paths (e.g. from .env) against BASE_DIR instead
        of the process's current working directory. Without this, launching
        the app from a different directory silently points it at a
        different (likely empty) database and upload folder -- a fragile
        failure mode that's easy to hit accidentally.
        """
        path = Path(value)
        if not path.is_absolute():
            path = (BASE_DIR / path).resolve()
        return str(path)


@lru_cache
def get_settings() -> Settings:
    return Settings()
