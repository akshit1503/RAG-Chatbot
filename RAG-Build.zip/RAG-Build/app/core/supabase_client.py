import logging
from functools import lru_cache
from typing import Any

from app.core.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


class SupabaseNotConfiguredError(Exception):
    """Raised by get_client() when SUPABASE_URL/SUPABASE_KEY aren't set.
    Callers that only ever go through mirror_row() never see this -- it
    swallows the error itself -- this is for anything that wants a hard
    failure instead (e.g. a future admin "test connection" endpoint).
    """


def is_configured() -> bool:
    return bool(settings.supabase_url and settings.supabase_key)


@lru_cache
def get_client() -> Any:
    """Lazily creates and caches a Supabase client. Importing the
    `supabase` package happens in here, not at module load -- this whole
    integration is optional, so the rest of the app must keep working even
    on an install that never ran `pip install supabase`.
    """
    if not is_configured():
        raise SupabaseNotConfiguredError(
            "SUPABASE_URL and SUPABASE_KEY are not set in .env. This app runs fully "
            "standalone without Supabase -- set both to enable mirroring audit/feedback "
            "rows to your own Supabase project. See supabase_schema.sql for the tables to "
            "create first."
        )
    try:
        from supabase import create_client
    except ImportError as exc:
        raise SupabaseNotConfiguredError(
            "SUPABASE_URL/SUPABASE_KEY are set but the 'supabase' package isn't installed. "
            "Run: pip install supabase"
        ) from exc
    return create_client(settings.supabase_url, settings.supabase_key)


def mirror_row(table: str, data: dict) -> None:
    """Best-effort mirror of a single row to a Supabase table. A pure
    fire-and-forget side channel: Supabase is never the source of truth
    (SQLite/Chroma are), so this silently no-ops when unconfigured and
    silently swallows (logging a warning) any failure when configured --
    the primary write to the local DB must never be blocked or rolled back
    by a Supabase hiccup.
    """
    if not is_configured() or not settings.supabase_sync_enabled:
        return
    try:
        client = get_client()
        client.table(table).insert(data).execute()
    except Exception:
        logger.warning("Supabase mirror write to '%s' failed", table, exc_info=True)
