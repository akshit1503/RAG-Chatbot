import threading
import time
from collections import defaultdict

from app.core.config import get_settings

settings = get_settings()

# In-memory, per-process. Fine for this app's single-instance deployment
# model (no load balancer/multiple workers in front of it); a multi-worker
# deployment would need a shared store (e.g. Redis) instead, since each
# worker process would otherwise track its own independent window.
_lock = threading.Lock()
_buckets: dict[tuple[int, str], list[float]] = defaultdict(list)


class RateLimitExceededError(Exception):
    def __init__(self, retry_after_seconds: float):
        self.retry_after_seconds = retry_after_seconds
        super().__init__(f"Rate limit exceeded, retry after {retry_after_seconds:.1f}s")


def check_rate_limit(user_id: int, bucket: str, limit: int | None = None, window_seconds: int = 60) -> None:
    """Sliding-window rate limit: at most `limit` calls from this user in
    this bucket within `window_seconds`. Buckets are per (user, endpoint
    group) -- e.g. a user hammering RAG queries doesn't eat into their own
    SQL-query quota, and one user's usage never affects another's.

    `limit=None` uses the global default (settings.rate_limit_requests_per_minute).
    `limit<=0` (either the passed value or the global default) means
    unlimited, matching this app's existing convention for "0 = no limit"
    settings (max_upload_size_mb, max_ocr_pages).
    """
    if not settings.rate_limit_enabled:
        return
    effective_limit = limit if limit is not None else settings.rate_limit_requests_per_minute
    if effective_limit <= 0:
        return

    key = (user_id, bucket)
    now = time.monotonic()
    with _lock:
        timestamps = _buckets[key]
        cutoff = now - window_seconds
        while timestamps and timestamps[0] < cutoff:
            timestamps.pop(0)
        if len(timestamps) >= effective_limit:
            retry_after = window_seconds - (now - timestamps[0])
            raise RateLimitExceededError(max(retry_after, 0.0))
        timestamps.append(now)


def reset_all() -> None:
    """Test-only helper: clears all buckets so tests don't leak state
    into each other or depend on real wall-clock gaps between test runs.
    """
    with _lock:
        _buckets.clear()
