import httpx
from bs4 import BeautifulSoup

_TIMEOUT = httpx.Timeout(15.0)
_SEARCH_URL = "https://html.duckduckgo.com/html/"
_INSTANT_ANSWER_URL = "https://api.duckduckgo.com/"
_HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; RAG-Chatbot/1.0)"}


class WebSearchError(Exception):
    pass


def _instant_answer(query: str) -> list[dict]:
    """DuckDuckGo's Instant Answer API -- a real, documented, key-free JSON
    API meant for exactly this kind of programmatic use (unlike
    _html_search below, this is NOT scraping a page meant for browsers,
    so there's no bot-detection question here at all). Good coverage for
    well-known topics/entities (usually pulling a Wikipedia-sourced
    abstract), poor coverage for narrow or phrased-as-a-question queries
    -- a real supplement to _html_search, not a full replacement, so
    callers should still fall through to that when this comes back empty.
    """
    try:
        response = httpx.get(
            _INSTANT_ANSWER_URL,
            params={"q": query, "format": "json", "no_html": 1, "skip_disambig": 1},
            timeout=_TIMEOUT,
        )
        response.raise_for_status()
        data = response.json()
    except (httpx.HTTPError, ValueError):
        return []

    abstract = data.get("AbstractText")
    if not abstract:
        return []
    return [
        {
            "title": data.get("Heading") or query,
            "url": data.get("AbstractURL") or "",
            "snippet": abstract,
        }
    ]


def _html_search(query: str, max_results: int) -> list[dict]:
    """Free, unofficial web search via DuckDuckGo's HTML results page (no
    API key, no paid search API). This scrapes a public results page
    rather than calling a supported API, so it can break if DuckDuckGo
    changes their markup, AND -- observed directly, not assumed -- it can
    also come back with a bot-detection challenge page (an `anomaly.js`
    JS verification challenge, HTTP 202) instead of real results under
    normal automated use. That's DuckDuckGo's own anti-bot measure
    working as intended; this app does not attempt to defeat it (no
    headless-browser JS execution, no fingerprint spoofing, no proxying)
    -- callers should treat an empty result list here as an expected,
    honest failure mode and degrade gracefully (see rag/service.py's
    fallback chain), not something to route around.
    """
    try:
        with httpx.Client(timeout=_TIMEOUT, headers=_HEADERS) as client:
            response = client.post(_SEARCH_URL, data={"q": query})
            response.raise_for_status()
    except httpx.HTTPError as exc:
        raise WebSearchError(f"Web search request failed: {exc}") from exc

    soup = BeautifulSoup(response.text, "html.parser")
    results = []
    for result in soup.select(".result")[:max_results]:
        title_el = result.select_one(".result__title")
        link_el = result.select_one(".result__a")
        snippet_el = result.select_one(".result__snippet")
        if not (title_el and link_el and link_el.get("href")):
            continue
        results.append(
            {
                "title": title_el.get_text(strip=True),
                "url": link_el["href"],
                "snippet": snippet_el.get_text(strip=True) if snippet_el else "",
            }
        )
    return results


def search_web(query: str, max_results: int = 5, topic: str | None = None) -> list[dict]:
    """Tries the Instant Answer API first -- with `topic` (a bare
    entity/subject name, if the caller has one) before `query`, since the
    IA API does near-exact topic-name lookup rather than full-text search
    (confirmed by direct testing: "Eiffel Tower" returns a real abstract,
    "eiffel tower built year" returns nothing at all). Falls through to
    the HTML-scrape results page if neither IA attempt came back with
    anything. All three are complementary, not redundant, so trying them
    in sequence meaningfully improves real-world reliability without
    doing anything evasive -- this is just using DuckDuckGo's own
    legitimate, documented, key-free API before falling back to the page
    meant for browsers.
    """
    if topic:
        results = _instant_answer(topic)
        if results:
            return results
    results = _instant_answer(query)
    if results:
        return results
    return _html_search(query, max_results)
